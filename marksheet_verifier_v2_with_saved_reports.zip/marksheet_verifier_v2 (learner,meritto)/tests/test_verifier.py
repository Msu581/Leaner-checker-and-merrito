"""Run:  python -m pytest -q tests
Optional checks against real files: set MV_REAL_DATA to a folder holding the real workbooks/PDFs."""
from __future__ import annotations

import glob
import os
import sqlite3
import sys
from pathlib import Path

import pytest
from openpyxl import Workbook, load_workbook

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).parent))

from fixtures import grade_sheet, write_all

import core
import meritto as M
from core import MODE_STRICT, ST_MATCH, ST_MISMATCH, ST_SKIPPED, Settings

STRICT = Settings(mode=MODE_STRICT)
REAL = Path(os.environ.get("MV_REAL_DATA", "/nonexistent"))


def real(pattern):
    hits = sorted(glob.glob(str(REAL / pattern)))
    if not hits:
        pytest.skip(f"real file {pattern} not available (set MV_REAL_DATA)")
    return hits[0]


# ============================================================ PDF reading: ABC ID present / absent
def test_pdf_with_and_without_abc(tmp_path):
    a = core.read_pdf(grade_sheet(tmp_path / "a.pdf", "Divyanteeka", "Sanjay Kumar Sinha", "Poonam Kumari",
                                  "20-03-2007", reg="240410700090", abc="954810071797"))[0].fields
    assert a["abc"] == "954810071797" and a["reg"] == "240410700090" and a["father"] == "Sanjay Kumar Sinha"
    b = core.read_pdf(grade_sheet(tmp_path / "b.pdf", "X Y", "F", "M", "01-01-2006", reg="251612400486"))[0].fields
    assert "abc" not in b and b["reg"] == "251612400486"


@pytest.mark.parametrize("value", ["N/A", "-", "Not Available"])
def test_placeholder_abc_is_ignored(tmp_path, value):
    f = core.read_pdf(grade_sheet(tmp_path / "c.pdf", "X Y", "F", "M", "01-01-2006", reg="251612400486", abc=value))[0].fields
    assert "abc" not in f


def test_spaced_abc_is_normalised(tmp_path):
    f = core.read_pdf(grade_sheet(tmp_path / "d.pdf", "X", "F", "M", "01-01-2006", reg="1234567", abc="9548 1007 1797"))[0].fields
    assert f["abc"] == "954810071797"


def test_real_divyanteeka_pdf():
    f = core.read_pdf(real("*Divyanteeka*.pdf"))[0].fields
    assert f == {"name": "Divyanteeka", "father": "Sanjay Kumar Sinha", "mother": "Poonam Kumari",
                 "dob": "20-03-2007", "abc": "954810071797", "reg": "240410700090"}


# ============================================================ field comparison
def test_abc_compare_rules():
    s = Settings()
    assert core.compare_field("abc", "", "954810071797", s).status == ST_SKIPPED       # no ABC on marksheet: fine
    assert core.compare_field("abc", "9548 1007 1797", "954810071797", s).status == ST_MATCH
    assert core.compare_field("abc", "954810071790", "954810071797", s).status == ST_MISMATCH
    assert core.compare_field("abc", "954810071797", "", s).status == core.ST_MISSING


@pytest.mark.parametrize("pdf, excel, normal_ok, strict_ok", [
    ("S R Sahoo", "R S Sahoo", True, False),           # normal: same words, other order; strict: different
    ("Deepchand Dayma", "Deep Chand Dayma", True, False),
    ("S.R. SAHOO", "s r sahoo", True, True),            # case + punctuation only
    ("Anisha   Sahoo", "Anisha Sahoo", True, True),     # extra spaces
    ("Ballanki Sivalakshmi", "Ballanki Shivalakshmi", True, False),
])
def test_strict_vs_normal(pdf, excel, normal_ok, strict_ok):
    n = core.compare_field("father", pdf, excel, Settings())
    s = core.compare_field("father", pdf, excel, STRICT)
    assert (s.status == ST_MATCH) is strict_ok
    if normal_ok:
        assert n.status in (ST_MATCH, core.ST_CLOSE)
    assert s.status in (ST_MATCH, ST_MISMATCH)  # strict never gives partial results


def test_normal_mode_word_order_is_close_but_strict_is_mismatch():
    assert core.compare_field("father", "S R Sahoo", "R S Sahoo", Settings()).status == core.ST_CLOSE
    assert core.compare_field("father", "S R Sahoo", "R S Sahoo", STRICT).status == ST_MISMATCH


def test_titles_toggle_in_strict_mode():
    assert core.compare_field("father", "Mr Banarsi Lal", "Banarsi Lal", STRICT).status == ST_MATCH
    keep = Settings(mode=MODE_STRICT, ignore_titles=False)
    assert core.compare_field("father", "Mr Banarsi Lal", "Banarsi Lal", keep).status == ST_MISMATCH


def test_norm_reg_handles_float_text():
    assert core.norm_reg("251612400673.0") == core.norm_reg(251612400673) == "251612400673"
    assert core.norm_reg("2.51612400699E+11") == "251612400699"
    assert core.norm_reg("REG/2025/0012") == "REG20250012"  # unchanged behaviour for non-numeric IDs


# ============================================================ page 1 compare
def _grid(rows):
    return [[core._cell_str(c) for c in r] for r in rows]


def test_abc_fallback_when_pdf_has_no_reg(tmp_path):
    grid = _grid([["Reg No", "ABC ID", "Name", "Father Name", "Mother Name", "DOB"],
                  ["251612400001", "954810071797", "Divyanteeka", "Sanjay Kumar Sinha", "Poonam Kumari", "20/03/2007"]])
    rec = core.read_pdf(grade_sheet(tmp_path / "x.pdf", "Divyanteeka", "Sanjay Kumar Sinha", "Poonam Kumari",
                                    "20-03-2007", abc="954810071797"))
    m = {k: g.col for k, g in core.auto_detect(grid, 0, rec).items()}
    assert m["abc"] == 1
    r = core.compare(grid, 0, m, rec).records[0]
    assert r.overall == core.OV_VERIFIED and r.excel_row == 2 and "paired by ABC ID" in r.note
    assert r.fields["reg"].status == ST_SKIPPED


def test_missing_abc_on_marksheet_does_not_change_overall(tmp_path):
    grid = _grid([["Reg No", "ABC ID", "Name", "Father Name", "Mother Name", "DOB"],
                  ["251612400486", "111", "Anuj Dayma", "Deepchand Dayma", "Kamla Devi", "03/04/2006"]])
    rec = core.read_pdf(grade_sheet(tmp_path / "y.pdf", "Anuj Dayma", "Deepchand Dayma", "Kamla Devi", "03-04-2006",
                                    reg="251612400486"))
    m = {k: g.col for k, g in core.auto_detect(grid, 0, rec).items()}
    r = core.compare(grid, 0, m, rec).records[0]
    assert r.fields["abc"].status == ST_SKIPPED and r.overall == core.OV_VERIFIED


def test_split_first_last_name():
    grid = _grid([["First Name", "Last Name", "Father Name", "Registration Number"],
                  ["Anisha", "Sahoo", "S R Sahoo", "251612400673"]])
    g = core.auto_detect(grid, 0)
    assert g["name"].col == 0 and g["name_last"].col == 1
    rec = core.PdfRecord("a.pdf", "a.pdf", 1, 1, {"reg": "251612400673", "name": "Anisha Sahoo", "father": "S R Sahoo"})
    r = core.compare(grid, 0, {k: v.col for k, v in g.items()}, [rec], STRICT).records[0]
    assert r.fields["name"].status == ST_MATCH and r.fields["name"].excel_value == "Anisha Sahoo"


def test_all_sheets_combines_different_layouts(tmp_path):
    wb = Workbook()
    a = wb.active
    a.title = "SOT"
    a.append(["", "Data Required"])
    a.append(["Partner", "ABC ID", "Candidate Name", "Father Name", "MSU REGN_NO"])
    a.append(["PW", "111", "Akash", "Vikas", 251811600057])
    b = wb.create_sheet("SOM")  # extra leading serial column, so every column is shifted
    b.append(["", "", "Data Required"])
    b.append(["", "Partner", "ABC ID", "Candidate Name", "Father Name", "MSU REGN_NO"])
    b.append([1, "PW", "222", "Zeeshan", "Shahadat", 251511800028])
    n = wb.create_sheet("Mapping")  # lookup sheet: must be skipped
    n.append(["TruScholar Field", "Source"])
    n.append(["Registration Number", "MSU REGN_NO"])
    p = tmp_path / "multi.xlsx"
    wb.save(p)
    sd = core.load_all_sheets(p)
    assert "Mapping" in sd.note and sd.grid[0][-1] == "Sheet"
    g = core.auto_detect(sd.grid, 0)
    m = {k: v.col for k, v in g.items()}
    rec = core.PdfRecord("z.pdf", "z.pdf", 1, 1, {"reg": "251511800028", "name": "Zeeshan", "father": "Shahadat"})
    res = core.compare(sd.grid, 0, m, [rec], origin=sd.origin)
    r = res.records[0]
    assert r.overall == core.OV_VERIFIED and r.excel_row == "SOM!3"
    assert res.unmatched_excel == [{"row": "SOT!3", "reg": "251811600057", "name": "Akash"}]
    assert sd.row_label(1) == "SOT!3"


def test_page1_sample_results_unchanged():
    """Regression: the bundled sample data gives the same results as before this change."""
    sd = core.load_sheet(ROOT / "sample_data" / "sample_students.xlsx")
    hr = core.detect_header_row(sd.grid)
    recs = [r for p in sorted((ROOT / "sample_data").glob("*.pdf")) for r in core.read_pdf(p)]
    m = {k: g.col for k, g in core.auto_detect(sd.grid, hr, recs).items()}
    got = {r.pdf.file: (r.overall, r.excel_row) for r in core.compare(sd.grid, hr, m, recs).records}
    assert got == {"Abdul_Samad_marksheet.pdf": ("Verified (minor differences)", 5),
                   "Anita_Kumari.pdf": ("Verified (minor differences)", 9), "Imran.pdf": ("Needs review", 8),
                   "Priya_Sharma.pdf": ("Verified", 6), "Rohan_Das.pdf": ("Needs review", 7),
                   "Unknown_Student.pdf": ("Not in Excel", None)}


def test_old_database_runs_still_load_and_export(tmp_path):
    """A run saved before ABC existed (no abc field rows) must still open and export."""
    from report import build_report
    from storage import Database

    db = Database(tmp_path / "old.db")
    rec = core.PdfRecord("a.pdf", "a.pdf", 1, 1, {"reg": "1", "name": "A"})
    fr = {"reg": core.FieldResult("reg", "1", "1", ST_MATCH, 100.0), "name": core.FieldResult("name", "A", "A", ST_MATCH, 100.0)}
    rid = db.save_run({"mapping": {"reg": 0, "name": 1}}, core.RunResult([core.RecordResult(rec, core.OV_VERIFIED, 2, fr)], []))
    info, res = db.load_run(rid)
    assert "abc" not in res.records[0].fields
    build_report(tmp_path / "r.xlsx", info, res)
    assert load_workbook(tmp_path / "r.xlsx").sheetnames == ["Summary", "Comparison", "Needs attention", "Unmatched Excel"]
    db.close()
    assert sqlite3.connect(tmp_path / "old.db").execute("select count(*) from runs").fetchone()[0] == 1


# ============================================================ page 2: Meritto vs Marksheet
def meritto_book(path):
    """Same structure as the real 1083 sheet."""
    wb = Workbook()
    ws = wb.active
    ws.append(["Escalation Matrix", "E1", None, None, None, "E2", None, "E3"])
    ws.append([None, "Date", "To", None, None, "Date", "To", "Date", "To"])
    ws.append([])
    ws.append([None] * 7 + ["Resolution status"])
    ws.append(["Sl no.", "Student Name", "Enrollment no.", "ABC ID", "Remarks", "Data as per Meritto/TR",
               "Data in Marksheet", "Remarks", "Date"])
    ws.append([])
    ws.append(["Anaesthesia and Operation Theatre Technology"])                                        # row 7 section
    ws.append([1.0, "Anisha Sahoo", 251612400673.0, None, "Father's Name is not as per 10th marksheet",
               "Father's Name : S R Sahoo", "Father's Name : R S Sahoo"])                              # 8
    ws.append([2.0, "Anuj Dayma", 251612400486.0, None, "Father's Name is not as per 10th marksheet",
               "Father's Name :Deep Chand Dayma", "Father's Name :Deepchand Dayma"])                   # 9
    ws.append([3.0, "Arpan", 251612400436.0, None, "x", "Father’s Name : Banarsi Lal", "Father's Name : Mr Banarsi Lal"])  # 10
    ws.append([4.0, "Ballanki Sowmya", 251612400524.0, None, "x", "Mother's Name : Ballanki Shivalakshmi",
               "Mother's Name : Ballanki Sivalakshmi"])                                                 # 11
    ws.append([5.0, "Kammari Sanjana", 251612400671.0, None, "x", "Father's Name : Kammari Chandra Shekar Chary",
               "Father's Name : Kammari Chandra Sekhar Chary"])                                         # 12
    ws.append([6.0, "Bilquis", "251612400999", None, "x",
               "Name of Student : Bilquis Shabir\nFather's Name : Shabir Ahmad Khanday", None])         # 13 no PDF
    ws.append([7.0, "Bhawna", 251612400222.0, None, "Total marks have to be rechecked", None, None])     # 14 empty
    ws.append([8.0, "Aman", 251612400471.0, None, "marks", "Marks - 34", "Marks - 31"])                 # 15 marks
    ws.append([9.0, "Ravi", 251612400472.0, None, "Aadhaar wrong", "Aadhaar No. : 805951933281", None])  # 16 unsupported
    ws.append([10.0, "Anuj Dayma", 251612400486.0, None, "Mother's name is not as per 10th",
               "Kamla Devi", None])                                                                    # 17 field from remark
    ws.append(["HHM Emversity"])                                                                       # 18 section
    ws.append([11.0, "Anisha Sahoo", 251612400673.0, None, "dup", "Father's Name : S R Sahoo", None])    # 19 duplicate
    wb.save(path)
    return str(path)


@pytest.fixture
def meritto_setup(tmp_path):
    sd = core.load_sheet(meritto_book(tmp_path / "1083.xlsx"))
    pdfs = write_all(tmp_path / "pdfs")
    recs = [r for p in pdfs.values() for r in core.read_pdf(p)]
    hr = M.detect_header_row(sd.grid)
    cols = {k: g.col for k, g in M.detect_columns(sd.grid, hr, recs).items()}
    return sd, hr, cols, recs


def test_meritto_detects_header_and_columns(meritto_setup):
    _sd, hr, cols, _ = meritto_setup
    assert hr == 4  # row 5
    assert {k: core.col_letter(v) for k, v in cols.items()} == {
        "enroll": "C", "expected": "F", "claimed": "G", "student": "B", "remark": "E", "abc": "D"}


def test_parse_cell_variants():
    got = M.parse_cell("Father's Name :Bhagirath\nMother's Name : Maya Devi\n")
    assert got == [("Father's Name", "father", "Bhagirath"), ("Mother's Name", "mother", "Maya Devi")]
    assert M.parse_cell("Name of Student : Ms.Nasreen")[0][1:] == ("name", "Ms.Nasreen")
    assert M.parse_cell("Marks - 34")[0] == ("", None, "Marks - 34")


def _by_row(checks):
    out = {}
    for c in checks:
        out.setdefault(c.excel_row, []).append(c)
    return out


def test_meritto_results_normal_mode(meritto_setup):
    sd, hr, cols, recs = meritto_setup
    checks = M.run_checks(M.build_checks(sd.grid, hr, cols), recs, Settings())
    r = _by_row(checks)
    assert 7 not in r and 18 not in r                         # section rows skipped
    assert r[8][0].status == M.M_OLD                           # PDF still shows R S Sahoo
    assert r[9][0].status == M.M_OLD                           # old value wins over 'close' in both modes
    assert r[10][0].status == M.M_CORRECT                      # Mr ignored; curly apostrophe label parsed
    assert r[11][0].status == M.M_CORRECT
    assert r[12][0].status in (M.M_WRONG, M.M_REVIEW)          # neither expected nor old value
    assert [c.field for c in r[13]] == ["name", "father"] and {c.status for c in r[13]} == {M.M_NOPDF}
    assert r[14][0].status == M.M_SKIP
    assert r[15][0].status == M.M_MARKS
    assert r[16][0].status == M.M_SKIP and "Aadhaar" in r[16][0].note
    assert r[17][0].field == "mother" and r[17][0].status == M.M_CORRECT and "Remarks" in r[17][0].note
    # duplicate: flagged on both rows and checked separately; row 19 has no old value, so normal mode
    # rates the word-order difference as close, while strict mode calls it a mismatch
    assert "row(s) 19" in r[8][0].note and "row(s) 8" in r[19][0].note
    assert r[19][0].status == M.M_MINOR
    assert M.evaluate(r[19][0], recs, STRICT).status == M.M_WRONG
    assert r[8][0].pdf_file == "Anisha_Sahoo.pdf" and r[8][0].pdf_value == "R S Sahoo"


def test_meritto_strict_vs_normal_difference(tmp_path):
    """Corrected PDF with only a spacing difference: normal accepts, strict rejects."""
    recs = core.read_pdf(grade_sheet(tmp_path / "s.pdf", "A", "Deepchand Dayma", "M", "01-01-2006", reg="251612400486"))
    chk = M.Check(excel_row=9, enrollment="251612400486", field="father", label="Father's Name", expected="Deep Chand Dayma")
    assert M.evaluate(chk, recs, Settings()).status == M.M_MINOR
    assert M.evaluate(chk, recs, STRICT).status == M.M_WRONG and "split differently" in chk.note


def test_meritto_abc_fallback_and_missing_field(tmp_path):
    recs = core.read_pdf(grade_sheet(tmp_path / "n.pdf", "A", "B", "C", "01-01-2006", abc="954810071797"))  # no reg
    chk = M.Check(excel_row=5, enrollment="", abc="954810071797", field="father", expected="B")
    assert M.evaluate(chk, recs, STRICT).status == M.M_CORRECT and "ABC" in chk.note
    rec = core.PdfRecord("p.pdf", "p.pdf", 1, 1, {"reg": "251612400673", "name": "A"})
    chk2 = M.Check(excel_row=6, enrollment="251612400673", field="mother", expected="X")
    assert M.evaluate(chk2, [rec], STRICT).status == M.M_NOFIELD


def test_meritto_near_miss_enrollment_is_reported():
    rec = core.PdfRecord("p.pdf", "p.pdf", 1, 1, {"reg": "251612400673", "father": "X"})
    chk = M.Check(excel_row=6, enrollment="251612400678", field="father", expected="X")
    assert M.evaluate(chk, [rec], STRICT).status == M.M_NOPDF and "Closest PDF: p.pdf" in chk.note


def test_meritto_manual_overrides(meritto_setup):
    sd, hr, cols, recs = meritto_setup
    checks = M.run_checks(M.build_checks(sd.grid, hr, cols), recs, STRICT)
    c = next(x for x in checks if x.excel_row == 8)
    c.force_pdf_value = "S R Sahoo"                          # reviewer typed what the re-issued sheet says
    assert M.evaluate(c, recs, STRICT).status == M.M_CORRECT
    c.force_pdf_value = None
    c.force_pdf_path = next(r.path for r in recs if r.file == "Arpan.pdf")  # wrong PDF chosen by hand
    M.evaluate(c, recs, STRICT)
    assert c.pdf_file == "Arpan.pdf" and "chosen by hand" in c.note
    c.expected = ""                                          # expected value removed by hand -> not a mismatch
    assert M.evaluate(c, recs, STRICT).status == M.M_SKIP


def test_meritto_manual_columns_and_last_row(meritto_setup):
    sd, hr, _cols, recs = meritto_setup
    g = M.detect_columns(sd.grid, hr, recs, keep={"expected": 6, "claimed": 5})  # user swapped F and G
    assert g["expected"].col == 6 and g["claimed"].col == 5 and g["expected"].confidence == "manual"
    checks = M.build_checks(sd.grid, hr, {k: v.col for k, v in g.items()}, last_row=9)
    assert {c.excel_row for c in checks} == {8, 9}
    with pytest.raises(ValueError):
        M.build_checks(sd.grid, hr, {"enroll": None, "expected": 5})


def test_meritto_report(meritto_setup, tmp_path):
    from report import build_meritto_report

    sd, hr, cols, recs = meritto_setup
    checks = M.run_checks(M.build_checks(sd.grid, hr, cols), recs, STRICT)
    checks[0].manual.append("PDF value set by hand")
    p = build_meritto_report(tmp_path / "m.xlsx", {"columns": cols, "settings": STRICT.to_dict()}, checks)
    wb = load_workbook(p)
    assert wb.sheetnames == ["Summary", "Results", "Needs attention"]
    assert wb["Results"].max_row == len(checks) + 1
    assert wb["Results"]["I2"].value == checks[0].status and wb["Results"]["O2"].value == "PDF value set by hand"
    n_problem = sum(c.status in M.M_PROBLEM for c in checks)
    assert wb["Needs attention"].max_row == n_problem + 1
    summary = [str(c.value) for row in wb["Summary"].iter_rows() for c in row if c.value]
    assert any("Strict" in v for v in summary) and any("COUNTIF(Results!$I$2" in v for v in summary)


def test_real_1083_file_parses():
    sd = core.load_sheet(real("*1083*.xlsx"))
    hr = M.detect_header_row(sd.grid)
    cols = {k: g.col for k, g in M.detect_columns(sd.grid, hr).items()}
    assert hr == 4 and core.col_letter(cols["enroll"]) == "C" and core.col_letter(cols["expected"]) == "F"
    checks = M.build_checks(sd.grid, hr, cols)
    kinds = {k: sum(c.kind == k for c in checks) for k in ("field", "marks", "empty", "unsupported")}
    assert kinds == {"field": 128, "marks": 16, "empty": 12, "unsupported": 1}
    first = checks[0]
    assert (first.excel_row, first.field, first.expected, first.claimed) == (8, "father", "S R Sahoo", "R S Sahoo")


def test_real_pw_file_all_sheets():
    sd = core.load_all_sheets(real("*PW_Learners*.xlsx"))
    assert {o[0] for o in sd.origin if o} == {"SOT", "SOM", "SOH"} and len(sd.grid) == 613
    g = core.auto_detect(sd.grid, 0)
    assert sd.grid[0][g["reg"].col] == "MSU REGN_NO" and sd.grid[0][g["abc"].col] == "ABC ID"


def test_real_truscholar_file():
    sd = core.load_sheet(real("*Learner_Data*.xlsx"))
    g = core.auto_detect(sd.grid, 0)
    assert [sd.grid[0][g[k].col] for k in ("reg", "abc", "name", "name_last")] == [
        "Registration Number", "ABC ID", "First Name", "Last Name"]
    assert "Mapping" in core.load_all_sheets(sd.path).note


# ============================================================ PDF layout: long value running into the right column
def test_long_value_glued_to_right_column_label(tmp_path):
    f = core.read_pdf(grade_sheet(tmp_path / "g.pdf", "AKASH VIKAS WAKADE", "VIKAS SHANKAR WAKADE",
                                  "SANGITA VIKAS WAKADE", "30-03-2006", reg="251811600057"))[0].fields
    assert f["father"] == "VIKAS SHANKAR WAKADE" and f["mother"] == "SANGITA VIKAS WAKADE"


def test_long_value_without_label_is_not_cut():
    def w(t, x0, top, width=None):
        return {"text": t, "x0": x0, "x1": x0 + (width or 6 * len(t)), "top": top, "bottom": top + 10}
    words = [w("Category", 330, 0), w(":", 430, 0), w("Regular", 436, 0),            # two lines give the anchor x=330
             w("Semester", 330, 20), w(":", 430, 20), w("First", 436, 20),
             w("Father's", 60, 40), w("Name", 110, 40), w(":", 165, 40),
             w("VENKATA", 171, 40), w("SATYA", 220, 40), w("NARAYANA", 260, 40), w("MURTHY", 330, 40)]
    line = core._lines_from_words(words)[2]
    assert line == ["Father's Name : VENKATA SATYA NARAYANA MURTHY"]


def test_sheet_row_label_survives_database_and_report(tmp_path):
    from report import build_report
    from storage import Database

    grid = _grid([["Reg No", "Name"], ["1", "A"], ["2", "B"]])
    rec = core.PdfRecord("a.pdf", "a.pdf", 1, 1, {"reg": "1", "name": "A"})
    res = core.compare(grid, 0, {"reg": 0, "name": 1}, [rec], origin=[None, ("SOM", 7), ("SOH", 9)])
    db = Database(tmp_path / "t.db")
    info, back = db.load_run(db.save_run({"mapping": {"reg": 0}}, res))
    assert back.records[0].excel_row == "SOM!7" and back.unmatched_excel[0]["row"] == "SOH!9"
    build_report(tmp_path / "r.xlsx", info, back)
    wb = load_workbook(tmp_path / "r.xlsx")
    assert wb["Comparison"]["E3"].value == "SOM!7" and wb["Unmatched Excel"]["A2"].value == "SOH!9"
    db.close()


# ---------------------------------------------------------------- stored Excel reports
def test_reports_are_stored_with_date_and_file(tmp_path):
    from report import build_report, build_meritto_report
    from storage import Database, learner_summary

    rec = core.PdfRecord("a.pdf", "a.pdf", 1, 1, {"reg": "123456", "name": "Asha"})
    fr = {"name": core.FieldResult("name", "Asha", "Asha", ST_MATCH, 100.0, "")}
    res = core.RunResult([core.RecordResult(rec, core.OV_VERIFIED, 2, fr)], [])
    db = Database(tmp_path / "t.db")
    run_id = db.save_run({"mapping": {"reg": 0}}, res)
    p = tmp_path / "learner.xlsx"
    build_report(p, {"excel_file": "students.xlsx"}, res)
    r1 = db.save_report("Learner", p, {"excel_file": "students.xlsx"}, run_id=run_id, summary=learner_summary(res))

    chk = M.Check(excel_row=5, enrollment="123456", label="Father's Name", field="father", expected="Ravi")
    chk.status, chk.pdf_value = M.M_CORRECT, "Ravi"
    q = tmp_path / "meritto.xlsx"
    build_meritto_report(q, {"excel_file": "1083.xlsx"}, [chk])
    r2 = db.save_report("Meritto", q, {"excel_file": "1083.xlsx"}, summary="Correct 1", checks=[chk])

    rows = db.list_reports()
    assert [r["id"] for r in rows] == [r2, r1]                       # newest first
    assert rows[0]["kind"] == "Meritto" and rows[1]["run_id"] == run_id
    assert len(rows[0]["created_at"]) == 19                          # YYYY-MM-DD HH:MM:SS
    name, data = db.report_file(r2)
    assert name == "meritto.xlsx" and data == q.read_bytes()         # the exact file comes back
    found = db.meritto_history_for_enrollment("123456")
    assert found[0]["status"] == M.M_CORRECT and found[0]["expected"] == "Ravi"
    db.delete_run(run_id)                                            # report survives, link cleared
    assert db.list_reports()[1]["run_id"] is None
    db.delete_report(r2)
    assert db.report_checks(r2) == [] and len(db.list_reports()) == 1


def test_old_database_gets_reports_table(tmp_path):
    from storage import Database

    p = tmp_path / "old.db"
    con = sqlite3.connect(p)
    con.execute("CREATE TABLE runs(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL)")
    con.commit()
    con.close()
    assert Database(p).list_reports() == []
