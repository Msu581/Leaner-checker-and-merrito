"""Test helpers: grade-sheet PDFs laid out like the real Medhavi grade sheet
(two columns of 'Label : value'; ABC ID present on some sheets and absent on others).
Needs reportlab (test-only dependency, see requirements-dev.txt)."""
from __future__ import annotations

from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas


def grade_sheet(path, name, father, mother, dob, reg=None, abc=None, extra=None):
    """Write one grade sheet. reg/abc None = that line is not printed at all."""
    c = canvas.Canvas(str(path), pagesize=A4)
    c.setFont("Helvetica-Bold", 18)
    c.drawString(140, 760, "MEDHAVI SKILLS UNIVERSITY, SIKKIM")
    c.setFont("Helvetica", 11)
    c.drawString(250, 730, "GRADE SHEET")
    left = [("Name of Student", name), ("Father's Name", father), ("Mother's Name", mother), ("Date of Birth", dob),
            ("Aadhaar No.", "XXXXXXXX2180")]
    if abc is not None:
        left.append(("ABC ID", abc))
    if reg is not None:
        left.append(("Registration No.", reg))
    left += list(extra or [])
    right = [("Category", "Regular"), ("Programme", "Integrated B. Tech"), ("Semester", "First Semester"),
             ("Year Of Admission", "2024-2025")]
    y = 690
    for i, (label, value) in enumerate(left):
        c.drawString(60, y - i * 18, label)
        c.drawString(165, y - i * 18, f": {value}")
    for i, (label, value) in enumerate(right):
        c.drawString(330, y - i * 18, label)
        c.drawString(430, y - i * 18, f": {value}")
    c.drawString(60, 500, "Course Code   Course Name   Credits   Marks   Grade")
    c.drawString(60, 482, "AIL103        Mathematics   3-0-0     53      C")
    c.save()
    return str(path)


def write_all(folder):
    """The marksheets used by the Meritto tests. Enrollment numbers come from the real 1083 file."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    return {
        # row 8: expected father "S R Sahoo", old value "R S Sahoo" -> PDF still shows the old one
        "sahoo": grade_sheet(folder / "Anisha_Sahoo.pdf", "Anisha Sahoo", "R S Sahoo", "Mamata Sahoo", "01-02-2006",
                             reg="251612400673", abc="111122223333"),
        # row 9: expected "Deep Chand Dayma"; PDF shows "Deepchand Dayma" (old value). No ABC ID on this sheet.
        "dayma": grade_sheet(folder / "Anuj_Dayma.pdf", "Anuj Dayma", "Deepchand Dayma", "Kamla Devi", "03-04-2006",
                             reg="251612400486"),
        # row 10: expected "Banarsi Lal"; PDF now corrected but printed with a title
        "arpan": grade_sheet(folder / "Arpan.pdf", "Arpan", "Mr Banarsi Lal", "Sunita", "05-06-2006", reg="251612400436"),
        # row 11: mother corrected exactly
        "sowmya": grade_sheet(folder / "Ballanki_Sowmya.pdf", "Ballanki Sowmya", "Ballanki Ramesh",
                              "Ballanki Shivalakshmi", "07-08-2006", reg="251612400524"),
        # row 12: father differs from both expected and old value
        "sanjana": grade_sheet(folder / "Kammari_Sanjana.pdf", "Kammari Sanjana", "K Chandra Shekar", "Kammari Laxmi",
                               "09-10-2006", reg="251612400671"),
    }
