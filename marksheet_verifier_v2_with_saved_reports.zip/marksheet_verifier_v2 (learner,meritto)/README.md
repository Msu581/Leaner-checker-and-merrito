# Marksheet Verifier

Two tools in one window:

* **Excel vs Marksheet** (tabs 1-3): compares student details on PDF grade sheets with an Excel/CSV record.
  Rows are paired by **registration number** (or by **ABC ID** when the PDF has no registration number); then name,
  father's name, mother's name, date of birth and ABC ID are compared. A marksheet with no ABC ID is fine: that
  field is simply "Not compared".
* **Meritto vs Marksheet** (tab 4): checks that marksheets now show the value the Meritto/TR record says they
  should (see below).

## Install (once)
    pip install -r requirements.txt
Linux only: `sudo apt install python3-tk` (Windows and macOS already include Tkinter).

## Run
    python main.py                       # opens the GUI
    python main.py cli --excel sample_data/sample_students.xlsx --pdf sample_data --out report.xlsx
    python main.py history --reg 251612400699
    python main.py meritto --excel 1083.xlsx --pdf pdfs/ --out meritto_report.xlsx --strict
    python main.py reports                          # list every stored Excel report
    python main.py reports --get 3 --out copy.xlsx  # get stored report 3 back as a file

Try it with the files in `sample_data/` (a messy Excel sheet plus six PDFs; `make_sample_data.py` recreates them).

## GUI workflow
1. **Setup**: choose the Excel file and add PDFs (files or a whole folder). Columns are auto-detected;
   change any dropdown to override. Adjust the thresholds if needed, then **Run comparison**.
2. **Results**: filter, double-click a row for field-by-field detail, **Export Excel report**.
3. **History**: every run is stored in SQLite (`marksheet_results.db`). Re-open, re-export or delete runs,
   or look up one registration number across all runs.

## Normal and strict mode (both tabs)
Pick the mode under **Name matching mode** (CLI: `--strict`).
* **Normal**: the fuzzy matching described below.
* **Strict**: names are equal only if identical after ignoring case, extra spaces and punctuation.
  `S R Sahoo` is **not** `R S Sahoo`, and `Deep Chand` is **not** `Deepchand`. No partial scores; thresholds unused.
* **Ignore titles (Mr, Smt, Shri...)** works in both modes. Dates and ABC IDs are always compared exactly.

## All sheets
For Excel files with several tabs (e.g. SOT / SOM / SOH) choose **(All sheets)** in the Sheet dropdown (CLI:
`--sheet all`). Tabs are lined up by header text, so columns may sit in different places per tab. Rows are shown as
`SOM!3` (sheet and row). Tabs without recognisable headers (notes, mappings) are skipped.
If the file has separate First Name / Last Name columns, map the **Last name (optional)** field and they are joined.

## Meritto vs Marksheet (tab 4)
1. Choose the Meritto Excel file (e.g. `1083.xlsx`). The header row is found automatically; change it if needed.
2. Add the marksheet PDFs.
3. Check the column dropdowns (all auto-detected, all changeable; the sheet and the last row can be chosen too):
   enrollment no.*, **expected data** (Meritto/TR column; *required), **old value in marksheet** (optional),
   student name, remarks, ABC ID.
4. **Run check.** Each `Label : value` line in the expected-data cell (e.g. `Father's Name : S R Sahoo`) is checked
   against that field in the PDF of the same enrollment number (ABC ID as fallback).

| Result | Meaning |
|---|---|
| Correct / Correct (minor differences) | PDF shows the expected value (minor = normal mode only) |
| Still wrong (same as old value) | PDF still shows the old value from the "old value" column |
| Mismatch / Needs review | PDF shows something else |
| Field not in PDF / PDF not found | nothing to compare (a close enrollment number is suggested) |
| Marks row / Not checked | marks rows, empty cells, fields not on marksheets such as Aadhaar |

Double-click a result to change the field, expected value, PDF, or type the PDF's value by hand. **Re-check** keeps
manual changes. The Excel report has Summary, Results and Needs attention sheets. Exported Meritto reports are stored on the Saved reports tab (see below).

## Saved reports (tab 5)
Every Excel report you export (Setup/Results, History, or the Meritto tab) is also stored in the SQLite database
(`marksheet_results.db`), together with the **date and time it was created**. Turn this off with
"Store a copy of every Excel report in the database" on the Setup tab (CLI: `--no-db`).

| Stored | Where |
|---|---|
| The .xlsx file itself, date/time, type (Learner / Meritto), file name, where it was saved, the Excel that was checked, totals | table `reports` |
| Every Meritto check row (enrollment, field, expected value, PDF value, result, note) | table `meritto_checks` |
| Learner results | tables `runs`, `records`, `field_results` (as before; the report is linked to its run) |

On tab 5: **Open** a stored report, **Save a copy...** to disk, **Delete selected**, select a report to see its rows,
or look up an enrollment number across all saved Meritto reports. Meritto results are therefore now kept too.
Existing databases are upgraded automatically the first time the new version opens them.

## Tests
    pip install -r requirements-dev.txt
    python -m pytest -q tests                 # set MV_REAL_DATA=<folder with real files> for the extra real-file tests

## Fuzzy matching
Names are cleaned (case, punctuation, Mr/Smt/Shri) and scored 0-100:
- 100 = **Match**. Word-order changes, spacing differences and initials ("A. K. Sharma") score 95-98.
- **>= close-match threshold** (default 92) = **Close match**, accepted automatically.
- **>= review threshold** (default 75) = **Review**, check by hand. Below that = **Mismatch**.

Dates are parsed (dd-mm-yyyy, 5 Jul 2006, Excel dates, serial numbers) and compared as dates.
Swapped day/month is flagged for review. Date of birth never uses fuzzy scoring.

## Excel report sheets
Summary (live COUNTIF totals, mapping, settings) | Comparison (colour-coded, filterable) |
Needs attention (one row per problem, with a reviewer-decision dropdown) | Unmatched Excel.

## Scanned PDFs (optional)
Install the Tesseract program, `pip install pytesseract`, and tick "Use OCR" before adding the PDFs.
OCR is best-effort: always check values it reads (double-click a PDF row to correct it).
