"""
storage.py - SQLite storage for comparison runs.

Tables
  runs             one row per comparison run (files, mapping, settings, totals)
  records          one row per PDF record in a run
  field_results    one row per compared field of a record
  unmatched_excel  Excel rows that had no PDF
  reports          every Excel report that was created: date/time, type, file name and the .xlsx file itself
  meritto_checks   one row per check of a saved Meritto report (so the data can be searched later)
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path

from core import (COMPARE_FIELDS, OV_MINOR, OV_MISMATCH, OV_NOREG, OV_NOTFOUND, OV_REVIEW, OV_VERIFIED,
                  FieldResult, PdfRecord, RecordResult, RunResult)

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    excel_file TEXT, sheet TEXT, header_row INTEGER,
    mapping TEXT, settings TEXT,
    pdf_count INTEGER,
    n_verified INTEGER, n_review INTEGER, n_mismatch INTEGER, n_notfound INTEGER
);
CREATE TABLE IF NOT EXISTS records(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
    pdf_file TEXT, pdf_path TEXT, page INTEGER, pages INTEGER, source TEXT,
    pdf_reg TEXT, excel_row INTEGER, overall TEXT, note TEXT
);
CREATE TABLE IF NOT EXISTS field_results(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    record_id INTEGER NOT NULL REFERENCES records(id) ON DELETE CASCADE,
    field TEXT, pdf_value TEXT, excel_value TEXT, status TEXT, score REAL, note TEXT
);
CREATE TABLE IF NOT EXISTS unmatched_excel(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id INTEGER NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
    excel_row INTEGER, reg TEXT, name TEXT
);
CREATE TABLE IF NOT EXISTS reports(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,           -- date and time the Excel report was created
    kind TEXT NOT NULL,                 -- 'Learner' or 'Meritto'
    file_name TEXT NOT NULL,            -- e.g. verification_report_20261007_1530.xlsx
    saved_to TEXT,                      -- full path where the report was written on disk
    source_excel TEXT,                  -- the Excel file that was checked
    run_id INTEGER REFERENCES runs(id) ON DELETE SET NULL,   -- Learner run, when it was saved
    summary TEXT,                       -- short totals, e.g. "Verified 3, Review 2, ..."
    size_bytes INTEGER,
    data BLOB NOT NULL                  -- the .xlsx file itself
);
CREATE TABLE IF NOT EXISTS meritto_checks(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    report_id INTEGER NOT NULL REFERENCES reports(id) ON DELETE CASCADE,
    excel_row TEXT, enrollment TEXT, student TEXT, field TEXT, label TEXT,
    expected TEXT, claimed TEXT, pdf_file TEXT, pdf_value TEXT,
    status TEXT, score REAL, note TEXT, manual TEXT
);
CREATE INDEX IF NOT EXISTS idx_reports_created ON reports(created_at);
CREATE INDEX IF NOT EXISTS idx_mchecks_report ON meritto_checks(report_id);
CREATE INDEX IF NOT EXISTS idx_mchecks_enroll ON meritto_checks(enrollment);
CREATE INDEX IF NOT EXISTS idx_records_run ON records(run_id);
CREATE INDEX IF NOT EXISTS idx_records_reg ON records(pdf_reg);
CREATE INDEX IF NOT EXISTS idx_fields_record ON field_results(record_id);
"""


def learner_summary(result) -> str:
    c = result.counts()
    return (f"{len(result.records)} records: Verified {c[OV_VERIFIED] + c[OV_MINOR]}, Review {c[OV_REVIEW]}, "
            f"Mismatch {c[OV_MISMATCH]}, Not found {c[OV_NOTFOUND] + c[OV_NOREG]}")


class Database:
    def __init__(self, path):
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.con = sqlite3.connect(self.path)
        self.con.row_factory = sqlite3.Row
        self.con.execute("PRAGMA foreign_keys = ON")
        self.con.executescript(SCHEMA)

    def close(self):
        self.con.close()

    # ---- write -----------------------------------------------------------
    def save_run(self, info: dict, result: RunResult) -> int:
        c = result.counts()
        with self.con:
            cur = self.con.execute(
                "INSERT INTO runs(created_at, excel_file, sheet, header_row, mapping, settings, pdf_count,"
                " n_verified, n_review, n_mismatch, n_notfound) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (info.get("created_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                 info.get("excel_file", ""), info.get("sheet", ""), info.get("header_row", 0),
                 json.dumps(info.get("mapping", {})), json.dumps(info.get("settings", {})),
                 len(result.records),
                 c[OV_VERIFIED] + c[OV_MINOR], c[OV_REVIEW], c[OV_MISMATCH], c[OV_NOTFOUND] + c[OV_NOREG]))
            run_id = cur.lastrowid
            for r in result.records:
                cur = self.con.execute(
                    "INSERT INTO records(run_id, pdf_file, pdf_path, page, pages, source, pdf_reg, excel_row, overall, note)"
                    " VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (run_id, r.pdf.file, r.pdf.path, r.pdf.page, r.pdf.pages, r.pdf.source,
                     r.pdf.fields.get("reg", ""), r.excel_row, r.overall, r.note))
                rid = cur.lastrowid
                if r.fields:
                    self.con.executemany(
                        "INSERT INTO field_results(record_id, field, pdf_value, excel_value, status, score, note)"
                        " VALUES(?,?,?,?,?,?,?)",
                        [(rid, f.field, f.pdf_value, f.excel_value, f.status, f.score, f.note) for f in r.fields.values()])
                else:  # not paired: keep what the PDF said
                    self.con.executemany(
                        "INSERT INTO field_results(record_id, field, pdf_value, excel_value, status, score, note)"
                        " VALUES(?,?,?,?,?,?,?)",
                        [(rid, k, r.pdf.fields.get(k, ""), "", "Not compared", None, "") for k in ["reg"] + COMPARE_FIELDS])
            self.con.executemany(
                "INSERT INTO unmatched_excel(run_id, excel_row, reg, name) VALUES(?,?,?,?)",
                [(run_id, u["row"], u["reg"], u["name"]) for u in result.unmatched_excel])
        return run_id

    def delete_run(self, run_id: int):
        with self.con:
            self.con.execute("DELETE FROM runs WHERE id=?", (run_id,))

    # ---- read ------------------------------------------------------------
    def list_runs(self):
        return [dict(r) for r in self.con.execute("SELECT * FROM runs ORDER BY id DESC")]

    def load_run(self, run_id: int):
        """Return (info dict, RunResult) rebuilt from the database."""
        row = self.con.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
        if row is None:
            raise KeyError(f"No run with id {run_id}")
        info = dict(row)
        info["mapping"] = json.loads(info["mapping"] or "{}")
        info["settings"] = json.loads(info["settings"] or "{}")
        records = []
        for r in self.con.execute("SELECT * FROM records WHERE run_id=? ORDER BY id", (run_id,)):
            frs = {}
            for f in self.con.execute("SELECT * FROM field_results WHERE record_id=? ORDER BY id", (r["id"],)):
                frs[f["field"]] = FieldResult(f["field"], f["pdf_value"] or "", f["excel_value"] or "",
                                              f["status"], f["score"], f["note"] or "")
            pdf_fields = {k: v.pdf_value for k, v in frs.items() if v.pdf_value}
            pdf = PdfRecord(r["pdf_file"], r["pdf_path"] or "", r["page"], r["pages"] or 1, pdf_fields, r["source"] or "text")
            if r["overall"] in (OV_NOTFOUND, OV_NOREG):
                frs = {}
            records.append(RecordResult(pdf, r["overall"], r["excel_row"], frs, r["note"] or ""))
        unmatched = [{"row": u["excel_row"], "reg": u["reg"], "name": u["name"]}
                     for u in self.con.execute("SELECT * FROM unmatched_excel WHERE run_id=? ORDER BY id", (run_id,))]
        return info, RunResult(records, unmatched)

    # ---- Excel reports -----------------------------------------------------
    def save_report(self, kind: str, path, info: dict | None = None, run_id: int | None = None,
                    summary: str = "", checks=None) -> int:
        """Store a written .xlsx report (the file itself plus its date/time) and return its id.

        kind is 'Learner' or 'Meritto'. For Meritto reports pass the checks so every row is stored too."""
        path = Path(path)
        data = path.read_bytes()
        info = info or {}
        with self.con:
            cur = self.con.execute(
                "INSERT INTO reports(created_at, kind, file_name, saved_to, source_excel, run_id, summary, size_bytes, data)"
                " VALUES(?,?,?,?,?,?,?,?,?)",
                (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), kind, path.name, str(path.resolve()),
                 info.get("excel_file", ""), run_id, summary, len(data), sqlite3.Binary(data)))
            report_id = cur.lastrowid
            if checks:
                self.con.executemany(
                    "INSERT INTO meritto_checks(report_id, excel_row, enrollment, student, field, label, expected, claimed,"
                    " pdf_file, pdf_value, status, score, note, manual) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    [(report_id, str(c.excel_row), c.enrollment, c.student, c.field or "", c.label, c.expected, c.claimed,
                      c.pdf_file, c.pdf_value, c.status, c.score, c.note, "; ".join(c.manual)) for c in checks])
        return report_id

    def list_reports(self):
        """All saved reports, newest first (without the file bytes)."""
        return [dict(r) for r in self.con.execute(
            "SELECT id, created_at, kind, file_name, saved_to, source_excel, run_id, summary, size_bytes"
            " FROM reports ORDER BY id DESC")]

    def report_file(self, report_id: int):
        """Return (file_name, bytes) of a saved report."""
        row = self.con.execute("SELECT file_name, data FROM reports WHERE id=?", (report_id,)).fetchone()
        if row is None:
            raise KeyError(f"No report with id {report_id}")
        return row["file_name"], bytes(row["data"])

    def report_checks(self, report_id: int):
        return [dict(r) for r in self.con.execute(
            "SELECT * FROM meritto_checks WHERE report_id=? ORDER BY id", (report_id,))]

    def delete_report(self, report_id: int):
        with self.con:
            self.con.execute("DELETE FROM reports WHERE id=?", (report_id,))

    def meritto_history_for_enrollment(self, enrollment: str):
        """Every saved Meritto check for one enrollment number, newest first."""
        q = ("SELECT r.id AS report_id, r.created_at, r.file_name, m.excel_row, m.field, m.label, m.expected,"
             " m.pdf_value, m.status, m.note FROM meritto_checks m JOIN reports r ON r.id = m.report_id"
             " WHERE m.enrollment = ? ORDER BY r.id DESC, m.id")
        return [dict(x) for x in self.con.execute(q, (enrollment,))]

    def history_for_reg(self, reg: str):
        """Every past result for one registration number, newest first."""
        q = ("SELECT r.id AS run_id, r.created_at, r.excel_file, rec.pdf_file, rec.excel_row, rec.overall, rec.note "
             "FROM records rec JOIN runs r ON r.id = rec.run_id WHERE rec.pdf_reg = ? ORDER BY r.id DESC")
        return [dict(x) for x in self.con.execute(q, (reg,))]
