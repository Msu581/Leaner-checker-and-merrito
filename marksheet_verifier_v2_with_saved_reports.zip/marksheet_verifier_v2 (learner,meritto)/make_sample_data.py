"""Creates sample_data/sample_students.xlsx (deliberately messy layout) and extra test PDFs."""
from pathlib import Path
from openpyxl import Workbook
import datetime as dt

out = Path(__file__).parent / "sample_data"
out.mkdir(exist_ok=True)

wb = Workbook()
ws = wb.active
ws.title = "Batch 2025-26"
ws["A1"] = "Medhavi Skills University - BVoc AOTT batch 2025-26"
ws["A2"] = "Exported from student records"
ws.append([])
ws.append(["S.No", "Candidate", "Enrolment / Regd. No", "Mother", "Father Name", "D.O.B", "Programme"])
rows = [
    (1, "ABDUL SAMAD", 251612400699, "Habeeba Begum", "Abdul Satar", dt.date(2006, 7, 5), "BVoc AOTT"),      # father typo
    (2, "Priya Sharma", 251612400700, "Sunita Sharma", "Rakesh Sharma", dt.date(2005, 11, 12), "BVoc AOTT"),
    (3, "Rohan Das", 251612400701, "Mitali Das", "Biswajit Das", "02/03/2006", "BVoc AOTT"),               # DOB day/month swapped vs PDF
    (4, "Mohd. Imran", 251612400702, "Shabana Khan", "Mohammad Yusuf", dt.date(2006, 1, 20), "BVoc AOTT"),
    (5, "Anita Kumari", 251612400703, "Geeta Devi", "Ramesh Prasad", dt.date(2006, 9, 9), "BVoc AOTT"),
    (6, "Not Yet Submitted", 251612400799, "Someone", "Someone Else", dt.date(2006, 1, 1), "BVoc AOTT"),    # no PDF
]
for r in rows:
    ws.append(list(r))
for c in ws["F"][4:]:
    if isinstance(c.value, dt.date):
        c.number_format = "DD-MM-YYYY"
wb.save(out / "sample_students.xlsx")
print("wrote", out / "sample_students.xlsx")

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
except ImportError:
    raise SystemExit("reportlab not installed - skipping extra PDFs (pip install reportlab)")

pdfs = [
    ("Priya_Sharma.pdf", "Priya Sharma", "Rakesh Sharma", "Sunita Sharma", "12-11-2005", "251612400700"),
    ("Rohan_Das.pdf", "Rohan Das", "Biswajit Das", "Mitali Das", "03-02-2006", "251612400701"),
    ("Imran.pdf", "Mohammad Imran", "Mohammad Yusuf", "Shabana Khan", "20-01-2006", "251612400702"),
    ("Anita_Kumari.pdf", "Anita Kumari", "Ramesh Prashad", "Geeta Devi", "09-09-2006", "251612400703"),
    ("Unknown_Student.pdf", "Vikram Rao", "Suresh Rao", "Lata Rao", "04-04-2006", "251612400755"),
]
for fn, name, father, mother, dob, reg in pdfs:
    c = canvas.Canvas(str(out / fn), pagesize=A4)
    c.setFont("Helvetica-Bold", 16)
    c.drawString(150, 790, "MEDHAVI SKILLS UNIVERSITY, SIKKIM")
    c.drawString(250, 760, "GRADE SHEET")
    c.setFont("Helvetica", 10)
    left = [("Name of Student", name), ("Father's Name", father), ("Mother's Name", mother), ("Date of Birth", dob)]
    y = 720
    for k, v in left:
        c.drawString(50, y, k); c.drawString(150, y, ": " + v); y -= 22
    right = [("Category", "Regular"), ("Programme", "Bachelor of Vocation"), ("Registration No.", reg), ("Semester", "First Semester")]
    y = 720
    for k, v in right:
        c.drawString(330, y, k); c.drawString(430, y, ": " + v); y -= 22
    c.save()
print("wrote", len(pdfs), "extra PDFs")
