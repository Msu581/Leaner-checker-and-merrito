"""
gui.py - Tkinter interface for the marksheet verifier.

Tabs:  1 Setup (files, column mapping, settings)  |  2 Results  |  3 History (database)
       4 Meritto vs Marksheet (see gui_meritto.py)  |  5 Saved reports (every Excel report, stored in the database)
"""
from __future__ import annotations

import os
import queue
import subprocess
import sys
import tempfile
import threading
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import core
from core import (ALL_SHEETS, COMPARE_FIELDS, FIELDS, MAP_FIELDS, MAP_LABELS, MODE_NORMAL, MODE_STRICT, OV_MINOR,
                  OV_MISMATCH, OV_NOREG, OV_NOTFOUND, OV_REVIEW, OV_VERIFIED, ST_SKIPPED, Settings, col_letter)
from report import build_report
from storage import Database, learner_summary

DEFAULT_DB = Path(__file__).with_name("marksheet_results.db")
NOT_MAPPED = "(not mapped)"
MODES = {"Normal (fuzzy)": MODE_NORMAL, "Strict (exact)": MODE_STRICT}
FILTERS = ["All", "Verified", "Needs review", "Mismatch / not found"]
TAG_COLORS = {"ok": "#DFF2E4", "minor": "#EAF3DC", "review": "#FBF0C9", "bad": "#F8D9D5"}
CONF_COLORS = {"high": "#2E7A4D", "medium": "#93600E", "low": "#B03A2E", "manual": "#0F5E6E", "none": "#777777"}


def overall_tag(ov):
    return {OV_VERIFIED: "ok", OV_MINOR: "minor", OV_REVIEW: "review"}.get(ov, "bad")


def meritto_tag(status):
    if status in ("Correct",):
        return "ok"
    if status == "Correct (minor differences)":
        return "minor"
    if status in ("Needs review", "Field not in PDF"):
        return "review"
    if status in ("Still wrong (same as old value)", "Mismatch", "PDF not found"):
        return "bad"
    return ""


def short_status(f):
    if f is None or f.status == ST_SKIPPED:
        return "-"
    return f.status if f.score is None or f.field == "dob" or f.status in ("Match", "Missing") else f"{f.status} {f.score:.0f}%"


def open_file(path):
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception:
        pass


class ScrollFrame(ttk.Frame):
    """A frame whose content (built in .inner) scrolls vertically when the window is too short.
    When everything fits, .inner simply fills the frame, so stretchy layouts behave as before."""

    def __init__(self, master, **inner_kw):
        super().__init__(master)
        bg = ttk.Style(self).lookup("TFrame", "background") or None
        self.canvas = tk.Canvas(self, highlightthickness=0, borderwidth=0, background=bg)
        self.vs = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas, **inner_kw)
        self._win = self.canvas.create_window(0, 0, window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=self.vs.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.inner.bind("<Configure>", self._fit)
        self.canvas.bind("<Configure>", self._fit)
        self.canvas.bind("<Enter>", lambda e: self._wheel_bind(True))
        self.canvas.bind("<Leave>", lambda e: self._wheel_bind(False))

    def _fit(self, _event=None):
        c, need = self.canvas, self.inner.winfo_reqheight()
        h = max(need, c.winfo_height())
        c.itemconfigure(self._win, width=c.winfo_width(), height=h)
        c.configure(scrollregion=(0, 0, c.winfo_width(), h))
        if need > c.winfo_height() + 1:
            self.vs.grid(row=0, column=1, sticky="ns")
        else:
            self.vs.grid_remove()
            c.yview_moveto(0)

    def _wheel_bind(self, on):
        for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            if on:
                self.canvas.bind_all(seq, self._wheel)
            else:
                self.canvas.unbind_all(seq)

    def _wheel(self, e):
        if isinstance(e.widget, (ttk.Treeview, tk.Listbox)) or not self.vs.winfo_ismapped():
            return  # lists scroll themselves
        step = -1 if (getattr(e, "num", 0) == 4 or getattr(e, "delta", 0) > 0) else 1
        self.canvas.yview_scroll(step, "units")


class App(tk.Tk):
    def __init__(self, db_path=DEFAULT_DB):
        super().__init__()
        self.title("Marksheet Verifier: Excel vs PDF")
        self.geometry(f"1260x{min(860, self.winfo_screenheight() - 90)}")
        self.minsize(1020, 640)
        self.db = Database(db_path)

        self.sheet: core.SheetData | None = None
        self.header_row = -1
        self.pdf_records: list[core.PdfRecord] = []
        self.seen_pdfs: set[str] = set()
        self.guesses = {k: core.ColumnGuess() for k, _ in MAP_FIELDS}
        self.manual: dict[str, int] = {}
        self.result: core.RunResult | None = None
        self.run_info: dict | None = None
        self.shown_results: list = []

        self.v_sheet = tk.StringVar()
        self.v_header = tk.IntVar(value=0)
        self.v_dateorder = tk.StringVar(value="Day-Month-Year")
        self.v_match = tk.IntVar(value=92)
        self.v_review = tk.IntVar(value=75)
        self.v_titles = tk.BooleanVar(value=True)
        self.v_mode = tk.StringVar(value=next(iter(MODES)))
        self.v_ocr = tk.BooleanVar(value=False)
        self.v_save = tk.BooleanVar(value=True)
        self.v_save_reports = tk.BooleanVar(value=True)
        self.v_filter = tk.StringVar(value=FILTERS[0])
        self.v_status = tk.StringVar(value="Add an Excel file and your PDF marksheets to begin.")
        self.map_vars = {k: tk.StringVar(value=NOT_MAPPED) for k, _ in MAP_FIELDS}

        self._style()
        self._menu()
        self._build()
        self.protocol("WM_DELETE_WINDOW", self._quit)
        self.refresh_history()
        self.refresh_reports()

    # ------------------------------------------------------------------ layout
    def _style(self):
        st = ttk.Style(self)
        if "clam" in st.theme_names() and sys.platform.startswith("linux"):
            st.theme_use("clam")
        st.configure("Treeview", rowheight=24)
        st.configure("Big.TButton", font=("TkDefaultFont", 11, "bold"), padding=8)
        st.configure("Head.TLabel", font=("TkDefaultFont", 10, "bold"))
        st.configure("Hint.TLabel", foreground="#5A6B71")

    def _menu(self):
        m = tk.Menu(self)
        f = tk.Menu(m, tearoff=0)
        f.add_command(label="Open Excel file...", command=self.browse_excel)
        f.add_command(label="Add PDF files...", command=self.browse_pdfs)
        f.add_command(label="Add PDF folder...", command=self.browse_folder)
        f.add_separator()
        f.add_command(label="Export Excel report...", command=self.export_report)
        f.add_command(label="Choose database file...", command=self.choose_db)
        f.add_separator()
        f.add_command(label="Quit", command=self._quit)
        m.add_cascade(label="File", menu=f)
        self.config(menu=m)

    def _build(self):
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=8, pady=(8, 0))
        self.s_setup = ScrollFrame(self.nb, padding=8)
        self.t_setup = self.s_setup.inner
        self.t_results, self.t_hist = (ttk.Frame(self.nb, padding=8) for _ in range(2))
        self.nb.add(self.s_setup, text="  1  Setup  ")
        self.nb.add(self.t_results, text="  2  Results  ")
        self.nb.add(self.t_hist, text="  3  History  ")
        self._build_setup()
        self._build_results()
        self._build_history()
        from gui_meritto import MerittoTab  # imported here, not at the top: gui_meritto imports gui
        self.s_meritto = ScrollFrame(self.nb)
        self.t_meritto = MerittoTab(self.s_meritto.inner, self)
        self.t_meritto.pack(fill="both", expand=True)
        self.nb.add(self.s_meritto, text="  4  Meritto vs Marksheet  ")
        self.t_reports = ttk.Frame(self.nb, padding=8)
        self.nb.add(self.t_reports, text="  5  Saved reports  ")
        self._build_reports()
        bar = ttk.Frame(self, padding=(10, 4))
        bar.pack(side="bottom", fill="x", before=self.nb)  # packed first, so a short window never hides it
        ttk.Label(bar, textvariable=self.v_status).pack(side="left")
        self.progress = ttk.Progressbar(bar, mode="indeterminate", length=140)
        ttk.Label(bar, text=f"Database: {self.db.path}", style="Hint.TLabel").pack(side="right")

    # ---- setup tab
    def _build_setup(self):
        t = self.t_setup
        t.columnconfigure(0, weight=1)
        t.columnconfigure(1, weight=1)
        t.rowconfigure(1, weight=1)

        # Excel box
        ex = ttk.LabelFrame(t, text="Excel / CSV file", padding=8)
        ex.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=(0, 6))
        ex.columnconfigure(1, weight=1)
        self.l_excel = ttk.Label(ex, text="No file chosen", style="Hint.TLabel")
        self.l_excel.grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Button(ex, text="Choose Excel file...", command=self.browse_excel).grid(row=1, column=0, pady=6, sticky="w")
        ttk.Label(ex, text="Sheet").grid(row=1, column=1, sticky="e", padx=(10, 4))
        self.cb_sheet = ttk.Combobox(ex, textvariable=self.v_sheet, state="readonly", width=22)
        self.cb_sheet.grid(row=1, column=2, sticky="w")
        self.cb_sheet.bind("<<ComboboxSelected>>", lambda e: self.change_sheet())
        ttk.Label(ex, text="Header row (0 = none)").grid(row=2, column=0, sticky="w")
        sp = ttk.Spinbox(ex, from_=0, to=500, width=6, textvariable=self.v_header, command=self.change_header)
        sp.grid(row=2, column=1, sticky="w", padx=(10, 0))
        sp.bind("<Return>", lambda e: self.change_header())
        sp.bind("<FocusOut>", lambda e: self.change_header())

        # Settings box
        se = ttk.LabelFrame(t, text="Matching settings", padding=8)
        se.grid(row=0, column=1, sticky="nsew", padx=(6, 0), pady=(0, 6))
        se.columnconfigure(1, weight=1)
        ttk.Label(se, text="Name matching mode").grid(row=0, column=0, sticky="w")
        cm = ttk.Combobox(se, textvariable=self.v_mode, state="readonly", width=18, values=list(MODES))
        cm.grid(row=0, column=1, sticky="w", padx=8)
        cm.bind("<<ComboboxSelected>>", lambda e: self._thresh("match"))
        ttk.Label(se, text="Ambiguous dates (05-07-2006)").grid(row=1, column=0, sticky="w")
        cb = ttk.Combobox(se, textvariable=self.v_dateorder, state="readonly", width=18,
                          values=["Day-Month-Year", "Month-Day-Year"])
        cb.grid(row=1, column=1, sticky="w", padx=8)
        cb.bind("<<ComboboxSelected>>", lambda e: self.run_detect())

        self.l_match = ttk.Label(se, width=5)
        self.l_review = ttk.Label(se, width=5)
        ttk.Label(se, text="Close-match threshold").grid(row=2, column=0, sticky="w", pady=(8, 0))
        ttk.Scale(se, from_=50, to=100, variable=self.v_match, command=lambda v: self._thresh("match")).grid(
            row=2, column=1, sticky="ew", padx=8, pady=(8, 0))
        self.l_match.grid(row=2, column=2, pady=(8, 0))
        ttk.Label(se, text="Review threshold").grid(row=3, column=0, sticky="w")
        ttk.Scale(se, from_=30, to=100, variable=self.v_review, command=lambda v: self._thresh("review")).grid(
            row=3, column=1, sticky="ew", padx=8)
        self.l_review.grid(row=3, column=2)
        self.l_thresh_help = ttk.Label(se, style="Hint.TLabel", wraplength=470, justify="left")
        self.l_thresh_help.grid(row=4, column=0, columnspan=3, sticky="w", pady=(4, 4))
        ttk.Checkbutton(se, text="Ignore titles (Mr, Smt, Shri...) in names", variable=self.v_titles).grid(
            row=5, column=0, columnspan=3, sticky="w")
        ttk.Checkbutton(se, text="Use OCR for scanned PDFs (needs Tesseract)", variable=self.v_ocr).grid(
            row=6, column=0, columnspan=3, sticky="w")
        ttk.Checkbutton(se, text="Save each run to the database", variable=self.v_save).grid(
            row=7, column=0, columnspan=3, sticky="w")
        ttk.Checkbutton(se, text="Store a copy of every Excel report in the database (both tabs)",
                        variable=self.v_save_reports).grid(row=8, column=0, columnspan=3, sticky="w")
        self._thresh("match")

        # Mapping + preview
        mp = ttk.LabelFrame(t, text="Column mapping (auto-detected; change any dropdown to override)", padding=8)
        mp.grid(row=1, column=0, sticky="nsew", padx=(0, 6))
        mp.columnconfigure(1, weight=1)
        self.cb_map, self.l_conf, self.l_samp = {}, {}, {}
        for i, (key, label) in enumerate(MAP_FIELDS):
            ttk.Label(mp, text=label + (" *" if key == "reg" else ""), style="Head.TLabel").grid(row=i * 2, column=0, sticky="w", pady=(4, 0))
            cb = ttk.Combobox(mp, textvariable=self.map_vars[key], state="readonly", width=32, values=[NOT_MAPPED])
            cb.grid(row=i * 2, column=1, sticky="ew", padx=8, pady=(4, 0))
            cb.bind("<<ComboboxSelected>>", lambda e, k=key: self.on_map(k))
            self.cb_map[key] = cb
            self.l_conf[key] = ttk.Label(mp, text="Not found")
            self.l_conf[key].grid(row=i * 2, column=2, sticky="w", pady=(4, 0))
            self.l_samp[key] = ttk.Label(mp, text="", style="Hint.TLabel")
            self.l_samp[key].grid(row=i * 2 + 1, column=1, columnspan=2, sticky="w", padx=8)
        row = ttk.Frame(mp)
        row.grid(row=len(MAP_FIELDS) * 2, column=0, columnspan=3, sticky="w", pady=(8, 0))
        ttk.Button(row, text="Auto-detect again", command=lambda: self.run_detect(keep_manual=True)).pack(side="left")
        ttk.Button(row, text="Reset to auto-detect", command=lambda: self.run_detect(keep_manual=False)).pack(side="left", padx=6)
        ttk.Label(mp, text="* The registration number pairs each PDF with its Excel row (ABC ID if the PDF has no reg. no.).",
                  style="Hint.TLabel").grid(row=len(MAP_FIELDS) * 2 + 1, column=0, columnspan=3, sticky="w", pady=(6, 0))

        # PDF list
        pf = ttk.LabelFrame(t, text="PDF marksheets (double-click a row to correct what was read)", padding=8)
        pf.grid(row=1, column=1, sticky="nsew", padx=(6, 0))
        pf.columnconfigure(0, weight=1)
        pf.rowconfigure(1, weight=1)
        bt = ttk.Frame(pf)
        bt.grid(row=0, column=0, sticky="w", pady=(0, 6))
        ttk.Button(bt, text="Add PDFs...", command=self.browse_pdfs).pack(side="left")
        ttk.Button(bt, text="Add folder...", command=self.browse_folder).pack(side="left", padx=6)
        ttk.Button(bt, text="Remove selected", command=self.remove_pdfs).pack(side="left")
        ttk.Button(bt, text="Clear all", command=self.clear_pdfs).pack(side="left", padx=6)
        cols = ("file", "page", "reg", "abc", "name", "father", "mother", "dob")
        self.tv_pdf = ttk.Treeview(pf, columns=cols, show="headings", selectmode="extended")
        for c, w, txt in [("file", 150, "File"), ("page", 40, "Pg"), ("reg", 110, "Reg. no."), ("abc", 100, "ABC ID"), ("name", 110, "Name"),
                          ("father", 100, "Father"), ("mother", 100, "Mother"), ("dob", 80, "DOB")]:
            self.tv_pdf.heading(c, text=txt)
            self.tv_pdf.column(c, width=w, minwidth=40, stretch=c in ("file", "name"))
        ys = ttk.Scrollbar(pf, orient="vertical", command=self.tv_pdf.yview)
        xs = ttk.Scrollbar(pf, orient="horizontal", command=self.tv_pdf.xview)
        self.tv_pdf.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        self.tv_pdf.grid(row=1, column=0, sticky="nsew")
        ys.grid(row=1, column=1, sticky="ns")
        xs.grid(row=2, column=0, sticky="ew")
        self.tv_pdf.bind("<Double-1>", self.edit_pdf)
        self.tv_pdf.tag_configure("bad", background=TAG_COLORS["bad"])

        # Preview
        pv = ttk.LabelFrame(t, text="Excel preview (mapped columns are named in the heading)", padding=6)
        pv.grid(row=2, column=0, columnspan=2, sticky="nsew", pady=(6, 0))
        pv.columnconfigure(0, weight=1)
        self.pv_frame = pv
        self.tv_prev = None
        self._reset_preview()

        go = ttk.Frame(t)
        go.grid(row=3, column=0, columnspan=2, sticky="e", pady=(8, 0))
        ttk.Button(go, text="Run comparison", style="Big.TButton", command=self.run_compare).pack(side="right")

    def _reset_preview(self):
        if self.tv_prev is not None:
            self.tv_prev.destroy()
            for w in getattr(self, "_prev_bars", []):
                w.destroy()
        self.tv_prev = ttk.Treeview(self.pv_frame, columns=("row",), show="headings", height=4)
        self.tv_prev.heading("row", text="Row")
        self.tv_prev.column("row", width=44, stretch=False)
        xs = ttk.Scrollbar(self.pv_frame, orient="horizontal", command=self.tv_prev.xview)
        self.tv_prev.configure(xscrollcommand=xs.set)
        self.tv_prev.grid(row=0, column=0, sticky="ew")
        xs.grid(row=1, column=0, sticky="ew")
        self._prev_bars = [xs]
        self.tv_prev.tag_configure("hdr", background="#E0EDEF", font=("TkDefaultFont", 9, "bold"))

    # ---- results tab
    def _build_results(self):
        t = self.t_results
        t.columnconfigure(0, weight=1)
        t.rowconfigure(2, weight=1)
        self.f_tally = ttk.Frame(t)
        self.f_tally.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        self.tally_lbl = {}
        for i, (key, text, color) in enumerate([("all", "Records", "#16262C"), (OV_VERIFIED, "Verified", "#2E7A4D"),
                                               (OV_REVIEW, "Need review", "#93600E"), (OV_MISMATCH, "Mismatch", "#B03A2E"),
                                               ("nf", "Not in Excel / no reg. no.", "#B03A2E")]):
            box = ttk.Frame(self.f_tally, padding=(0, 0, 28, 0))
            box.pack(side="left")
            n = tk.Label(box, text="0", font=("TkDefaultFont", 22, "bold"), fg=color)
            n.pack(anchor="w")
            ttk.Label(box, text=text, style="Hint.TLabel").pack(anchor="w")
            self.tally_lbl[key] = n
        bar = ttk.Frame(t)
        bar.grid(row=1, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(bar, text="Show").pack(side="left")
        cb = ttk.Combobox(bar, textvariable=self.v_filter, values=FILTERS, state="readonly", width=22)
        cb.pack(side="left", padx=6)
        cb.bind("<<ComboboxSelected>>", lambda e: self.fill_results())
        ttk.Button(bar, text="Re-run with current settings", command=self.run_compare).pack(side="left", padx=(12, 0))
        ttk.Button(bar, text="Export Excel report...", command=self.export_report).pack(side="right")
        ttk.Label(bar, text="Double-click a row for details", style="Hint.TLabel").pack(side="right", padx=12)

        cols = ("n", "file", "reg", "row", "overall", "name", "father", "mother", "dob", "abc")
        self.tv_res = ttk.Treeview(t, columns=cols, show="headings", selectmode="browse")
        for c, w, txt in [("n", 36, "#"), ("file", 190, "PDF file"), ("reg", 120, "Reg. no."), ("row", 82, "Excel row"),
                          ("overall", 170, "Overall"), ("name", 130, "Name"), ("father", 130, "Father"),
                          ("mother", 130, "Mother"), ("dob", 110, "DOB"), ("abc", 110, "ABC ID")]:
            self.tv_res.heading(c, text=txt)
            self.tv_res.column(c, width=w, minwidth=36, stretch=c in ("file", "overall"))
        for tag, col in TAG_COLORS.items():
            self.tv_res.tag_configure(tag, background=col)
        ys = ttk.Scrollbar(t, orient="vertical", command=self.tv_res.yview)
        self.tv_res.configure(yscrollcommand=ys.set)
        self.tv_res.grid(row=2, column=0, sticky="nsew")
        ys.grid(row=2, column=1, sticky="ns")
        self.tv_res.bind("<Double-1>", self.open_detail)
        self.l_unmatched = ttk.Label(t, text="", style="Hint.TLabel")
        self.l_unmatched.grid(row=3, column=0, sticky="w", pady=(6, 0))

    # ---- history tab
    def _build_history(self):
        t = self.t_hist
        t.columnconfigure(0, weight=1)
        t.rowconfigure(1, weight=1)
        t.rowconfigure(3, weight=1)
        bar = ttk.Frame(t)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        for txt, cmd in [("View in Results", self.hist_view), ("Export selected to Excel...", self.hist_export),
                         ("Delete selected", self.hist_delete), ("Refresh", self.refresh_history)]:
            ttk.Button(bar, text=txt, command=cmd).pack(side="left", padx=(0, 6))
        cols = ("id", "when", "excel", "pdfs", "ok", "review", "bad", "nf")
        self.tv_hist = ttk.Treeview(t, columns=cols, show="headings", selectmode="browse")
        for c, w, txt in [("id", 44, "Run"), ("when", 150, "Date"), ("excel", 280, "Excel file"), ("pdfs", 60, "PDFs"),
                          ("ok", 80, "Verified"), ("review", 90, "Need review"), ("bad", 80, "Mismatch"), ("nf", 90, "Not found")]:
            self.tv_hist.heading(c, text=txt)
            self.tv_hist.column(c, width=w, minwidth=40, stretch=c == "excel")
        self.tv_hist.grid(row=1, column=0, sticky="nsew")
        ys = ttk.Scrollbar(t, orient="vertical", command=self.tv_hist.yview)
        self.tv_hist.configure(yscrollcommand=ys.set)
        ys.grid(row=1, column=1, sticky="ns")
        self.tv_hist.bind("<<TreeviewSelect>>", lambda e: self.hist_preview())
        self.tv_hist.bind("<Double-1>", lambda e: self.hist_view())
        sb = ttk.Frame(t)
        sb.grid(row=2, column=0, sticky="ew", pady=(8, 4))
        ttk.Label(sb, text="Look up a registration number across all runs:").pack(side="left")
        self.v_lookup = tk.StringVar()
        e = ttk.Entry(sb, textvariable=self.v_lookup, width=22)
        e.pack(side="left", padx=6)
        e.bind("<Return>", lambda ev: self.hist_lookup())
        ttk.Button(sb, text="Find", command=self.hist_lookup).pack(side="left")
        self.tv_hrec = ttk.Treeview(t, columns=("a", "b", "c", "d", "e"), show="headings", selectmode="browse")
        for c, w, txt in [("a", 70, "Run"), ("b", 220, "PDF file / date"), ("c", 120, "Reg. no."), ("d", 70, "Row"), ("e", 400, "Overall / note")]:
            self.tv_hrec.heading(c, text=txt)
            self.tv_hrec.column(c, width=w, minwidth=40, stretch=c == "e")
        for tag, col in TAG_COLORS.items():
            self.tv_hrec.tag_configure(tag, background=col)
        self.tv_hrec.grid(row=3, column=0, sticky="nsew")

    # ------------------------------------------------------------------ settings
    def _thresh(self, which):
        m, r = int(round(float(self.v_match.get()))), int(round(float(self.v_review.get())))
        if which == "match" and r > m:
            r = m
        if which == "review" and m < r:
            m = r
        self.v_match.set(m)
        self.v_review.set(r)
        self.l_match.config(text=f"{m}%")
        self.l_review.config(text=f"{r}%")
        if MODES.get(self.v_mode.get()) == MODE_STRICT:
            self.l_thresh_help.config(text="Strict mode: names must be identical apart from case, extra spaces and "
                                           "punctuation (and titles, if ignored). Thresholds are not used.")
            return
        self.l_thresh_help.config(
            text=f"Names scoring {m}% or more count as a close match. {r}% to {m - 1}% are flagged for review. "
                 f"Below {r}% are mismatches.")

    def settings(self) -> Settings:
        return Settings(day_first=self.v_dateorder.get().startswith("Day"), match_threshold=float(self.v_match.get()),
                        review_threshold=float(self.v_review.get()), ignore_titles=self.v_titles.get(), ocr=self.v_ocr.get(),
                        mode=MODES.get(self.v_mode.get(), MODE_NORMAL))

    def status(self, text):
        self.v_status.set(text)
        self.update_idletasks()

    # ------------------------------------------------------------------ Excel
    def browse_excel(self):
        p = filedialog.askopenfilename(title="Choose the Excel or CSV file",
                                       filetypes=[("Excel or CSV", "*.xlsx *.xlsm *.xls *.ods *.csv *.tsv"), ("All files", "*.*")])
        if p:
            self.load_excel(p)

    def load_excel(self, path, sheet=None):
        try:
            self.sheet = core.load_all_sheets(path) if sheet == ALL_SHEETS else core.load_sheet(path, sheet)
        except Exception as e:
            messagebox.showerror("Could not read file", f"{Path(path).name}\n\n{e}")
            return
        self.l_excel.config(text=f"{Path(path).name}  ({len(self.sheet.grid)} rows, {self.sheet.ncols} columns)"
                                 + (f"\n{self.sheet.note}" if self.sheet.note else ""), foreground="")
        names = self.sheet.sheet_names
        self.cb_sheet.config(values=names + [ALL_SHEETS] if len(names) > 1 else names)
        self.v_sheet.set(self.sheet.sheet)
        self.header_row = 0 if self.sheet.origin else core.detect_header_row(self.sheet.grid)
        self.v_header.set(self.header_row + 1)
        self.manual.clear()
        self.run_detect(keep_manual=False)
        self.status(f"Loaded {Path(path).name}, sheet \"{self.sheet.sheet}\".")

    def change_sheet(self):
        if self.sheet and self.v_sheet.get() != self.sheet.sheet:
            self.load_excel(self.sheet.path, self.v_sheet.get())

    def change_header(self):
        if not self.sheet:
            return
        if self.sheet.origin:  # combined sheets: row 1 is always the combined header
            self.v_header.set(self.header_row + 1)
            return
        try:
            n = int(self.v_header.get())
        except (tk.TclError, ValueError):
            return
        n = max(0, min(n, len(self.sheet.grid)))
        if n - 1 != self.header_row:
            self.header_row = n - 1
            self.run_detect(keep_manual=True)

    def col_choices(self):
        out = [NOT_MAPPED]
        if self.sheet:
            for c in range(self.sheet.ncols):
                h = self.sheet.grid[self.header_row][c] if 0 <= self.header_row < len(self.sheet.grid) else ""
                out.append(f"{col_letter(c)}: {h[:28]}" if h else col_letter(c))
        return out

    def run_detect(self, keep_manual=True):
        if not self.sheet:
            return
        if not keep_manual:
            self.manual.clear()
        self.guesses = core.auto_detect(self.sheet.grid, self.header_row, self.pdf_records, self.settings(),
                                        keep=self.manual)
        self.refresh_mapping()

    def refresh_mapping(self):
        choices = self.col_choices()
        for key, _ in MAP_FIELDS:
            g = self.guesses[key]
            self.cb_map[key].config(values=choices)
            self.map_vars[key].set(choices[g.col + 1] if g.col is not None and g.col + 1 < len(choices) else NOT_MAPPED)
            self._conf_label(key, g)
            self._sample_label(key, g.col)
        self.refresh_preview()

    def _conf_label(self, key, g):
        txt = {"manual": "Set manually", "none": "Not found"}.get(g.confidence, f"Auto, {g.confidence} confidence")
        self.l_conf[key].config(text=txt, foreground=CONF_COLORS[g.confidence])

    def _sample_label(self, key, col):
        """One short line: example values, then why the column was chosen."""
        if col is None or not self.sheet:
            self.l_samp[key].config(text="")
            return
        rows = core.data_rows(self.sheet.grid, self.header_row)[:3]
        vals = [self.sheet.grid[r][col] for r in rows if self.sheet.grid[r][col]]
        g = self.guesses[key]
        txt = ("e.g. " + ", ".join(vals)) if vals else ""
        if g.reason and g.confidence != "manual":
            txt += f"  ({g.reason})"
        self.l_samp[key].config(text=txt if len(txt) <= 78 else txt[:75] + "...")

    def on_map(self, key):
        i = self.cb_map[key].current()
        col = None if i <= 0 else i - 1
        if col is None:
            self.manual.pop(key, None)
            self.guesses[key] = core.ColumnGuess()
        else:
            for other, g in self.guesses.items():  # a column can serve one field only
                if other != key and g.col == col:
                    self.guesses[other] = core.ColumnGuess()
                    self.manual.pop(other, None)
                    self.map_vars[other].set(NOT_MAPPED)
                    self._conf_label(other, self.guesses[other])
                    self._sample_label(other, None)
            self.manual[key] = col
            self.guesses[key] = core.ColumnGuess(col, "manual", 1.0, "Set manually")
        self._conf_label(key, self.guesses[key])
        self._sample_label(key, col)
        self.refresh_preview()

    def mapping(self):
        return {k: g.col for k, g in self.guesses.items()}

    def refresh_preview(self):
        if not self.sheet:
            return
        self._reset_preview()
        n = self.sheet.ncols
        by_col = {g.col: MAP_LABELS[k] for k, g in self.guesses.items() if g.col is not None}
        ids = ["row"] + [f"c{i}" for i in range(n)]
        self.tv_prev.config(columns=ids)
        self.tv_prev.heading("row", text="Row")
        self.tv_prev.column("row", width=86 if self.sheet.origin else 44, stretch=False)  # "SOM!123" when combined
        for i in range(n):
            lab = col_letter(i) + (f" = {by_col[i]}" if i in by_col else "")
            self.tv_prev.heading(f"c{i}", text=lab)
            self.tv_prev.column(f"c{i}", width=max(90, 9 * len(lab)), stretch=False)
        rows = ([self.header_row] if self.header_row >= 0 else []) + core.data_rows(self.sheet.grid, self.header_row)[:5]
        for r in rows:
            self.tv_prev.insert("", "end", values=[self.sheet.row_label(r)] + self.sheet.grid[r],
                                tags=("hdr",) if r == self.header_row else ())

    # ------------------------------------------------------------------ PDFs
    def browse_pdfs(self):
        ps = filedialog.askopenfilenames(title="Choose PDF marksheets", filetypes=[("PDF files", "*.pdf")])
        if ps:
            self.add_pdfs(list(ps))

    def browse_folder(self):
        d = filedialog.askdirectory(title="Choose a folder of PDF marksheets")
        if d:
            self.add_pdfs(sorted(str(p) for p in Path(d).rglob("*") if p.suffix.lower() == ".pdf"))

    def add_pdfs(self, paths):
        paths = [p for p in paths if p not in self.seen_pdfs]
        if not paths:
            return
        use_ocr = self.v_ocr.get()
        q: queue.Queue = queue.Queue()

        def work():
            for i, p in enumerate(paths, 1):
                try:
                    q.put(("ok", p, core.read_pdf(p, use_ocr=use_ocr), i))
                except Exception as e:
                    q.put(("err", p, str(e), i))
            q.put(("done", None, None, 0))

        self.progress.pack(side="right", padx=8)
        self.progress.start(12)
        threading.Thread(target=work, daemon=True).start()
        self.after(80, lambda: self._poll_pdfs(q, len(paths), []))

    def _poll_pdfs(self, q, total, errors):
        done = False
        try:
            while True:
                kind, p, data, i = q.get_nowait()
                if kind == "ok":
                    self.pdf_records.extend(data)
                    self.seen_pdfs.add(p)
                    self.status(f"Read {i} of {total} PDFs...")
                elif kind == "err":
                    errors.append(f"{Path(p).name}: {data}")
                else:
                    done = True
        except queue.Empty:
            pass
        if not done:
            self.after(80, lambda: self._poll_pdfs(q, total, errors))
            return
        self.progress.stop()
        self.progress.pack_forget()
        self.refresh_pdfs()
        self.run_detect(keep_manual=True)
        bad = sum(1 for r in self.pdf_records if r.unreadable)
        self.status(f"{len(self.pdf_records)} PDF records loaded" + (f", {bad} unreadable." if bad else "."))
        if errors:
            messagebox.showwarning("Some PDFs could not be opened", "\n".join(errors[:10]))
        if bad and not self.v_ocr.get():
            messagebox.showinfo("Scanned PDFs?", f"{bad} PDF(s) had no readable text. If they are scans, tick "
                                "'Use OCR for scanned PDFs' and add them again, or correct the values by hand.")

    def refresh_pdfs(self):
        self.tv_pdf.delete(*self.tv_pdf.get_children())
        for i, r in enumerate(self.pdf_records):
            f = r.fields
            self.tv_pdf.insert("", "end", iid=str(i), tags=("bad",) if r.unreadable else (),
                               values=(r.file, r.page, f.get("reg", ""), f.get("abc", ""), f.get("name", ""), f.get("father", ""),
                                       f.get("mother", ""), f.get("dob", "")))

    def remove_pdfs(self):
        idx = sorted((int(i) for i in self.tv_pdf.selection()), reverse=True)
        for i in idx:
            self.pdf_records.pop(i)
        self.seen_pdfs = {r.path for r in self.pdf_records}
        self.refresh_pdfs()

    def clear_pdfs(self):
        self.pdf_records.clear()
        self.seen_pdfs.clear()
        self.refresh_pdfs()

    def edit_pdf(self, event):
        iid = self.tv_pdf.identify_row(event.y)
        if not iid:
            return
        rec = self.pdf_records[int(iid)]
        win = tk.Toplevel(self)
        win.title(f"Correct values: {rec.file}")
        win.transient(self)
        win.grab_set()
        ents = {}
        for i, (k, label) in enumerate(FIELDS):
            ttk.Label(win, text=label).grid(row=i, column=0, sticky="w", padx=10, pady=4)
            v = tk.StringVar(value=rec.fields.get(k, ""))
            ttk.Entry(win, textvariable=v, width=40).grid(row=i, column=1, padx=10, pady=4)
            ents[k] = v
        if rec.note:
            ttk.Label(win, text=rec.note, style="Hint.TLabel", wraplength=360).grid(row=6, column=0, columnspan=2, padx=10)

        def save():
            rec.fields = {k: v.get().strip() for k, v in ents.items() if v.get().strip()}
            rec.source, rec.unreadable = "manual", not rec.fields
            win.destroy()
            self.refresh_pdfs()
            self.run_detect(keep_manual=True)

        ttk.Button(win, text="Save", command=save).grid(row=7, column=1, sticky="e", padx=10, pady=10)

    # ------------------------------------------------------------------ compare
    def run_compare(self):
        if not self.sheet:
            return messagebox.showinfo("Excel file needed", "Choose an Excel or CSV file first.")
        if not self.pdf_records:
            return messagebox.showinfo("PDFs needed", "Add at least one PDF marksheet first.")
        m = self.mapping()
        if m.get("reg") is None:
            return messagebox.showinfo("Map the registration number", "Choose which Excel column holds the registration number. It is used to pair each PDF with its row.")
        s = self.settings()
        try:
            self.result = core.compare(self.sheet.grid, self.header_row, m, self.pdf_records, s, origin=self.sheet.origin)
        except Exception as e:
            return messagebox.showerror("Comparison failed", str(e))
        self.run_info = dict(created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), excel_file=Path(self.sheet.path).name,
                             sheet=self.sheet.sheet, header_row=self.header_row, mapping=m, settings=s.to_dict())
        msg = "Comparison finished."
        if self.v_save.get():
            try:
                rid = self.db.save_run(self.run_info, self.result)
                self.run_info["id"] = rid
                msg += f" Saved as run {rid}."
                self.refresh_history()
            except Exception as e:
                messagebox.showwarning("Could not save to database", str(e))
        self.status(msg)
        self.fill_results()
        self.nb.select(self.t_results)

    def fill_results(self):
        self.tv_res.delete(*self.tv_res.get_children())
        self.shown_results = []
        if not self.result:
            return
        c = self.result.counts()
        self.tally_lbl["all"].config(text=str(len(self.result.records)))
        self.tally_lbl[OV_VERIFIED].config(text=str(c[OV_VERIFIED] + c[OV_MINOR]))
        self.tally_lbl[OV_REVIEW].config(text=str(c[OV_REVIEW]))
        self.tally_lbl[OV_MISMATCH].config(text=str(c[OV_MISMATCH]))
        self.tally_lbl["nf"].config(text=str(c[OV_NOTFOUND] + c[OV_NOREG]))
        flt = self.v_filter.get()
        keep = {"All": None, "Verified": (OV_VERIFIED, OV_MINOR), "Needs review": (OV_REVIEW,),
                "Mismatch / not found": (OV_MISMATCH, OV_NOTFOUND, OV_NOREG)}[flt]
        for n, r in enumerate(self.result.records, 1):
            if keep and r.overall not in keep:
                continue
            f = r.fields
            self.shown_results.append(r)
            self.tv_res.insert("", "end", iid=str(len(self.shown_results) - 1), tags=(overall_tag(r.overall),),
                               values=(n, r.pdf.file, r.pdf.fields.get("reg", ""), r.excel_row or "", r.overall,
                                       short_status(f.get("name")), short_status(f.get("father")),
                                       short_status(f.get("mother")), short_status(f.get("dob")), short_status(f.get("abc"))))
        um = len(self.result.unmatched_excel)
        self.l_unmatched.config(text=f"{um} Excel row(s) had no matching PDF (listed in the Excel report)." if um else "")

    def open_detail(self, event):
        iid = self.tv_res.identify_row(event.y)
        if not iid:
            return
        r = self.shown_results[int(iid)]
        win = tk.Toplevel(self)
        win.title(f"{r.pdf.file}: {r.overall}")
        win.geometry("860x330")
        win.transient(self)
        ttk.Label(win, text=f"{r.pdf.file}  |  Reg. no. {r.pdf.fields.get('reg', '-')}  |  Excel row {r.excel_row or '-'}  |  {r.overall}",
                  style="Head.TLabel").pack(anchor="w", padx=10, pady=(10, 4))
        if r.note:
            ttk.Label(win, text=r.note, wraplength=820, foreground="#93600E").pack(anchor="w", padx=10)
        tv = ttk.Treeview(win, columns=("f", "p", "e", "s", "sc", "n"), show="headings", height=6)
        for c, w, t in [("f", 120, "Field"), ("p", 170, "PDF"), ("e", 170, "Excel"), ("s", 100, "Result"), ("sc", 60, "Match %"), ("n", 220, "Details")]:
            tv.heading(c, text=t)
            tv.column(c, width=w)
        for k, label in FIELDS:
            f = r.fields.get(k)
            if f is None:
                tv.insert("", "end", values=(label, r.pdf.fields.get(k, ""), "", "-", "", ""))
            else:
                tv.insert("", "end", values=(label, f.pdf_value, f.excel_value, f.status,
                                             "" if f.score is None else f"{f.score:.0f}", f.note))
        tv.pack(fill="both", expand=True, padx=10, pady=10)

    # ------------------------------------------------------------------ export
    def export_report(self):
        if not self.result:
            return messagebox.showinfo("Nothing to export", "Run a comparison first.")
        default = f"verification_report_{datetime.now():%Y%m%d_%H%M}.xlsx"
        p = filedialog.asksaveasfilename(title="Save Excel report", defaultextension=".xlsx", initialfile=default,
                                         filetypes=[("Excel workbook", "*.xlsx")])
        if not p:
            return
        try:
            build_report(p, self.run_info, self.result)
        except PermissionError:
            return messagebox.showerror("Could not save", "The file is open in Excel. Close it and try again.")
        except Exception as e:
            return messagebox.showerror("Could not save", str(e))
        self.status(f"Report saved: {p}" + self.store_report("Learner", p, self.run_info,
                                                             run_id=(self.run_info or {}).get("id"),
                                                             summary=learner_summary(self.result)))
        if messagebox.askyesno("Report saved", "Open the report now?"):
            open_file(p)

    # ------------------------------------------------------------------ history
    def refresh_history(self):
        self.tv_hist.delete(*self.tv_hist.get_children())
        for r in self.db.list_runs():
            self.tv_hist.insert("", "end", iid=str(r["id"]), values=(r["id"], r["created_at"], r["excel_file"], r["pdf_count"],
                                                                      r["n_verified"], r["n_review"], r["n_mismatch"], r["n_notfound"]))

    def _sel_run(self):
        s = self.tv_hist.selection()
        if not s:
            messagebox.showinfo("Choose a run", "Select a run in the list first.")
            return None
        return int(s[0])

    def hist_preview(self):
        s = self.tv_hist.selection()
        if not s:
            return
        self.tv_hrec.delete(*self.tv_hrec.get_children())
        _, res = self.db.load_run(int(s[0]))
        for n, r in enumerate(res.records, 1):
            self.tv_hrec.insert("", "end", tags=(overall_tag(r.overall),),
                                values=(s[0], r.pdf.file, r.pdf.fields.get("reg", ""), r.excel_row or "", f"{r.overall}  {r.note}".strip()))

    def hist_view(self):
        rid = self._sel_run()
        if rid is None:
            return
        info, res = self.db.load_run(rid)
        self.run_info, self.result = info, res
        self.fill_results()
        self.nb.select(self.t_results)
        self.status(f"Showing saved run {rid} ({info['created_at']}).")

    def hist_export(self):
        rid = self._sel_run()
        if rid is None:
            return
        info, res = self.db.load_run(rid)
        p = filedialog.asksaveasfilename(defaultextension=".xlsx", initialfile=f"verification_run_{rid}.xlsx",
                                         filetypes=[("Excel workbook", "*.xlsx")])
        if p:
            build_report(p, info, res)
            self.status(f"Report saved: {p}" + self.store_report("Learner", p, info, run_id=rid,
                                                                 summary=learner_summary(res)))
            if messagebox.askyesno("Report saved", "Open the report now?"):
                open_file(p)

    def hist_delete(self):
        rid = self._sel_run()
        if rid is not None and messagebox.askyesno("Delete run", f"Delete run {rid} and its results from the database?"):
            self.db.delete_run(rid)
            self.tv_hrec.delete(*self.tv_hrec.get_children())
            self.refresh_history()

    def hist_lookup(self):
        reg = core.norm_reg(self.v_lookup.get())
        self.tv_hrec.delete(*self.tv_hrec.get_children())
        if not reg:
            return
        rows = self.db.history_for_reg(self.v_lookup.get().strip()) or self.db.history_for_reg(reg)
        if not rows:
            self.tv_hrec.insert("", "end", values=("", "No saved results for this number", "", "", ""))
        for r in rows:
            self.tv_hrec.insert("", "end", tags=(overall_tag(r["overall"]),),
                                values=(r["run_id"], f'{r["pdf_file"]}  ({r["created_at"]})', reg, r["excel_row"] or "",
                                        f'{r["overall"]}  {r["note"] or ""}'.strip()))

    def choose_db(self):
        p = filedialog.asksaveasfilename(title="Choose or create a database file", defaultextension=".db",
                                         initialfile=Path(self.db.path).name, filetypes=[("SQLite database", "*.db")],
                                         confirmoverwrite=False)
        if p:
            self.db.close()
            self.db = Database(p)
            self.refresh_history()
            self.refresh_reports()
            self.status(f"Using database {p}")

    # ------------------------------------------------------------------ saved reports (tab 5)
    def store_report(self, kind, path, info, run_id=None, summary="", checks=None) -> str:
        """Put a just-written Excel report into the database. Returns a short note for the status bar."""
        if not self.v_save_reports.get():
            return ""
        try:
            rid = self.db.save_report(kind, path, info, run_id=run_id, summary=summary, checks=checks)
        except Exception as e:  # the report itself is already on disk, so only warn
            messagebox.showwarning("Report not stored in the database", str(e))
            return ""
        self.refresh_reports()
        return f"  (stored in the database as report {rid})"

    def _build_reports(self):
        t = self.t_reports
        t.columnconfigure(0, weight=1)
        t.rowconfigure(1, weight=1)
        t.rowconfigure(3, weight=1)
        bar = ttk.Frame(t)
        bar.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        for txt, cmd in [("Open", self.rep_open), ("Save a copy...", self.rep_save_copy),
                         ("Delete selected", self.rep_delete), ("Refresh", self.refresh_reports)]:
            ttk.Button(bar, text=txt, command=cmd).pack(side="left", padx=(0, 6))
        ttk.Label(bar, text="Every exported Excel report is kept here with the date and time it was created.",
                  style="Hint.TLabel").pack(side="right")
        cols = ("id", "when", "kind", "file", "source", "summary", "size")
        self.tv_rep = ttk.Treeview(t, columns=cols, show="headings", selectmode="browse")
        for c, w, txt in [("id", 44, "No."), ("when", 170, "Created (date and time)"), ("kind", 70, "Type"),
                          ("file", 270, "Report file"), ("source", 200, "Excel checked"), ("summary", 360, "Summary"),
                          ("size", 70, "Size")]:
            self.tv_rep.heading(c, text=txt)
            self.tv_rep.column(c, width=w, minwidth=40, stretch=c in ("file", "summary"))
        self.tv_rep.grid(row=1, column=0, sticky="nsew")
        ys = ttk.Scrollbar(t, orient="vertical", command=self.tv_rep.yview)
        self.tv_rep.configure(yscrollcommand=ys.set)
        ys.grid(row=1, column=1, sticky="ns")
        self.tv_rep.bind("<<TreeviewSelect>>", lambda e: self.rep_preview())
        self.tv_rep.bind("<Double-1>", lambda e: self.rep_open())
        sb = ttk.Frame(t)
        sb.grid(row=2, column=0, sticky="ew", pady=(8, 4))
        ttk.Label(sb, text="Look up an enrollment number in saved Meritto reports:").pack(side="left")
        self.v_rep_lookup = tk.StringVar()
        e = ttk.Entry(sb, textvariable=self.v_rep_lookup, width=22)
        e.pack(side="left", padx=6)
        e.bind("<Return>", lambda ev: self.rep_lookup())
        ttk.Button(sb, text="Find", command=self.rep_lookup).pack(side="left")
        self.tv_rep_rows = ttk.Treeview(t, columns=("a", "b", "c", "d", "e", "f"), show="headings", selectmode="browse")
        for c, w, txt in [("a", 175, "Report / row"), ("b", 120, "Reg. / field"), ("c", 200, "Expected / Excel"),
                          ("d", 200, "In PDF"), ("e", 160, "Result"), ("f", 300, "Note")]:
            self.tv_rep_rows.heading(c, text=txt)
            self.tv_rep_rows.column(c, width=w, minwidth=40, stretch=c == "f")
        for tag, col in TAG_COLORS.items():
            self.tv_rep_rows.tag_configure(tag, background=col)
        self.tv_rep_rows.grid(row=3, column=0, sticky="nsew")

    def refresh_reports(self):
        if not hasattr(self, "tv_rep"):
            return
        self.tv_rep.delete(*self.tv_rep.get_children())
        for r in self.db.list_reports():
            size = f"{(r['size_bytes'] or 0) / 1024:.0f} KB"
            self.tv_rep.insert("", "end", iid=str(r["id"]), values=(r["id"], r["created_at"], r["kind"], r["file_name"],
                                                                    r["source_excel"] or "", r["summary"] or "", size))

    def _sel_report(self):
        s = self.tv_rep.selection()
        if not s:
            messagebox.showinfo("Choose a report", "Select a report in the list first.")
            return None
        return int(s[0])

    def rep_preview(self):
        s = self.tv_rep.selection()
        self.tv_rep_rows.delete(*self.tv_rep_rows.get_children())
        if not s:
            return
        rep = next((r for r in self.db.list_reports() if r["id"] == int(s[0])), None)
        if rep is None:
            return
        if rep["kind"] == "Meritto":
            for c in self.db.report_checks(rep["id"]):
                self.tv_rep_rows.insert("", "end", tags=(meritto_tag(c["status"]),),
                                        values=(f"row {c['excel_row']}", f"{c['enrollment']} / {c['label'] or c['field']}",
                                                c["expected"], c["pdf_value"], c["status"], c["note"]))
        elif rep["run_id"]:
            try:
                _, res = self.db.load_run(rep["run_id"])
            except KeyError:
                return
            for r in res.records:
                self.tv_rep_rows.insert("", "end", tags=(overall_tag(r.overall),),
                                        values=(f"row {r.excel_row or '-'}", r.pdf.fields.get("reg", ""), r.pdf.file,
                                                "", r.overall, r.note))
        else:
            self.tv_rep_rows.insert("", "end", values=("", "", "Open the report to see its rows", "", "", ""))

    def _report_to_temp(self, report_id):
        name, data = self.db.report_file(report_id)
        folder = Path(tempfile.gettempdir()) / "marksheet_verifier_reports"
        folder.mkdir(exist_ok=True)
        p = folder / f"{report_id}_{name}"
        p.write_bytes(data)
        return p

    def rep_open(self):
        rid = self._sel_report()
        if rid is None:
            return
        try:
            p = self._report_to_temp(rid)
        except PermissionError:
            return messagebox.showerror("Could not open", "This report is already open in Excel.")
        open_file(str(p))
        self.status(f"Opened saved report {rid} (a temporary copy: use 'Save a copy...' to keep changes).")

    def rep_save_copy(self):
        rid = self._sel_report()
        if rid is None:
            return
        name, data = self.db.report_file(rid)
        p = filedialog.asksaveasfilename(title="Save a copy of the report", defaultextension=".xlsx", initialfile=name,
                                         filetypes=[("Excel workbook", "*.xlsx")])
        if not p:
            return
        try:
            Path(p).write_bytes(data)
        except PermissionError:
            return messagebox.showerror("Could not save", "The file is open in Excel. Close it and try again.")
        self.status(f"Saved a copy of report {rid}: {p}")

    def rep_delete(self):
        rid = self._sel_report()
        if rid is not None and messagebox.askyesno("Delete report", f"Delete report {rid} from the database?\n"
                                                   "(Files already saved on disk are not touched.)"):
            self.db.delete_report(rid)
            self.tv_rep_rows.delete(*self.tv_rep_rows.get_children())
            self.refresh_reports()

    def rep_lookup(self):
        self.tv_rep_rows.delete(*self.tv_rep_rows.get_children())
        txt = self.v_rep_lookup.get().strip()
        if not txt:
            return
        rows = self.db.meritto_history_for_enrollment(txt)
        if not rows and core.norm_reg(txt) != txt:
            rows = self.db.meritto_history_for_enrollment(core.norm_reg(txt))
        if not rows:
            self.tv_rep_rows.insert("", "end", values=("", "No saved Meritto checks for this number", "", "", "", ""))
        for r in rows:
            self.tv_rep_rows.insert("", "end", tags=(meritto_tag(r["status"]),),
                                    values=(f"{r['report_id']}: {r['created_at']}", f"row {r['excel_row']} / {r['label'] or r['field']}",
                                            r["expected"], r["pdf_value"], r["status"], r["note"]))

    def _quit(self):
        try:
            self.db.close()
        finally:
            self.destroy()


def run(db_path=DEFAULT_DB):
    App(db_path).mainloop()
