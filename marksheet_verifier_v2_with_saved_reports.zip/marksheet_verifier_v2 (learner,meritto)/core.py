"""
core.py - extraction, column auto-detection, fuzzy comparison.

No GUI or database code lives here, so everything can be used from scripts,
the command line, or the GUI.
"""
from __future__ import annotations

import datetime as dt
import difflib
import re
import unicodedata
from collections import Counter
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from pathlib import Path

try:  # rapidfuzz is faster and a bit more accurate, but optional
    from rapidfuzz import fuzz
    from rapidfuzz.distance import Levenshtein

    HAVE_RAPIDFUZZ = True
except ImportError:  # pragma: no cover
    HAVE_RAPIDFUZZ = False

# --------------------------------------------------------------------------
# Constants
# --------------------------------------------------------------------------
FIELDS = [
    ("reg", "Registration No."),
    ("abc", "ABC ID"),
    ("name", "Student Name"),
    ("father", "Father's Name"),
    ("mother", "Mother's Name"),
    ("dob", "Date of Birth"),
]
FIELD_LABELS = dict(FIELDS)
COMPARE_FIELDS = ["name", "father", "mother", "dob", "abc"]  # abc last keeps old report columns in place
# Excel-only columns: mapped like the others but never read from a PDF.
EXTRA_FIELDS = [("name_last", "Last name (optional)")]
MAP_FIELDS = FIELDS + EXTRA_FIELDS
MAP_LABELS = dict(MAP_FIELDS)
NAME_FIELDS = ("name", "father", "mother")

MODE_NORMAL = "normal"   # fuzzy scores, thresholds, initials, word order
MODE_STRICT = "strict"   # only case, extra spaces and punctuation (and titles, if ignored) are ignored
ALL_SHEETS = "(All sheets)"

# field-level statuses
ST_MATCH = "Match"
ST_CLOSE = "Close match"
ST_REVIEW = "Review"
ST_MISMATCH = "Mismatch"
ST_MISSING = "Missing"
ST_SKIPPED = "Not compared"

# record-level results
OV_VERIFIED = "Verified"
OV_MINOR = "Verified (minor differences)"
OV_REVIEW = "Needs review"
OV_MISMATCH = "Mismatch"
OV_NOTFOUND = "Not in Excel"
OV_NOREG = "No reg. no. in PDF"
OVERALL_ORDER = [OV_VERIFIED, OV_MINOR, OV_REVIEW, OV_MISMATCH, OV_NOTFOUND, OV_NOREG]

TITLES = {"MR", "MRS", "MS", "MISS", "DR", "SHRI", "SRI", "SMT", "KUMARI", "KUM", "LATE", "SHREE", "SHRIMATI"}


@dataclass
class Settings:
    day_first: bool = True          # 05-07-2006 means 5 July (India/UK style)
    match_threshold: float = 92.0   # name score >= this -> "Close match" (accepted)
    review_threshold: float = 75.0  # name score >= this -> "Review"; below -> "Mismatch"
    ignore_titles: bool = True      # drop Mr / Smt / Shri etc. before comparing
    ocr: bool = False               # try OCR on scanned PDFs
    mode: str = MODE_NORMAL         # MODE_NORMAL or MODE_STRICT (names only)

    def to_dict(self):
        return dict(self.__dict__)

    @classmethod
    def from_dict(cls, d):
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


def col_letter(i: int) -> str:
    """0 -> A, 25 -> Z, 26 -> AA"""
    s, i = "", i + 1
    while i > 0:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def col_index(letters: str) -> int:
    n = 0
    for ch in letters.upper():
        n = n * 26 + (ord(ch) - 64)
    return n - 1


# --------------------------------------------------------------------------
# Normalising and fuzzy scoring
# --------------------------------------------------------------------------
def _strip_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c))


def clean_name(s, ignore_titles=True) -> str:
    t = _strip_accents(str(s or "")).upper()
    t = re.sub(r"[^A-Z\s]", " ", t)
    words = t.split()
    if ignore_titles:
        words = [w for w in words if w not in TITLES]
    return " ".join(words)


def norm_reg(s) -> str:
    t = str(s or "").strip().upper()
    # Excel sometimes turns long IDs into 2.51612400699E+11
    if re.fullmatch(r"\d+(\.\d+)?E\+\d+", t):
        try:
            t = format(Decimal(t), "f").split(".")[0]
        except InvalidOperation:
            pass
    if re.fullmatch(r"\d+\.0+", t):  # a number stored as text, e.g. "251612400673.0"
        t = t.split(".")[0]
    return re.sub(r"[^A-Z0-9]", "", t)


def norm_abc(s) -> str:
    """ABC (APAAR) IDs are compared as digits only."""
    return re.sub(r"\D", "", norm_reg(s))


def _ratio(a, b):
    if HAVE_RAPIDFUZZ:
        return fuzz.ratio(a, b)
    return difflib.SequenceMatcher(None, a, b).ratio() * 100


def _token_sort(a, b):
    if HAVE_RAPIDFUZZ:
        return fuzz.token_sort_ratio(a, b)
    return _ratio(" ".join(sorted(a.split())), " ".join(sorted(b.split())))


def edit_distance(a, b):
    if HAVE_RAPIDFUZZ:
        return Levenshtein.distance(a, b)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def _initials_match(ta, tb):
    """'A K SHARMA' vs 'ARUN KUMAR SHARMA' -> True (needs same token count)."""
    if len(ta) != len(tb):
        return False
    pool, used_initial = list(tb), False
    for t in sorted(ta, key=len, reverse=True):
        if t in pool:
            pool.remove(t)
            continue
        hit = next((p for p in pool if (len(t) == 1 and p.startswith(t)) or (len(p) == 1 and t.startswith(p))), None)
        if hit is None:
            return False
        pool.remove(hit)
        used_initial = True
    return used_initial


def name_similarity(a_raw, b_raw, ignore_titles=True):
    """Return (score 0-100, explanation)."""
    a, b = clean_name(a_raw, ignore_titles), clean_name(b_raw, ignore_titles)
    if a == b:
        same = re.sub(r"\s+", " ", str(a_raw).strip()) == re.sub(r"\s+", " ", str(b_raw).strip())
        return 100.0, "Exact" if same else "Same apart from case, spacing or punctuation"
    if not a or not b:
        return 0.0, "Empty after cleaning"
    ta, tb = a.split(), b.split()
    if a.replace(" ", "") == b.replace(" ", ""):
        return 98.0, "Spacing differs"
    if sorted(ta) == sorted(tb):
        return 97.0, "Same words, different order"
    if _initials_match(ta, tb):
        return 95.0, "Initials vs full name"
    score = max(_ratio(a, b), _token_sort(a, b))
    return float(round(score, 1)), f"{score:.0f}% similar"


# --------------------------------------------------------------------------
# Dates
# --------------------------------------------------------------------------
_MONTHS = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
           "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}


def _ymd(y, m, d):
    try:
        return dt.date(int(y), int(m), int(d))
    except ValueError:
        return None


def _year4(y):
    y = int(y)
    return y if y >= 100 else (2000 + y if y <= 30 else 1900 + y)


def parse_date(value, day_first=True):
    if value is None:
        return None
    if isinstance(value, dt.datetime):
        return value.date()
    if isinstance(value, dt.date):
        return value
    s = str(value).strip()
    if not s:
        return None
    m = re.match(r"^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})(?:[ T].*)?$", s)
    if m:
        return _ymd(*m.groups())
    m = re.match(r"^(\d{1,2})[-/.\s](\d{1,2})[-/.\s](\d{2,4})(?:\s.*)?$", s)
    if m:
        a, b, y = int(m.group(1)), int(m.group(2)), _year4(m.group(3))
        if a > 12:
            d, mo = a, b
        elif b > 12:
            mo, d = a, b
        elif day_first:
            d, mo = a, b
        else:
            mo, d = a, b
        return _ymd(y, mo, d)
    m = re.match(r"^(\d{1,2})(?:st|nd|rd|th)?[\s\-/.]*([A-Za-z]{3,})[\s\-/.,]*(\d{2,4})$", s)
    if m and m.group(2)[:3].lower() in _MONTHS:
        return _ymd(_year4(m.group(3)), _MONTHS[m.group(2)[:3].lower()], m.group(1))
    m = re.match(r"^([A-Za-z]{3,})[\s\-.]*(\d{1,2})(?:st|nd|rd|th)?,?[\s\-.]*(\d{2,4})$", s)
    if m and m.group(1)[:3].lower() in _MONTHS:
        return _ymd(_year4(m.group(3)), _MONTHS[m.group(1)[:3].lower()], m.group(2))
    m = re.match(r"^(\d{5})(?:\.\d+)?$", s)  # Excel serial number
    if m and 10000 < int(m.group(1)) < 80000:
        return (dt.date(1899, 12, 30) + dt.timedelta(days=int(m.group(1))))
    return None


def fmt_date(d):
    return d.strftime("%d-%m-%Y") if d else ""


# --------------------------------------------------------------------------
# PDF extraction
# --------------------------------------------------------------------------
@dataclass
class PdfRecord:
    file: str
    path: str
    page: int
    pages: int
    fields: dict = field(default_factory=dict)
    source: str = "text"        # text | ocr | manual
    unreadable: bool = False
    note: str = ""


def label_field(label: str):
    l = re.sub(r"\s+", " ", re.sub(r"[^a-z\s]", " ", label.lower())).strip()
    if not l:
        return None
    if "mother" in l:
        return "mother"
    if "father" in l:
        return "father"
    if "birth" in l or l in ("dob", "d o b"):
        return "dob"
    if re.search(r"regist|enrol|^reg( no| number)?$", l):
        return "reg"
    if re.search(r"\babc\b|\bapaar\b", l):
        return "abc"
    if "name" in l and not re.search(
            r"guardian|husband|institut|college|school|course|programme|program|exam|centre|center|university|parent|subject|paper", l):
        return "name"
    return None


def _lines_from_words(words, scale=1.0):
    """words: dicts with x0, x1, top, bottom, text -> list of lines, each a list of segments.
    A segment is a run of words; a big horizontal gap starts a new segment (handles two-column layouts)."""
    words = [w for w in words if str(w["text"]).strip()]
    words.sort(key=lambda w: (w["top"], w["x0"]))
    lines = []
    for w in words:
        h = max(w["bottom"] - w["top"], 1)
        for ln in lines:
            if abs(ln["top"] - w["top"]) < max(2.5 * scale, h * 0.35):
                ln["w"].append(w)
                break
        else:
            lines.append({"top": w["top"], "w": [w]})
    out, split_lines = [], []
    for ln in sorted(lines, key=lambda l: l["top"]):
        ws = sorted(ln["w"], key=lambda w: w["x0"])
        segs, cur = [], []
        for w in ws:
            h = max(w["bottom"] - w["top"], 1)
            if cur and w["x0"] - cur[-1]["x1"] > max(18 * scale, h * 2.2):
                segs.append(cur)
                cur = []
            cur.append(w)
        segs.append(cur)
        split_lines.append(segs)
    # Where a second column of labels starts (x seen on 2+ lines after a clear gap). A long value can run
    # up to that column and get glued to its label ("SHANKAR WAKADE Programme : B.Tech"); split there,
    # but only when the rest really looks like "Label : value".
    starts = Counter(round(sg[0]["x0"] / (3 * scale)) for segs in split_lines for sg in segs[1:] if sg)
    anchors = [k * 3 * scale for k, n in starts.items() if n >= 2]
    text = lambda ws: " ".join(w["text"] for w in ws)
    for segs in split_lines:
        fixed = []
        for i, sg in enumerate(segs):
            after = text(segs[i + 1]) if i + 1 < len(segs) and re.match(r"^[:：]", text(segs[i + 1])) else ""
            cut = next((j for j in range(1, len(sg)) if any(abs(sg[j]["x0"] - a) <= 3 * scale for a in anchors)
                        and _LABEL_RE.match(f"{text(sg[j:])} {after}".strip())), None)
            fixed += [sg[:cut], sg[cut:]] if cut else [sg]
        segs = [" ".join(w["text"] for w in sg).strip() for sg in fixed]
        merged = []
        for s in segs:
            if not s:
                continue
            if merged and (re.match(r"^[:：]", s) or re.search(r"[:：]\s*$", merged[-1])):
                merged[-1] += " " + s
            else:
                merged.append(s)
        out.append(merged)
    return out


_LABEL_RE = re.compile(r"^(.{2,60}?)\s*[:：]\s*(.+)$")


def _clean_value(key, v):
    v = v.strip()
    if key == "reg":
        m = re.search(r"[A-Za-z0-9/\-]{4,}", v)
        return m.group(0) if m else v
    if key == "dob":
        m = re.search(r"\d{1,4}[-/.\s]\w{1,9}[-/.\s,]*\d{2,4}", v)
        return m.group(0) if m else v
    if key == "abc":
        m = re.search(r"\d[\d\s\-]{6,}\d", v)
        return re.sub(r"\D", "", m.group(0)) if m else v
    return v.strip(" .,:;")


def extract_fields(lines):
    found = {}
    for segs in lines:
        for i, seg in enumerate(segs):
            key = val = None
            m = _LABEL_RE.match(seg)
            if m:
                key, val = label_field(m.group(1)), m.group(2)
            elif i + 1 < len(segs) and len(seg.split()) <= 5:  # "Label | value" without a colon
                k = label_field(seg)
                if k and label_field(segs[i + 1]) is None:
                    key, val = k, segs[i + 1]
            if key and key not in found and val.strip():
                cleaned = _clean_value(key, val)
                if key == "reg" and not re.search(r"\d{4,}", cleaned):
                    continue  # e.g. OCR noise; the full-text fallback below may still find it
                if key == "abc" and not re.fullmatch(r"\d{8,}", cleaned):
                    continue  # e.g. "ABC ID : -" or "N/A": treat as no ABC ID
                found[key] = cleaned
    full = "\n".join("  ".join(s) for s in lines)
    if "reg" not in found:
        m = re.search(r"\b(?:registration|regn?\.?|enrol+ment)\s*(?:no\.?|number)?\s*[:\-]?\s*([A-Z0-9/\-]{0,6}\d{4,}[A-Z0-9/\-]*)", full, re.I)
        if m:
            found["reg"] = m.group(1)
    if "abc" not in found:
        m = re.search(r"\b(?:abc|apaar)\s*(?:id|no\.?)?\s*[:\-]?\s*(\d[\d ]{6,}\d)", full, re.I)
        if m:
            found["abc"] = re.sub(r"\D", "", m.group(1))
    if "dob" not in found:
        m = re.search(r"(?:date of birth|d\.?\s?o\.?\s?b\.?)\s*[:\-]?\s*(\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4})", full, re.I)
        if m:
            found["dob"] = m.group(1)
    return found


def _ocr_words(img, psm, resolution):
    import pytesseract
    from pytesseract import Output

    d = pytesseract.image_to_data(img, output_type=Output.DICT, config=f"--psm {psm}")
    words = []
    for i, t in enumerate(d["text"]):
        try:
            conf = float(d["conf"][i])
        except ValueError:
            conf = -1
        if t.strip() and conf > 0:
            words.append({"text": t, "x0": d["left"][i], "x1": d["left"][i] + d["width"][i],
                          "top": d["top"][i], "bottom": d["top"][i] + d["height"][i]})
    return extract_fields(_lines_from_words(words, scale=resolution / 72))


def _ocr_page(page, resolution=300):
    """OCR with a few image treatments; later passes only fill fields earlier ones missed.
    (Watermarks and background patterns are common on marksheets and confuse plain OCR.)"""
    import pytesseract  # noqa: F401  (optional dependency; raises ImportError if absent)

    img = page.to_image(resolution=resolution).original.convert("L")
    passes = [(img, 6)]
    for cut in (140, 180):
        passes.append((img.point(lambda p, c=cut: 255 if p > c else 0), 6))
    passes.append((img.point(lambda p: 255 if p > 160 else 0), 4))
    found = {}
    for im, psm in passes:
        for k, v in _ocr_words(im, psm, resolution).items():
            found.setdefault(k, v)
        if all(k in found for k in ("reg", "name", "father", "mother", "dob")):
            break
    return found


def read_pdf(path, use_ocr=False, force_ocr=False):
    """Return one PdfRecord per page that contains student details."""
    import pdfplumber

    path = str(path)
    name = Path(path).name
    recs, ocr_problem = [], ""
    with pdfplumber.open(path) as pdf:
        n = len(pdf.pages)
        for i, page in enumerate(pdf.pages, 1):
            fields_, source = {}, "text"
            if not force_ocr:
                words = page.extract_words(x_tolerance=1.5, y_tolerance=2, keep_blank_chars=False)
                fields_ = extract_fields(_lines_from_words(words))
            if (force_ocr or not fields_) and use_ocr:
                try:
                    fields_, source = _ocr_page(page), "ocr"
                except Exception as e:  # missing tesseract etc.
                    ocr_problem = f"OCR failed: {e}"
            if fields_:
                recs.append(PdfRecord(name, path, i, n, fields_, source))
    if not recs:
        note = ocr_problem or ("No readable text found. This looks like a scanned PDF; enable OCR."
                               if not use_ocr else "No student details found.")
        recs.append(PdfRecord(name, path, 1, n, {}, "text", True, note))
    return recs


# --------------------------------------------------------------------------
# Excel / CSV loading
# --------------------------------------------------------------------------
@dataclass
class SheetData:
    path: str
    sheet: str
    sheet_names: list
    grid: list          # list of rows, each a list of strings
    ncols: int
    origin: list | None = None  # per grid row: (sheet, 1-based row) when several sheets were combined
    note: str = ""

    def row_label(self, r):
        """How grid row r (0-based) is shown to the user."""
        if self.origin and r < len(self.origin) and self.origin[r]:
            return f"{self.origin[r][0]}!{self.origin[r][1]}"
        return str(r + 1)


def _cell_str(v):
    if v is None:
        return ""
    if isinstance(v, bool):
        return str(v)
    if isinstance(v, dt.datetime):
        return v.date().isoformat() if (v.hour, v.minute, v.second) == (0, 0, 0) else v.isoformat(sep=" ")
    if isinstance(v, dt.date):
        return v.isoformat()
    if isinstance(v, float):
        if v != v:  # NaN
            return ""
        return str(int(v)) if v.is_integer() else format(v, ".15g")
    try:  # numpy scalars
        import numpy as np
        if isinstance(v, np.generic):
            return _cell_str(v.item())
    except ImportError:  # pragma: no cover
        pass
    return str(v).strip()


def _finish_grid(rows):
    grid = [[_cell_str(c) for c in r] for r in rows]
    while grid and not any(grid[-1]):
        grid.pop()
    ncols = 0
    for r in grid:
        for i, c in enumerate(r):
            if c:
                ncols = max(ncols, i + 1)
    for r in grid:
        r.extend([""] * (ncols - len(r)))
        del r[ncols:]
    return grid, ncols


def list_sheets(path):
    ext = Path(path).suffix.lower()
    if ext in (".csv", ".tsv", ".txt"):
        return ["(csv)"]
    if ext in (".xlsx", ".xlsm"):
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True)
        names = wb.sheetnames
        wb.close()
        return names
    import pandas as pd
    return pd.ExcelFile(path).sheet_names


def load_sheet(path, sheet=None) -> SheetData:
    path = str(path)
    ext = Path(path).suffix.lower()
    names = list_sheets(path)
    if ext in (".csv", ".tsv", ".txt"):
        import pandas as pd
        kw = dict(header=None, dtype=str, keep_default_na=False, sep=None, engine="python")
        try:
            df = pd.read_csv(path, encoding="utf-8-sig", **kw)
        except UnicodeDecodeError:
            df = pd.read_csv(path, encoding="latin-1", **kw)
        rows, sheet = df.values.tolist(), "(csv)"
    elif ext in (".xlsx", ".xlsm"):
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        if sheet not in names:  # default: the sheet with the most rows
            sheet = max(names, key=lambda n: wb[n].max_row or 0)
        rows = [list(r) for r in wb[sheet].iter_rows(values_only=True)]
        wb.close()
    else:  # .xls / .ods
        import pandas as pd
        if sheet not in names:
            sheet = names[0]
        df = pd.read_excel(path, sheet_name=sheet, header=None, dtype=object, keep_default_na=False, na_values=[])
        rows = df.values.tolist()
    grid, ncols = _finish_grid(rows)
    return SheetData(path, sheet, names, grid, ncols)


def load_all_sheets(path) -> SheetData:
    """Stack every sheet that has a recognisable header row into one grid.

    Columns are lined up by header text, so sheets may have their columns in different
    places (e.g. one sheet has an extra serial-number column). A 'Sheet' column is added.
    Row 0 of the result is the header; `origin` maps every row back to its sheet and row."""
    names = list_sheets(path)
    header, where = [], {}
    stacked, skipped = [], []
    for n in names:
        sd = load_sheet(path, n)
        hr = detect_header_row(sd.grid)
        kinds = {max(FIELDS, key=lambda f, c=c: header_score(f[0], c))[0] for c in sd.grid[hr]
                 if max(header_score(f, c) for f, _ in FIELDS) >= .6} if hr >= 0 else set()
        if len(kinds) < 2:  # needs headers for two different fields, so notes/lookup sheets are left out
            skipped.append(n)
            continue
        cols, seen = [], set()
        for h in sd.grid[hr]:
            key = re.sub(r"\s+", " ", h).strip().lower()
            if not key:
                cols.append(None)  # unlabelled column (e.g. serial numbers): not carried over
                continue
            base, i = key, 2
            while key in seen:  # the same header twice in one sheet stays two columns
                key, i = f"{base} ({i})", i + 1
            seen.add(key)
            if key not in where:
                where[key] = len(header)
                header.append(h.strip() if key == base else f"{h.strip()} ({i - 1})")
            cols.append(where[key])
        for r in data_rows(sd.grid, hr):
            stacked.append(({cols[c]: v for c, v in enumerate(sd.grid[r]) if cols[c] is not None and v}, n, r + 1))
    if not stacked:
        raise ValueError("No sheet has a recognisable header row (registration no., name, ...).")
    width = len(header) + 1
    grid = [header + ["Sheet"]]
    origin = [None]
    for vals, n, r in stacked:
        row = [""] * width
        for c, v in vals.items():
            row[c] = v
        row[-1] = n
        grid.append(row)
        origin.append((n, r))
    note = f"Combined {len(names) - len(skipped)} sheet(s), {len(stacked)} rows."
    if skipped:
        note += " Skipped (no header row found): " + ", ".join(skipped)
    return SheetData(str(path), ALL_SHEETS, names, grid, width, origin, note)


# --------------------------------------------------------------------------
# Column auto-detection
# --------------------------------------------------------------------------
_HDR = {
    "reg": [(r"registration|regn|reg\.? ?no|reg ?number|^reg$|regd", 1), (r"enrol+ment|enrol+ no", .9),
            (r"roll", .55), (r"univ.*(no|id)|student id|^id$", .45)],
    "name": [(r"name of (the )?(student|candidate)|(student|candidate|learner)'?s? ?name", 1),
             (r"^(full ?)?name$", .9), (r"^(student|candidate)$", .85), (r"^first ?name$|given ?name", .8),
             (r"name", .45)],
    "name_last": [(r"^(last|sur) ?name$|^surname$", 1), (r"last ?name|surname|family name", .8)],
    "abc": [(r"\babc\b|\bapaar\b", 1)],
    "father": [(r"father", 1), (r"f\.? ?name|fname", .6), (r"guardian", .5)],
    "mother": [(r"mother", 1), (r"m\.? ?name|mname", .6)],
    "dob": [(r"birth|\bdob\b|d\.o\.b", 1), (r"^b\.? ?date$|bdate", .8), (r"date", .3)],
}


def header_score(key, header):
    t = re.sub(r"[_\s]+", " ", str(header or "").lower()).strip()
    if not t:
        return 0.0
    if key == "name" and re.search(r"father|mother|guardian|husband|course|programme|school|college|institut|subject"
                                   r"|last ?name|surname|middle|family name|regional", t):
        return 0.0
    if key == "dob" and re.search(r"admission|issue|exam|publi|join", t):
        return 0.0
    return max((w for pat, w in _HDR[key] if re.search(pat, t)), default=0.0)


def detect_header_row(grid):
    """Index of the header row, or -1 if no row looks like one."""
    best, best_n = -1, 0
    for r in range(min(20, len(grid))):
        n = sum(1 for c in grid[r] if max(header_score(f, c) for f, _ in FIELDS) >= .6)
        if n > best_n:
            best, best_n = r, n
    return best


def data_rows(grid, header_row):
    return [r for r in range(header_row + 1, len(grid)) if any(grid[r])]


@dataclass
class ColumnGuess:
    col: int | None = None
    confidence: str = "none"    # high | medium | low | manual | none
    score: float = 0.0
    reason: str = ""


def auto_detect(grid, header_row, pdf_records=None, settings=None, keep=None):
    """Suggest a column for every field.

    Signals: header wording, what the values look like, and (strongest) whether the
    values equal what was read from the PDFs.  `keep` = {field: col} of manual
    choices that must not be changed."""
    settings = settings or Settings()
    pdf_records = pdf_records or []
    keep = {k: v for k, v in (keep or {}).items() if v is not None}
    ncols = len(grid[0]) if grid else 0
    rows = data_rows(grid, header_row)
    sample = rows[:400]
    hdr = lambda c: grid[header_row][c] if 0 <= header_row < len(grid) else ""
    vals = lambda c, rs: [grid[r][c] for r in rs if grid[r][c]]
    pdf_regs = [norm_reg(p.fields.get("reg")) for p in pdf_records if p.fields.get("reg")]
    pdf_abcs = [norm_abc(p.fields.get("abc")) for p in pdf_records if p.fields.get("abc")]
    cands = []

    for c in range(ncols):  # ABC ID: header or PDF values only (Aadhaar/reg columns also hold 12 digits)
        h = header_score("abc", hdr(c))
        found = 0
        if pdf_abcs:
            have = {norm_abc(x) for x in vals(c, rows)}
            found = sum(1 for x in pdf_abcs if x in have)
        why = ([f'header "{hdr(c)}"'] if h >= .5 else []) + ([f"{found} of {len(pdf_abcs)} PDF ABC IDs found"] if found else [])
        cands.append(("abc", c, min(1.0, .8 * h + .7 * (found / len(pdf_abcs) if pdf_abcs else 0)), why))
        h = header_score("name_last", hdr(c))
        if h:
            cands.append(("name_last", c, .6 * h, [f'header "{hdr(c)}"']))

    for c in range(ncols):
        h = header_score("reg", hdr(c))
        v = vals(c, sample)
        like = (sum(1 for x in v if re.search(r"\d{5,}", x.replace(" ", "")) and parse_date(x) is None) / len(v)) if v else 0
        uniq = (len({norm_reg(x) for x in v}) / len(v)) if v else 0
        p = 0.0
        found = 0
        if pdf_regs:
            have = {norm_reg(x) for x in vals(c, rows)}
            found = sum(1 for x in pdf_regs if x in have)
            p = found / len(pdf_regs)
        why = []
        if h >= .5:
            why.append(f'header "{hdr(c)}"')
        if found:
            why.append(f"{found} of {len(pdf_regs)} PDF reg. numbers found")
        elif like > .7:
            why.append("values look like ID numbers")
        cands.append(("reg", c, min(1.0, .55 * h + .2 * like * uniq + .7 * p + (.15 if h >= .5 and like > .7 else 0)), why))

    reg_col = keep.get("reg")
    if reg_col is None:
        best = max((x for x in cands if x[0] == "reg"), key=lambda x: x[2], default=None)
        reg_col = best[1] if best and best[2] >= .3 else None

    pairs = []
    if reg_col is not None and pdf_records:
        idx = {}
        for r in rows:
            idx.setdefault(norm_reg(grid[r][reg_col]), r)
        pairs = [(p, idx[norm_reg(p.fields.get("reg"))]) for p in pdf_records
                 if p.fields.get("reg") and norm_reg(p.fields["reg"]) in idx]

    for key in ("name", "father", "mother", "dob"):
        for c in range(ncols):
            h = header_score(key, hdr(c))
            v = vals(c, sample)
            if key == "dob":
                like = (sum(1 for x in v if parse_date(x, settings.day_first)) / len(v)) if v else 0
            else:
                like = (sum(1 for x in v if re.match(r"^[A-Za-z][A-Za-z.\s'\-]{2,}$", x)) / len(v)) if v else 0
            hits = tot = 0
            for rec, r in pairs:
                pv = rec.fields.get(key)
                if not pv:
                    continue
                tot += 1
                if key == "dob":
                    a, b = parse_date(pv, settings.day_first), parse_date(grid[r][c], settings.day_first)
                    hits += bool(a and b and a == b)
                else:
                    hits += name_similarity(pv, grid[r][c], settings.ignore_titles)[0] >= 85
            pf = hits / tot if tot else 0
            why = []
            if h >= .5:
                why.append(f'header "{hdr(c)}"')
            if hits:
                why.append(f"{hits} of {tot} PDF values match")
            elif key == "dob" and like > .7:
                why.append(f"{like:.0%} of values are dates")
            s = (.55 * h + .3 * like + .6 * pf) if key == "dob" else (.6 * h + .1 * like + .6 * pf)
            cands.append((key, c, min(1.0, s), why))

    result = {k: ColumnGuess() for k, _ in MAP_FIELDS}
    used = set(keep.values())
    for k, c in keep.items():
        result[k] = ColumnGuess(c, "manual", 1.0, "Set manually")
    for key, c, s, why in sorted(cands, key=lambda x: -x[2]):
        if result[key].col is not None or c in used or s < .3:
            continue
        result[key] = ColumnGuess(c, "high" if s >= .75 else "medium" if s >= .5 else "low", s, ", ".join(why))
        used.add(c)
    return result


# --------------------------------------------------------------------------
# Comparison
# --------------------------------------------------------------------------
@dataclass
class FieldResult:
    field: str
    pdf_value: str = ""
    excel_value: str = ""
    status: str = ST_SKIPPED
    score: float | None = None
    note: str = ""


@dataclass
class RecordResult:
    pdf: PdfRecord
    overall: str
    excel_row: int | None = None        # 1-based row number as shown in Excel
    fields: dict = field(default_factory=dict)
    note: str = ""


@dataclass
class RunResult:
    records: list
    unmatched_excel: list               # [{"row":int,"reg":str,"name":str}]

    def counts(self):
        c = {k: 0 for k in OVERALL_ORDER}
        for r in self.records:
            c[r.overall] = c.get(r.overall, 0) + 1
        return c


def strict_similarity(a_raw, b_raw, ignore_titles=True):
    """Strict mode: equal only if identical after ignoring case, extra spaces and punctuation
    (and titles, if ignored). Returns (100 or 0, explanation)."""
    a, b = clean_name(a_raw, ignore_titles), clean_name(b_raw, ignore_titles)
    if a == b:
        same = re.sub(r"\s+", " ", str(a_raw).strip()) == re.sub(r"\s+", " ", str(b_raw).strip())
        return 100.0, "Exact" if same else "Same apart from case, spacing or punctuation"
    if not a or not b:
        return 0.0, "Empty after cleaning"
    if a.replace(" ", "") == b.replace(" ", ""):
        return 0.0, "Strict: words are split differently"
    if sorted(a.split()) == sorted(b.split()):
        return 0.0, "Strict: same words, different order"
    return 0.0, "Strict: text differs"


def compare_field(key, pdf_val, excel_val, s: Settings) -> FieldResult:
    p, e = str(pdf_val or "").strip(), str(excel_val or "").strip()
    fr = FieldResult(key, p, e)
    if key == "abc":
        pa, ea = norm_abc(p), norm_abc(e)
        fr.pdf_value, fr.excel_value = pa or p, ea or e
        if not pa:  # many marksheets have no ABC ID; that is not an error
            fr.status, fr.note = ST_SKIPPED, "No ABC ID on the marksheet"
        elif not ea:
            fr.status, fr.note = ST_MISSING, "Empty in Excel"
        elif pa == ea:
            fr.status, fr.score, fr.note = ST_MATCH, 100.0, "Same ABC ID"
        else:
            fr.status, fr.score, fr.note = ST_MISMATCH, 0.0, "Different ABC ID"
        return fr
    if key == "dob":
        pd_, ed = parse_date(p, s.day_first), parse_date(e, s.day_first)
        fr.pdf_value, fr.excel_value = (fmt_date(pd_) or p), (fmt_date(ed) or e)
    if not p and not e:
        fr.status, fr.note = ST_MISSING, "Empty in both"
    elif not p:
        fr.status, fr.note = ST_MISSING, "Not found in PDF"
    elif not e:
        fr.status, fr.note = ST_MISSING, "Empty in Excel"
    elif key == "dob":
        if pd_ and ed:
            if pd_ == ed:
                fr.status, fr.score, fr.note = ST_MATCH, 100.0, "Same date"
            elif pd_.year == ed.year and pd_.month == ed.day and pd_.day == ed.month:
                fr.status, fr.score, fr.note = ST_REVIEW, 0.0, "Day and month look swapped"
            else:
                fr.status, fr.score, fr.note = ST_MISMATCH, 0.0, "Different dates"
        else:
            same = norm_reg(p) == norm_reg(e)
            fr.status, fr.score = (ST_MATCH, 100.0) if same else (ST_MISMATCH, 0.0)
            fr.note = "Same text" if same else "Could not read one of the dates"
    else:
        sim = strict_similarity if s.mode == MODE_STRICT else name_similarity
        score, note = sim(p, e, s.ignore_titles)
        fr.score, fr.note = score, note
        if score >= 100:
            fr.status = ST_MATCH
        elif score >= s.match_threshold:
            fr.status = ST_CLOSE
        elif score >= s.review_threshold:
            fr.status = ST_REVIEW
        else:
            fr.status = ST_MISMATCH
    return fr


def _overall(statuses):
    statuses = [x for x in statuses if x != ST_SKIPPED]
    if not statuses:
        return OV_REVIEW  # nothing was actually compared
    if ST_MISMATCH in statuses:
        return OV_MISMATCH
    if ST_REVIEW in statuses or ST_MISSING in statuses:
        return OV_REVIEW
    if ST_CLOSE in statuses:
        return OV_MINOR
    return OV_VERIFIED


def compare(grid, header_row, mapping, pdf_records, settings=None, origin=None) -> RunResult:
    """mapping: {field: column index or None}. Registration number must be mapped.

    origin: optional per-row (sheet, row) list from load_all_sheets(); then excel_row is shown as
    "SOM!3" (sheet and row in that sheet) instead of a plain number."""
    settings = settings or Settings()
    rc = mapping.get("reg")
    if rc is None:
        raise ValueError("Map the registration number column first; it is used to pair rows.")
    cell = lambda r, c: grid[r][c] if c is not None and c < len(grid[r]) else ""
    xrow = lambda r: f"{origin[r][0]}!{origin[r][1]}" if origin and r < len(origin) and origin[r] else r + 1
    where = lambda r: f"sheet {origin[r][0]} row {origin[r][1]}" if origin and r < len(origin) and origin[r] else f"row {r + 1}"
    last = mapping.get("name_last")

    def excel_value(r, key):
        v = cell(r, mapping.get(key))
        if key == "name" and last is not None and cell(r, last):  # First Name + Last Name columns
            v = f"{v} {cell(r, last)}".strip()
        return v

    rows = data_rows(grid, header_row)
    index, abc_index = {}, {}
    ac = mapping.get("abc")
    for r in rows:
        k = norm_reg(cell(r, rc))
        if k:
            index.setdefault(k, []).append(r)
        a = norm_abc(cell(r, ac)) if ac is not None else ""
        if a:
            abc_index.setdefault(a, []).append(r)
    used, results = set(), []
    for p in pdf_records:
        k = norm_reg(p.fields.get("reg"))
        paired_by = "reg"
        if not k:
            a = norm_abc(p.fields.get("abc"))
            if not (a and a in abc_index):
                results.append(RecordResult(p, OV_NOREG, note=p.note or "Registration number not found in the PDF"))
                continue
            hits, paired_by = abc_index[a], "abc"
        else:
            hits = index.get(k, [])
        if not hits:
            near = [(edit_distance(k, x), x) for x in index if abs(len(x) - len(k)) <= 2]
            near = sorted(n for n in near if n[0] <= 1)
            note = "Registration number not found in Excel"
            if near:
                r0 = index[near[0][1]][0]
                note += f". Closest in Excel: {cell(r0, rc)} ({where(r0)})"
            results.append(RecordResult(p, OV_NOTFOUND, note=note))
            continue
        r = hits[0]
        used.add(r)
        if paired_by == "reg":
            frs = {"reg": FieldResult("reg", str(p.fields.get("reg", "")), cell(r, rc), ST_MATCH, 100.0, "Paired on this")}
        else:
            frs = {"reg": FieldResult("reg", "", cell(r, rc), ST_SKIPPED, None, "Not on the marksheet; paired by ABC ID")}
        for key in COMPARE_FIELDS:
            c = mapping.get(key)
            if c is None:
                frs[key] = FieldResult(key, str(p.fields.get(key, "")), "", ST_SKIPPED, None, "Column not mapped")
            else:
                frs[key] = compare_field(key, p.fields.get(key), excel_value(r, key), settings)
        notes = []
        if paired_by == "abc":
            notes.append("No reg. no. in the PDF; paired by ABC ID")
        if len(hits) > 1:
            label = "ABC ID" if paired_by == "abc" else "Reg. no."
            notes.append(f"{label} appears in Excel at {', '.join(where(x) for x in hits)}; first used")
        results.append(RecordResult(p, _overall([f.status for k, f in frs.items() if k != "reg"]), xrow(r), frs,
                                    "; ".join(notes)))
    unmatched = [{"row": xrow(r), "reg": cell(r, rc), "name": excel_value(r, "name")}
                 for r in rows if r not in used and cell(r, rc)]
    return RunResult(results, unmatched)
