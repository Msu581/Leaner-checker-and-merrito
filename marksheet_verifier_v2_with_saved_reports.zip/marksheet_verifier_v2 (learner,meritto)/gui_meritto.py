"""
gui_meritto.py - the "Meritto vs Marksheet" tab.

1 choose the Meritto Excel  2 add marksheet PDFs  3 check the columns (auto-detected, changeable)
4 run  5 double-click a result to adjust it by hand  6 export.
Matching mode, title handling and OCR are shared with the Excel vs Marksheet tab.
"""
from __future__ import annotations

import queue
import threading
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import core
import meritto as M
from core import FIELD_LABELS, col_letter
from gui import (  # safe: gui.App imports this module only after gui has fully loaded
    MODES,
    open_file,
)

NOT_USED = "(not used)"
AUTO = "(automatic)"
FILTERS = {"All": None, "Problems only": M.M_PROBLEM, "Correct": M.M_OK, "Still wrong / mismatch": (M.M_OLD, M.M_WRONG),
           "Not found": (M.M_NOPDF, M.M_NOFIELD), "Not checked": (M.M_MARKS, M.M_SKIP)}
TAGS = {M.M_CORRECT: "ok", M.M_MINOR: "minor", M.M_REVIEW: "review", M.M_NOFIELD: "review",
        M.M_OLD: "bad", M.M_WRONG: "bad", M.M_NOPDF: "bad", M.M_MARKS: "skip", M.M_SKIP: "skip"}
FIELD_CHOICES = {FIELD_LABELS[k]: k for k in M.CHECKABLE}


class MerittoTab(ttk.Frame):
    def __init__(self, master, app):
        super().__init__(master, padding=8)
        self.app = app                      # gui.App: shared settings, status bar, progress bar
        self.sheet: core.SheetData | None = None
        self.header_row = -1
        self.guesses = {k: core.ColumnGuess() for k, _ in M.ROLES}
        self.manual: dict[str, int] = {}
        self.pdf_records: list[core.PdfRecord] = []
        self.seen_pdfs: set[str] = set()
        self.checks: list[M.Check] = []
        self.run_info: dict | None = None
        self.shown: list[M.Check] = []
        self.v_sheet = tk.StringVar()
        self.v_header = tk.IntVar(value=0)
        self.v_last = tk.IntVar(value=0)
        self.v_filter = tk.StringVar(value=next(iter(FILTERS)))
        self.v_tally = tk.StringVar(value="")
        self.col_vars = {k: tk.StringVar(value=NOT_USED) for k, _ in M.ROLES}
        self._build()

    # ------------------------------------------------------------------ layout
    def _build(self):
        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(2, weight=1)

        ex = ttk.LabelFrame(self, text="1  Meritto Excel file", padding=8)
        ex.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=(0, 6))
        self.l_excel = ttk.Label(ex, text="No file chosen", style="Hint.TLabel")
        self.l_excel.grid(row=0, column=0, columnspan=6, sticky="w")
        ttk.Button(ex, text="Choose Excel file...", command=self.browse_excel).grid(row=1, column=0, pady=6, sticky="w")
        ttk.Label(ex, text="Sheet").grid(row=1, column=1, sticky="e", padx=(10, 4))
        self.cb_sheet = ttk.Combobox(ex, textvariable=self.v_sheet, state="readonly", width=18)
        self.cb_sheet.grid(row=1, column=2, columnspan=4, sticky="w")
        self.cb_sheet.bind("<<ComboboxSelected>>", lambda e: self.change_sheet())
        ttk.Label(ex, text="Header row").grid(row=2, column=0, sticky="w")
        sp = ttk.Spinbox(ex, from_=1, to=1000, width=6, textvariable=self.v_header, command=self.change_header)
        sp.grid(row=2, column=1, sticky="w", padx=(10, 0))
        sp.bind("<Return>", lambda e: self.change_header())
        sp.bind("<FocusOut>", lambda e: self.change_header())
        ttk.Label(ex, text="Last row (0 = all)").grid(row=2, column=2, sticky="e", padx=(10, 4))
        ttk.Spinbox(ex, from_=0, to=100000, width=7, textvariable=self.v_last).grid(row=2, column=3, sticky="w")

        se = ttk.LabelFrame(self, text="Matching (shared with the Excel vs Marksheet tab)", padding=8)
        se.grid(row=0, column=1, sticky="nsew", padx=(6, 0), pady=(0, 6))
        ttk.Label(se, text="Name matching mode").grid(row=0, column=0, sticky="w")
        ttk.Combobox(se, textvariable=self.app.v_mode, state="readonly", width=18, values=list(MODES)).grid(
            row=0, column=1, sticky="w", padx=8)
        ttk.Checkbutton(se, text="Ignore titles (Mr, Smt, Shri...) in names", variable=self.app.v_titles).grid(
            row=1, column=0, columnspan=2, sticky="w")
        ttk.Checkbutton(se, text="Use OCR for scanned PDFs (needs Tesseract)", variable=self.app.v_ocr).grid(
            row=2, column=0, columnspan=2, sticky="w")
        ttk.Label(se, text="Strict: S R Sahoo and R S Sahoo are different; Deep Chand and Deepchand are different.\n"
                           "Normal: small spelling, spacing and word-order differences are accepted.",
                  style="Hint.TLabel", justify="left").grid(row=3, column=0, columnspan=2, sticky="w", pady=(4, 0))

        mp = ttk.LabelFrame(self, text="3  Columns (auto-detected; change any dropdown)", padding=8)
        mp.grid(row=1, column=0, sticky="nsew", padx=(0, 6))
        mp.columnconfigure(1, weight=1)
        self.cb_col, self.l_conf = {}, {}
        for i, (key, label) in enumerate(M.ROLES):
            req = key in ("enroll", "expected")
            ttk.Label(mp, text=label + (" *" if req else ""), style="Head.TLabel").grid(row=i, column=0, sticky="w", pady=2)
            cb = ttk.Combobox(mp, textvariable=self.col_vars[key], state="readonly", width=30, values=[NOT_USED])
            cb.grid(row=i, column=1, sticky="ew", padx=8, pady=2)
            cb.bind("<<ComboboxSelected>>", lambda e, k=key: self.on_col(k))
            self.cb_col[key] = cb
            self.l_conf[key] = ttk.Label(mp, text="", width=26)
            self.l_conf[key].grid(row=i, column=2, sticky="w")
        bt = ttk.Frame(mp)
        bt.grid(row=len(M.ROLES), column=0, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Button(bt, text="Reset to auto-detect", command=lambda: self.detect(keep_manual=False)).pack(side="left")
        ttk.Label(bt, text="* required. Each 'Label : value' line is checked separately.", style="Hint.TLabel").pack(
            side="left", padx=10)

        pf = ttk.LabelFrame(self, text="2  Marksheet PDFs", padding=8)
        pf.grid(row=1, column=1, sticky="nsew", padx=(6, 0))
        pf.columnconfigure(0, weight=1)
        pf.rowconfigure(1, weight=1)
        b = ttk.Frame(pf)
        b.grid(row=0, column=0, sticky="w", pady=(0, 6))
        ttk.Button(b, text="Add PDFs...", command=self.browse_pdfs).pack(side="left")
        ttk.Button(b, text="Add folder...", command=self.browse_folder).pack(side="left", padx=6)
        ttk.Button(b, text="Clear all", command=self.clear_pdfs).pack(side="left")
        cols = ("file", "reg", "abc", "name", "father", "mother")
        self.tv_pdf = ttk.Treeview(pf, columns=cols, show="headings", height=6)
        for c, w, t in [("file", 150, "File"), ("reg", 105, "Reg. no."), ("abc", 100, "ABC ID"), ("name", 110, "Name"),
                        ("father", 110, "Father"), ("mother", 110, "Mother")]:
            self.tv_pdf.heading(c, text=t)
            self.tv_pdf.column(c, width=w, minwidth=40, stretch=c == "file")
        self.tv_pdf.tag_configure("bad", background="#F8D9D5")
        ys = ttk.Scrollbar(pf, orient="vertical", command=self.tv_pdf.yview)
        self.tv_pdf.configure(yscrollcommand=ys.set)
        self.tv_pdf.grid(row=1, column=0, sticky="nsew")
        ys.grid(row=1, column=1, sticky="ns")

        rs = ttk.LabelFrame(self, text="Results (double-click a row to see details or adjust it by hand)", padding=8)
        rs.grid(row=2, column=0, columnspan=2, sticky="nsew", pady=(6, 0))
        rs.columnconfigure(0, weight=1)
        rs.rowconfigure(1, weight=1)
        bar = ttk.Frame(rs)
        bar.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        ttk.Button(bar, text="Run check", style="Big.TButton", command=self.run).pack(side="left")
        ttk.Button(bar, text="Re-check (keep manual changes)", command=self.recheck).pack(side="left", padx=6)
        ttk.Label(bar, text="Show").pack(side="left", padx=(12, 4))
        cb = ttk.Combobox(bar, textvariable=self.v_filter, values=list(FILTERS), state="readonly", width=22)
        cb.pack(side="left")
        cb.bind("<<ComboboxSelected>>", lambda e: self.fill())
        ttk.Button(bar, text="Export Excel report...", command=self.export).pack(side="right")
        ttk.Label(rs, textvariable=self.v_tally, style="Hint.TLabel").grid(row=2, column=0, sticky="w", pady=(6, 0))
        cols = ("row", "enr", "student", "field", "exp", "pdf", "status", "file")
        self.tv = ttk.Treeview(rs, columns=cols, show="headings", selectmode="browse")
        for c, w, t in [("row", 50, "Row"), ("enr", 110, "Enrollment"), ("student", 140, "Student"), ("field", 110, "Field"),
                        ("exp", 190, "Expected (Meritto)"), ("pdf", 190, "In PDF"), ("status", 200, "Result"),
                        ("file", 160, "PDF file")]:
            self.tv.heading(c, text=t)
            self.tv.column(c, width=w, minwidth=40, stretch=c in ("exp", "pdf", "status"))
        for tag, color in {"ok": "#DFF2E4", "minor": "#EAF3DC", "review": "#FBF0C9", "bad": "#F8D9D5", "skip": "#EDEDED"}.items():
            self.tv.tag_configure(tag, background=color)
        ys = ttk.Scrollbar(rs, orient="vertical", command=self.tv.yview)
        self.tv.configure(yscrollcommand=ys.set)
        self.tv.grid(row=1, column=0, sticky="nsew")
        ys.grid(row=1, column=1, sticky="ns")
        self.tv.bind("<Double-1>", self.open_detail)

    # ------------------------------------------------------------------ Excel
    def browse_excel(self):
        p = filedialog.askopenfilename(title="Choose the Meritto Excel file",
                                       filetypes=[("Excel or CSV", "*.xlsx *.xlsm *.xls *.ods *.csv *.tsv"), ("All files", "*.*")])
        if p:
            self.load_excel(p)

    def load_excel(self, path, sheet=None):
        try:
            self.sheet = core.load_sheet(path, sheet)
        except Exception as e:  # noqa: BLE001  (show any read error to the user)
            messagebox.showerror("Could not read file", f"{Path(path).name}\n\n{e}")
            return
        self.l_excel.config(text=f"{Path(path).name}  ({len(self.sheet.grid)} rows, {self.sheet.ncols} columns)")
        self.cb_sheet.config(values=self.sheet.sheet_names)
        self.v_sheet.set(self.sheet.sheet)
        self.header_row = M.detect_header_row(self.sheet.grid)
        if self.header_row < 0:
            self.header_row = 0
            messagebox.showinfo("Header row", "Could not find the header row automatically. Set 'Header row' by hand.")
        self.v_header.set(self.header_row + 1)
        self.manual.clear()
        self.detect(keep_manual=False)
        self.app.status(f"Meritto file loaded: {Path(path).name}, header row {self.header_row + 1}.")

    def change_sheet(self):
        if self.sheet and self.v_sheet.get() != self.sheet.sheet:
            self.load_excel(self.sheet.path, self.v_sheet.get())

    def change_header(self):
        if not self.sheet:
            return
        try:
            n = int(self.v_header.get())
        except (tk.TclError, ValueError):
            return
        n = max(1, min(n, len(self.sheet.grid)))
        if n - 1 != self.header_row:
            self.header_row = n - 1
            self.detect(keep_manual=True)

    def choices(self):
        out = [NOT_USED]
        if self.sheet:
            for c in range(self.sheet.ncols):
                h = self.sheet.grid[self.header_row][c] if 0 <= self.header_row < len(self.sheet.grid) else ""
                out.append(f"{col_letter(c)}: {h[:26]}" if h else col_letter(c))
        return out

    def detect(self, keep_manual=True):
        if not self.sheet:
            return
        if not keep_manual:
            self.manual.clear()
        self.guesses = M.detect_columns(self.sheet.grid, self.header_row, self.pdf_records, keep=self.manual)
        ch = self.choices()
        for key, _ in M.ROLES:
            g = self.guesses[key]
            self.cb_col[key].config(values=ch)
            self.col_vars[key].set(ch[g.col + 1] if g.col is not None and g.col + 1 < len(ch) else NOT_USED)
            self._conf(key)

    def _conf(self, key):
        g = self.guesses[key]
        txt = {"manual": "Set manually", "none": "Not found"}.get(g.confidence, f"Auto, {g.confidence}")
        color = {"high": "#2E7A4D", "medium": "#93600E", "low": "#B03A2E", "manual": "#0F5E6E"}.get(g.confidence, "#777777")
        self.l_conf[key].config(text=txt, foreground=color)

    def on_col(self, key):
        i = self.cb_col[key].current()
        col = None if i <= 0 else i - 1
        if col is None:
            self.manual.pop(key, None)
            self.guesses[key] = core.ColumnGuess()
        else:
            for other, g in self.guesses.items():  # one column serves one role
                if other != key and g.col == col:
                    self.guesses[other] = core.ColumnGuess()
                    self.manual.pop(other, None)
                    self.col_vars[other].set(NOT_USED)
                    self._conf(other)
            self.manual[key] = col
            self.guesses[key] = core.ColumnGuess(col, "manual", 1.0, "Set manually")
        self._conf(key)

    # ------------------------------------------------------------------ PDFs
    def browse_pdfs(self):
        ps = filedialog.askopenfilenames(title="Choose marksheet PDFs", filetypes=[("PDF files", "*.pdf")])
        if ps:
            self.add_pdfs(list(ps))

    def browse_folder(self):
        d = filedialog.askdirectory(title="Choose a folder of marksheet PDFs")
        if d:
            self.add_pdfs(sorted(str(p) for p in Path(d).rglob("*") if p.suffix.lower() == ".pdf"))

    def add_pdfs(self, paths):
        paths = [p for p in paths if p not in self.seen_pdfs]
        if not paths:
            return
        use_ocr, q = self.app.v_ocr.get(), queue.Queue()

        def work():
            for i, p in enumerate(paths, 1):
                try:
                    q.put(("ok", p, core.read_pdf(p, use_ocr=use_ocr), i))
                except Exception as e:  # noqa: BLE001  (one bad PDF must not stop the rest)
                    q.put(("err", p, str(e), i))
            q.put(("done", None, None, 0))

        self.app.progress.pack(side="right", padx=8)
        self.app.progress.start(12)
        threading.Thread(target=work, daemon=True).start()
        self.after(80, lambda: self._poll(q, len(paths), []))

    def _poll(self, q, total, errors):
        done = False
        try:
            while True:
                kind, p, data, i = q.get_nowait()
                if kind == "ok":
                    self.pdf_records.extend(data)
                    self.seen_pdfs.add(p)
                    self.app.status(f"Read {i} of {total} PDFs...")
                elif kind == "err":
                    errors.append(f"{Path(p).name}: {data}")
                else:
                    done = True
        except queue.Empty:
            pass
        if not done:
            self.after(80, lambda: self._poll(q, total, errors))
            return
        self.app.progress.stop()
        self.app.progress.pack_forget()
        self.refresh_pdfs()
        self.detect(keep_manual=True)
        bad = sum(1 for r in self.pdf_records if r.unreadable)
        self.app.status(f"Meritto tab: {len(self.pdf_records)} PDF records loaded" + (f", {bad} unreadable." if bad else "."))
        if errors:
            messagebox.showwarning("Some PDFs could not be opened", "\n".join(errors[:10]))

    def refresh_pdfs(self):
        self.tv_pdf.delete(*self.tv_pdf.get_children())
        for i, r in enumerate(self.pdf_records):
            f = r.fields
            self.tv_pdf.insert("", "end", iid=str(i), tags=("bad",) if r.unreadable else (),
                               values=(r.file, f.get("reg", ""), f.get("abc", ""), f.get("name", ""), f.get("father", ""),
                                       f.get("mother", "")))

    def clear_pdfs(self):
        self.pdf_records.clear()
        self.seen_pdfs.clear()
        self.refresh_pdfs()

    # ------------------------------------------------------------------ run
    def run(self):
        if not self.sheet:
            return messagebox.showinfo("Excel file needed", "Choose the Meritto Excel file first.")
        if not self.pdf_records:
            return messagebox.showinfo("PDFs needed", "Add the marksheet PDFs first.")
        if any(c.manual for c in self.checks) and not messagebox.askyesno(
                "Discard manual changes?", "Running again re-reads the Excel and discards your manual adjustments.\n"
                                           "Use 'Re-check' to keep them. Continue?"):
            return
        cols = {k: g.col for k, g in self.guesses.items()}
        try:
            last = int(self.v_last.get() or 0)
        except (tk.TclError, ValueError):
            last = 0
        try:
            self.checks = M.build_checks(self.sheet.grid, self.header_row, cols, last or None)
        except ValueError as e:
            return messagebox.showinfo("Choose the columns", str(e))
        s = self.app.settings()
        M.run_checks(self.checks, self.pdf_records, s)
        self.run_info = dict(created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), excel_file=Path(self.sheet.path).name,
                             sheet=self.sheet.sheet, header_row=self.header_row, columns=cols, settings=s.to_dict(),
                             pdf_count=len(self.pdf_records))
        self.fill()
        self.app.status(f"Meritto check finished: {len(self.checks)} checks.")

    def recheck(self):
        if not self.checks:
            return self.run()
        s = self.app.settings()
        M.run_checks(self.checks, self.pdf_records, s)
        if self.run_info:
            self.run_info.update(settings=s.to_dict(), pdf_count=len(self.pdf_records),
                                 created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        self.fill()
        self.app.status("Re-checked with the current settings and PDFs (manual changes kept).")

    def fill(self):
        self.tv.delete(*self.tv.get_children())
        self.shown = []
        keep = FILTERS[self.v_filter.get()]
        for c in self.checks:
            if keep and c.status not in keep:
                continue
            self.shown.append(c)
            self.tv.insert("", "end", iid=str(len(self.shown) - 1), tags=(TAGS.get(c.status, "skip"),),
                           values=(c.excel_row, c.enrollment, c.student, c.field_label, c.expected, c.pdf_value,
                                   c.status + ("  (manual)" if c.manual else ""), c.pdf_file))
        n = M.counts(self.checks)
        self.v_tally.set("   ".join(f"{k}: {v}" for k, v in n.items() if v) or "No checks yet.")

    # ------------------------------------------------------------------ detail / manual override
    def open_detail(self, event):
        iid = self.tv.identify_row(event.y)
        if not iid:
            return
        c = self.shown[int(iid)]
        win = tk.Toplevel(self)
        win.title(f"Row {c.excel_row}: {c.student or c.enrollment}")
        win.transient(self)
        win.columnconfigure(1, weight=1)
        info = [("Excel row", c.excel_row), ("Enrollment no.", c.enrollment), ("Student", c.student),
                ("Remarks (Excel)", c.remark), ("Old value (marksheet)", c.claimed or "-"), ("Result", c.status),
                ("Match %", "" if c.score is None else f"{c.score:.0f}"), ("Details", c.note),
                ("Manual changes", "; ".join(c.manual) or "-")]
        for i, (k, v) in enumerate(info):
            ttk.Label(win, text=k, style="Head.TLabel").grid(row=i, column=0, sticky="nw", padx=10, pady=2)
            ttk.Label(win, text=str(v), wraplength=520, justify="left").grid(row=i, column=1, sticky="w", padx=10, pady=2)
        r = len(info)
        ttk.Separator(win).grid(row=r, column=0, columnspan=2, sticky="ew", pady=8)
        ttk.Label(win, text="Adjust by hand", style="Head.TLabel").grid(row=r + 1, column=0, sticky="w", padx=10)
        v_field = tk.StringVar(value=FIELD_LABELS.get(c.field, ""))
        v_exp = tk.StringVar(value=c.expected)
        files = [AUTO] + sorted({p.path for p in self.pdf_records}, key=lambda x: Path(x).name.lower())
        v_pdf = tk.StringVar(value=Path(c.force_pdf_path).name if c.force_pdf_path else AUTO)
        v_val = tk.StringVar(value=c.force_pdf_value if c.force_pdf_value is not None else "")
        rows = [("Field to check", ttk.Combobox(win, textvariable=v_field, state="readonly", values=list(FIELD_CHOICES))),
                ("Expected value", ttk.Entry(win, textvariable=v_exp, width=50)),
                ("PDF to use", ttk.Combobox(win, textvariable=v_pdf, state="readonly", width=48,
                                            values=[AUTO] + [Path(x).name for x in files[1:]])),
                ("Value in PDF (blank = read it)", ttk.Entry(win, textvariable=v_val, width=50))]
        for i, (k, w) in enumerate(rows, r + 2):
            ttk.Label(win, text=k).grid(row=i, column=0, sticky="w", padx=10, pady=3)
            w.grid(row=i, column=1, sticky="ew", padx=10, pady=3)
        ttk.Label(win, text=f"Automatic value read from the PDF: {c.pdf_value or '-'}" if c.force_pdf_value is None else
                  "A manual PDF value is in use.", style="Hint.TLabel").grid(row=r + 6, column=1, sticky="w", padx=10)

        def save():
            changes = []
            fld = FIELD_CHOICES.get(v_field.get())
            if fld and fld != c.field:
                changes.append(f"field set to {v_field.get()}")
                c.field, c.kind = fld, "field"
            if v_exp.get().strip() != c.expected:
                changes.append(f'expected set to "{v_exp.get().strip()}"')
                c.expected = v_exp.get().strip()
                c.kind = "field" if c.expected and c.field else c.kind
            name = v_pdf.get()
            path = None if name == AUTO else next((x for x in files[1:] if Path(x).name == name), None)
            if path != c.force_pdf_path:
                changes.append(f"PDF set to {name}" if path else "PDF back to automatic")
                c.force_pdf_path = path
            val = v_val.get().strip() or None
            if val != c.force_pdf_value:
                changes.append(f'PDF value set to "{val}"' if val else "PDF value back to automatic")
                c.force_pdf_value = val
            if changes:
                c.manual.extend(changes)
                if c.kind == "field" and not c.field:
                    c.kind = "unsupported"
                M.evaluate(c, self.pdf_records, self.app.settings())
                self.fill()
            win.destroy()

        bb = ttk.Frame(win)
        bb.grid(row=r + 7, column=0, columnspan=2, sticky="e", padx=10, pady=10)
        ttk.Button(bb, text="Cancel", command=win.destroy).pack(side="right")
        ttk.Button(bb, text="Save and re-check", command=save).pack(side="right", padx=6)

    # ------------------------------------------------------------------ export
    def export(self):
        if not self.checks:
            return messagebox.showinfo("Nothing to export", "Run the check first.")
        from report import build_meritto_report

        p = filedialog.asksaveasfilename(title="Save Excel report", defaultextension=".xlsx",
                                         initialfile=f"meritto_report_{datetime.now():%Y%m%d_%H%M}.xlsx",
                                         filetypes=[("Excel workbook", "*.xlsx")])
        if not p:
            return
        try:
            build_meritto_report(p, self.run_info or {}, self.checks)
        except PermissionError:
            return messagebox.showerror("Could not save", "The file is open in Excel. Close it and try again.")
        except Exception as e:  # noqa: BLE001
            return messagebox.showerror("Could not save", str(e))
        summary = ", ".join(f"{k} {v}" for k, v in M.counts(self.checks).items() if v)
        self.app.status(f"Report saved: {p}" + self.app.store_report("Meritto", p, self.run_info, summary=summary,
                                                                   checks=self.checks))
        if messagebox.askyesno("Report saved", "Open the report now?"):
            open_file(p)
