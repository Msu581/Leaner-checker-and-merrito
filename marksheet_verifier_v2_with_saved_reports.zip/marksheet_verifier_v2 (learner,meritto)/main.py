"""
Marksheet Verifier: compare PDF marksheets with an Excel record.

  python main.py                     open the GUI
  python main.py cli --excel students.xlsx --pdf pdfs/ --out report.xlsx
  python main.py history --reg 251612400699
  python main.py meritto --excel 1083.xlsx --pdf pdfs/ --out meritto_report.xlsx [--strict]
  python main.py reports                         list every stored Excel report (date/time, type, totals)
  python main.py reports --get 3 --out copy.xlsx write stored report 3 back to a file
"""
from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

import core
from core import MAP_FIELDS, Settings, col_index, col_letter

DEFAULT_DB = Path(__file__).with_name("marksheet_results.db")


def _resolve_col(spec, grid, header_row, ncols):
    spec = spec.strip()
    if spec.isalpha() and len(spec) <= 2 and col_index(spec) < ncols:
        return col_index(spec)
    if 0 <= header_row < len(grid):
        for i, h in enumerate(grid[header_row]):
            if h.strip().lower() == spec.lower():
                return i
    raise SystemExit(f"Cannot find column '{spec}'. Use a letter (C) or the exact header text.")


def cli(a):
    from report import build_report
    from storage import Database

    if (a.sheet or "").lower() == "all":
        sheet = core.load_all_sheets(a.excel)
        print(sheet.note, file=sys.stderr)
    else:
        sheet = core.load_sheet(a.excel, a.sheet)
    if sheet.origin:
        hr = 0  # load_all_sheets() puts the combined header in row 1
    else:
        hr = (a.header_row - 1) if a.header_row is not None else core.detect_header_row(sheet.grid)
    s = _settings(a)
    recs = _read_pdfs(a.pdf, s)

    guesses = core.auto_detect(sheet.grid, hr, recs, s)
    manual = {}
    for item in a.map or []:
        k, _, v = item.partition("=")
        if k not in dict(MAP_FIELDS):
            raise SystemExit(f"Unknown field '{k}'. Use one of: {', '.join(dict(MAP_FIELDS))}")
        manual[k] = _resolve_col(v, sheet.grid, hr, sheet.ncols)
    if manual:
        guesses = core.auto_detect(sheet.grid, hr, recs, s, keep=manual)
    mapping = {k: g.col for k, g in guesses.items()}
    print("Column mapping:", file=sys.stderr)
    for k, label in MAP_FIELDS:
        g = guesses[k]
        print(f"  {label:18} -> {col_letter(g.col) if g.col is not None else '-':3} {g.confidence:7} {g.reason}", file=sys.stderr)

    result = core.compare(sheet.grid, hr, mapping, recs, s, origin=sheet.origin)
    info = dict(created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), excel_file=Path(a.excel).name, sheet=sheet.sheet,
                header_row=hr, mapping=mapping, settings=s.to_dict())
    db = run_id = None
    if not a.no_db:
        db = Database(a.db)
        run_id = db.save_run(info, result)
        print(f"Saved to database {a.db} as run {run_id}", file=sys.stderr)
    build_report(a.out, info, result)
    if db is not None:
        from storage import learner_summary
        rid = db.save_report("Learner", a.out, info, run_id=run_id, summary=learner_summary(result))
        print(f"Report stored in the database as report {rid}", file=sys.stderr)
    for k, v in result.counts().items():
        print(f"{k:32} {v}")
    print(f"Report written to {a.out}")


def _settings(a):
    return Settings(day_first=not a.month_first, match_threshold=a.match, review_threshold=min(a.review, a.match),
                    ignore_titles=not a.keep_titles, ocr=a.ocr, mode=core.MODE_STRICT if a.strict else core.MODE_NORMAL)


def _read_pdfs(specs, s):
    paths = []
    for p in specs:
        p = Path(p)
        paths += sorted(x for x in p.rglob("*") if x.suffix.lower() == ".pdf") if p.is_dir() else [p]
    if not paths:
        raise SystemExit("No PDF files found.")
    recs = []
    for i, p in enumerate(paths, 1):
        print(f"[{i}/{len(paths)}] reading {p.name}", file=sys.stderr)
        recs += core.read_pdf(p, use_ocr=s.ocr)
    return recs


def meritto_cli(a):
    import meritto as M
    from report import build_meritto_report

    sheet = core.load_sheet(a.excel, a.sheet)
    hr = (a.header_row - 1) if a.header_row is not None else M.detect_header_row(sheet.grid)
    if hr < 0:
        raise SystemExit("Could not find the header row; pass --header-row N.")
    s = _settings(a)
    recs = _read_pdfs(a.pdf, s)
    manual = {}
    for item in a.col or []:
        k, _, v = item.partition("=")
        if k not in M.ROLE_LABELS:
            raise SystemExit(f"Unknown column role '{k}'. Use one of: {', '.join(M.ROLE_LABELS)}")
        manual[k] = _resolve_col(v, sheet.grid, hr, sheet.ncols)
    guesses = M.detect_columns(sheet.grid, hr, recs, keep=manual)
    cols = {k: g.col for k, g in guesses.items()}
    print(f"Header row {hr + 1}. Columns:", file=sys.stderr)
    for k, label in M.ROLES:
        g = guesses[k]
        print(f"  {label:36} -> {col_letter(g.col) if g.col is not None else '-':3} {g.confidence:7} {g.reason}", file=sys.stderr)
    try:
        checks = M.build_checks(sheet.grid, hr, cols, a.last_row)
    except ValueError as e:
        raise SystemExit(str(e)) from None
    M.run_checks(checks, recs, s)
    info = dict(created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), excel_file=Path(a.excel).name, sheet=sheet.sheet,
                header_row=hr, columns=cols, settings=s.to_dict(), pdf_count=len(recs))
    build_meritto_report(a.out, info, checks)
    if not a.no_db:
        from storage import Database
        summary = ", ".join(f"{k} {v}" for k, v in M.counts(checks).items() if v)
        rid = Database(a.db).save_report("Meritto", a.out, info, summary=summary, checks=checks)
        print(f"Report and {len(checks)} checks stored in {a.db} as report {rid}", file=sys.stderr)
    for k, v in M.counts(checks).items():
        print(f"{k:34} {v}")
    print(f"Report written to {a.out}")


def history(a):
    from storage import Database

    rows = Database(a.db).history_for_reg(a.reg)
    if not rows:
        print("No saved results for that registration number.")
    for r in rows:
        print(f"run {r['run_id']:>3}  {r['created_at']}  {r['pdf_file']:35} row {r['excel_row'] or '-':>4}  {r['overall']}  {r['note'] or ''}")


def reports(a):
    from storage import Database

    db = Database(a.db)
    if a.get is not None:
        name, data = db.report_file(a.get)
        out = Path(a.out or name)
        out.write_bytes(data)
        print(f"Report {a.get} written to {out}")
        return
    rows = db.list_reports()
    if not rows:
        print("No reports stored yet.")
    for r in rows:
        print(f"{r['id']:>4}  {r['created_at']}  {r['kind']:8} {r['file_name']:42} {r['summary'] or ''}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--db", default=str(DEFAULT_DB), help="SQLite database file")
    sub = ap.add_subparsers(dest="cmd")
    c = sub.add_parser("cli", help="run a comparison without the GUI")
    c.add_argument("--excel", required=True)
    c.add_argument("--pdf", required=True, nargs="+", help="PDF files and/or folders")
    c.add_argument("--out", default=f"verification_report_{datetime.now():%Y%m%d_%H%M}.xlsx")
    c.add_argument("--sheet", help="sheet name, or 'all' to combine every sheet")
    c.add_argument("--header-row", type=int, help="1-based; 0 = no header. Default: auto")
    c.add_argument("--map", nargs="*", metavar="FIELD=COL", help="e.g. reg=C name=B father=E mother=D dob=F")
    c.add_argument("--match", type=float, default=92, help="close-match threshold (default 92)")
    c.add_argument("--review", type=float, default=75, help="review threshold (default 75)")
    c.add_argument("--month-first", action="store_true", help="read 05-07-2006 as May 7")
    c.add_argument("--keep-titles", action="store_true", help="do not strip Mr/Smt/Shri")
    c.add_argument("--ocr", action="store_true")
    c.add_argument("--strict", action="store_true", help="strict name matching (only case/spaces/punctuation ignored)")
    c.add_argument("--no-db", action="store_true")
    mc = sub.add_parser("meritto", help="Meritto vs Marksheet: check expected values against the PDFs")
    mc.add_argument("--excel", required=True)
    mc.add_argument("--pdf", required=True, nargs="+", help="PDF files and/or folders")
    mc.add_argument("--out", default=f"meritto_report_{datetime.now():%Y%m%d_%H%M}.xlsx")
    mc.add_argument("--sheet")
    mc.add_argument("--header-row", type=int, help="1-based. Default: auto")
    mc.add_argument("--last-row", type=int, help="1-based last row to read. Default: all")
    mc.add_argument("--col", nargs="*", metavar="ROLE=COL", help="e.g. enroll=C expected=F claimed=G")
    mc.add_argument("--strict", action="store_true", help="strict name matching (only case/spaces/punctuation ignored)")
    mc.add_argument("--keep-titles", action="store_true", help="do not strip Mr/Smt/Shri")
    mc.add_argument("--month-first", action="store_true")
    mc.add_argument("--ocr", action="store_true")
    mc.add_argument("--no-db", action="store_true", help="do not store the report in the database")
    mc.set_defaults(match=92.0, review=75.0)
    h = sub.add_parser("history", help="show saved results for a registration number")
    h.add_argument("--reg", required=True)
    r = sub.add_parser("reports", help="list the Excel reports stored in the database, or export one")
    r.add_argument("--get", type=int, metavar="ID", help="write report ID back to an .xlsx file")
    r.add_argument("--out", help="file name for --get (default: the original name)")
    a = ap.parse_args()
    if a.cmd == "cli":
        cli(a)
    elif a.cmd == "meritto":
        meritto_cli(a)
    elif a.cmd == "history":
        history(a)
    elif a.cmd == "reports":
        reports(a)
    else:
        try:
            import gui
        except ImportError as e:
            raise SystemExit(f"The GUI needs Tkinter ({e}). On Ubuntu/Debian: sudo apt install python3-tk")
        gui.run(a.db)


if __name__ == "__main__":
    main()
