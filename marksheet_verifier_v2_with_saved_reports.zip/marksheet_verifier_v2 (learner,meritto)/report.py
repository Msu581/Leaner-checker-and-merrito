"""
report.py - formatted Excel report of a comparison run.

Sheets
  Summary          run details, column mapping, live COUNTIF totals, colour legend
  Comparison       one row per PDF record, all fields side by side
  Needs attention  one row per problem field, with a reviewer-decision dropdown
  Unmatched Excel  Excel rows that had no PDF
"""
from __future__ import annotations

from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from core import (COMPARE_FIELDS, FIELD_LABELS, MAP_FIELDS, OV_MINOR, OV_MISMATCH, OV_NOREG, OV_NOTFOUND, OV_REVIEW,
                  OV_VERIFIED, OVERALL_ORDER, ST_CLOSE, ST_MATCH, ST_MISMATCH, ST_MISSING, ST_REVIEW, ST_SKIPPED,
                  RunResult, col_letter)

FONT = "Arial"
INK = "16262C"
HEAD_FILL = PatternFill("solid", fgColor="0F5E6E")
GROUP_FILL = PatternFill("solid", fgColor="16262C")
THIN = Side(style="thin", color="C9D4D3")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# (fill, font colour)
PALETTE = {
    ST_MATCH: ("C6EFCE", "006100"),
    ST_CLOSE: ("E2EFDA", "375623"),
    ST_REVIEW: ("FFEB9C", "7F6000"),
    ST_MISSING: ("FFEB9C", "7F6000"),
    ST_MISMATCH: ("FFC7CE", "9C0006"),
    ST_SKIPPED: ("EDEDED", "595959"),
    OV_VERIFIED: ("C6EFCE", "006100"),
    OV_MINOR: ("E2EFDA", "375623"),
    OV_REVIEW: ("FFEB9C", "7F6000"),
    OV_MISMATCH: ("FFC7CE", "9C0006"),
    OV_NOTFOUND: ("FFC7CE", "9C0006"),
    OV_NOREG: ("FFC7CE", "9C0006"),
}


def _f(bold=False, color=INK, size=10):
    return Font(name=FONT, bold=bold, color=color, size=size)


def _paint(cell, key):
    fill, color = PALETTE[key]
    cell.fill = PatternFill("solid", fgColor=fill)
    cell.font = _f(True, color)


def _body(cell, wrap=True, center=False):
    cell.font = _f()
    cell.border = BORDER
    cell.alignment = Alignment(vertical="top", wrap_text=wrap, horizontal="center" if center else "left")


def _header(ws, row, headers, start_col=1):
    for i, h in enumerate(headers):
        c = ws.cell(row=row, column=start_col + i, value=h)
        c.font = _f(True, "FFFFFF")
        c.fill = HEAD_FILL
        c.border = BORDER
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[row].height = 30


def _widths(ws, caps, first_row, last_row):
    for ci in range(1, ws.max_column + 1):
        longest = 0
        for r in range(first_row, min(last_row, first_row + 400) + 1):
            v = ws.cell(row=r, column=ci).value
            if v is not None:
                longest = max(longest, max(len(x) for x in str(v).split("\n")))
        ws.column_dimensions[get_column_letter(ci)].width = max(8, min(longest + 3, caps.get(ci, 38)))


def _page(ws):
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.sheet_view.showGridLines = False


def _mode_text(s):
    if s.get("mode") == "strict":
        return "Strict (only case, extra spaces and punctuation ignored; thresholds not used)"
    return "Normal (fuzzy: thresholds, initials and word order allowed)"


def build_report(path, info: dict, result: RunResult):
    wb = Workbook()

    # ---------------------------------------------------------------- Comparison
    cmp_ws = wb.active
    cmp_ws.title = "Comparison"
    base = ["#", "PDF file", "Page", "Reg. no. (PDF)", "Excel row", "Overall result"]
    sub = ["PDF value", "Excel value", "Result", "Match %"]
    for i, h in enumerate(base):
        pass
    cmp_ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(base))
    g = cmp_ws.cell(row=1, column=1, value="Record")
    cols = len(base)
    groups = [(1, len(base), "Record")]
    for k in COMPARE_FIELDS:
        groups.append((cols + 1, cols + len(sub), FIELD_LABELS[k]))
        cols += len(sub)
    for a, b, label in groups:
        if b > a and a != 1:
            cmp_ws.merge_cells(start_row=1, start_column=a, end_row=1, end_column=b)
        c = cmp_ws.cell(row=1, column=a, value=label)
        for ci in range(a, b + 1):
            cmp_ws.cell(row=1, column=ci).fill = GROUP_FILL
            cmp_ws.cell(row=1, column=ci).border = BORDER
        c.font = _f(True, "FFFFFF", 11)
        c.alignment = Alignment(horizontal="center", vertical="center")
    cmp_ws.row_dimensions[1].height = 22
    _header(cmp_ws, 2, base + sub * len(COMPARE_FIELDS))

    first = 3
    for n, rec in enumerate(result.records, 1):
        r = first + n - 1
        row = [n, rec.pdf.file, rec.pdf.page, rec.pdf.fields.get("reg", ""), rec.excel_row, rec.overall]
        for k in COMPARE_FIELDS:
            f = rec.fields.get(k)
            if f:
                row += [f.pdf_value, f.excel_value, f.status, f.score]
            else:
                row += [rec.pdf.fields.get(k, ""), "", ST_SKIPPED, None]
        for ci, v in enumerate(row, 1):
            c = cmp_ws.cell(row=r, column=ci, value=v)
            _body(c, center=ci in (1, 3, 5))
        _paint(cmp_ws.cell(row=r, column=6), rec.overall)
        for j in range(len(COMPARE_FIELDS)):
            rc = len(base) + 1 + j * len(sub)
            st = cmp_ws.cell(row=r, column=rc + 2)
            _paint(st, st.value)
            st.alignment = Alignment(horizontal="center", vertical="top")
            sc = cmp_ws.cell(row=r, column=rc + 3)
            sc.number_format = '0"%"'
            sc.alignment = Alignment(horizontal="center", vertical="top")
    last = first + max(len(result.records), 1) - 1
    cmp_ws.freeze_panes = cmp_ws.cell(row=3, column=4)
    cmp_ws.auto_filter.ref = f"A2:{get_column_letter(cmp_ws.max_column)}{last}"
    _widths(cmp_ws, {1: 6, 2: 34, 4: 18, 6: 28}, 3, last)
    for j in range(len(COMPARE_FIELDS)):
        rc = len(base) + 1 + j * len(sub)
        cmp_ws.column_dimensions[get_column_letter(rc + 2)].width = 13
        cmp_ws.column_dimensions[get_column_letter(rc + 3)].width = 9
    _page(cmp_ws)
    cmp_ws.print_title_rows = "1:2"

    # ---------------------------------------------------------------- Summary
    ws = wb.create_sheet("Summary", 0)
    ws.sheet_view.showGridLines = False
    ws["A1"] = "Marksheet verification report"
    ws["A1"].font = _f(True, "0F5E6E", 16)
    ws["A2"] = "PDF marksheets compared against an Excel record"
    ws["A2"].font = _f(False, "5A6B71", 10)

    def kv(r, k, v):
        a, b = ws.cell(row=r, column=1, value=k), ws.cell(row=r, column=2, value=v)
        a.font, b.font = _f(True), _f()
        a.alignment = b.alignment = Alignment(vertical="top", wrap_text=True)
        for c in (a, b):
            c.border = BORDER

    s = info.get("settings", {})
    r = 4
    ws.cell(row=r, column=1, value="Run details").font = _f(True, "0F5E6E", 12)
    r += 1
    for k, v in [
        ("Generated", datetime.now().strftime("%d-%m-%Y %H:%M")),
        ("Run date", info.get("created_at", "")),
        ("Excel file", info.get("excel_file", "")),
        ("Sheet", info.get("sheet", "")),
        ("Header row", (info.get("header_row", -1) + 1) or "none"),
        ("Close-match threshold", f'{s.get("match_threshold", "")}%  (name score at or above this is "Close match")'),
        ("Review threshold", f'{s.get("review_threshold", "")}%  (at or above: "Review"; below: "Mismatch")'),
        ("Date order", "Day-Month-Year" if s.get("day_first", True) else "Month-Day-Year"),
        ("Titles ignored (Mr, Smt, ...)", "Yes" if s.get("ignore_titles", True) else "No"),
        ("Name matching mode", _mode_text(s)),
    ]:
        kv(r, k, v)
        r += 1

    r += 1
    ws.cell(row=r, column=1, value="Column mapping").font = _f(True, "0F5E6E", 12)
    r += 1
    _header(ws, r, ["Field", "Excel column"])
    r += 1
    for key, label in MAP_FIELDS:
        col = info.get("mapping", {}).get(key)
        kv(r, label, col_letter(col) if isinstance(col, int) else "Not mapped")
        r += 1

    r += 1
    ws.cell(row=r, column=1, value="Results").font = _f(True, "0F5E6E", 12)
    r += 1
    _header(ws, r, ["Result", "Records", "Share"])
    r += 1
    rng = f"Comparison!$F$3:$F${last}"
    t0 = r
    total_row = t0 + len(OVERALL_ORDER)
    for ov in OVERALL_ORDER:
        a = ws.cell(row=r, column=1, value=ov)
        b = ws.cell(row=r, column=2, value=f'=COUNTIF({rng},A{r})')
        c = ws.cell(row=r, column=3, value=f"=IF($B${total_row}=0,0,B{r}/$B${total_row})")
        for x in (a, b, c):
            _body(x, wrap=False)
        _paint(a, ov)
        b.alignment = c.alignment = Alignment(horizontal="center")
        c.number_format = "0.0%"
        r += 1
    a = ws.cell(row=r, column=1, value="Total records")
    b = ws.cell(row=r, column=2, value=f"=SUM(B{t0}:B{r - 1})")
    c = ws.cell(row=r, column=3, value=f"=IF(B{r}=0,0,SUM(C{t0}:C{r - 1}))")
    for x in (a, b, c):
        _body(x, wrap=False)
        x.font = _f(True)
    b.alignment = c.alignment = Alignment(horizontal="center")
    c.number_format = "0.0%"
    r += 2

    ws.cell(row=r, column=1, value="Results by field").font = _f(True, "0F5E6E", 12)
    r += 1
    stat_list = [ST_MATCH, ST_CLOSE, ST_REVIEW, ST_MISSING, ST_MISMATCH]
    _header(ws, r, ["Field"] + stat_list)
    r += 1
    for j, k in enumerate(COMPARE_FIELDS):
        a = ws.cell(row=r, column=1, value=FIELD_LABELS[k])
        _body(a, wrap=False)
        a.font = _f(True)
        status_col = get_column_letter(len(base) + 1 + j * len(sub) + 2)
        for i, st in enumerate(stat_list):
            x = ws.cell(row=r, column=2 + i, value=f'=COUNTIF(Comparison!${status_col}$3:${status_col}${last},"{st}")')
            _body(x, wrap=False, center=True)
        r += 1

    r += 1
    ws.cell(row=r, column=1, value="How to read this").font = _f(True, "0F5E6E", 12)
    r += 1
    for k, v in [
        (ST_MATCH, "Identical after ignoring case, spacing and punctuation."),
        (ST_CLOSE, "Name is similar enough (at or above the close-match threshold). Accepted automatically."),
        (ST_REVIEW, "Between the review and close-match thresholds, empty in one file, or day/month swapped. Check by hand."),
        (ST_MISMATCH, "Clearly different. Registration number alone does not guarantee the record is right."),
        (ST_SKIPPED, "That column was not mapped, so the field was not compared."),
    ]:
        a, b = ws.cell(row=r, column=1, value=k), ws.cell(row=r, column=2, value=v)
        _body(a, wrap=False)
        _body(b)
        _paint(a, k)
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=6)
        ws.row_dimensions[r].height = 28
        r += 1
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 44
    for ci in "CDEF":
        ws.column_dimensions[ci].width = 14
    _page(ws)

    # ---------------------------------------------------------------- Needs attention
    na = wb.create_sheet("Needs attention")
    heads = ["PDF file", "Page", "Reg. no. (PDF)", "Excel row", "Field", "PDF value", "Excel value",
             "Result", "Match %", "Details", "Reviewer decision", "Reviewer comment"]
    _header(na, 1, heads)
    r = 2
    for rec in result.records:
        probs = []
        if rec.overall in (OV_NOTFOUND, OV_NOREG):
            probs.append(("Registration no.", rec.pdf.fields.get("reg", ""), "", rec.overall, None, rec.note))
        else:
            for k in COMPARE_FIELDS:
                f = rec.fields.get(k)
                if f and f.status in (ST_REVIEW, ST_MISMATCH, ST_MISSING):
                    probs.append((FIELD_LABELS[k], f.pdf_value, f.excel_value, f.status, f.score, f.note))
            if rec.note and not probs:
                probs.append(("Record", "", "", rec.overall, None, rec.note))
        for fld, pv, ev, st, sc, note in probs:
            vals = [rec.pdf.file, rec.pdf.page, rec.pdf.fields.get("reg", ""), rec.excel_row, fld, pv, ev, st, sc, note, "", ""]
            for ci, v in enumerate(vals, 1):
                _body(na.cell(row=r, column=ci, value=v), center=ci in (2, 4))
            _paint(na.cell(row=r, column=8), st if st in PALETTE else OV_MISMATCH)
            na.cell(row=r, column=8).alignment = Alignment(horizontal="center", vertical="top", wrap_text=True)
            na.cell(row=r, column=9).number_format = '0"%"'
            na.cell(row=r, column=9).alignment = Alignment(horizontal="center", vertical="top")
            r += 1
    if r == 2:
        na.cell(row=2, column=1, value="Nothing needs attention.").font = _f(True, "006100")
    else:
        dv = DataValidation(type="list", formula1='"Accepted,Corrected in Excel,Corrected in PDF,Rejected"', allow_blank=True)
        na.add_data_validation(dv)
        dv.add(f"K2:K{r - 1}")
        na.auto_filter.ref = f"A1:L{r - 1}"
    na.freeze_panes = "A2"
    _widths(na, {1: 34, 10: 46, 12: 30}, 2, r)
    na.column_dimensions["K"].width = 20
    _page(na)

    # ---------------------------------------------------------------- Unmatched Excel
    ue = wb.create_sheet("Unmatched Excel")
    _header(ue, 1, ["Excel row", "Reg. no.", "Student name", "Comment"])
    for i, u in enumerate(result.unmatched_excel, 2):
        for ci, v in enumerate([u["row"], u["reg"], u["name"], "No PDF supplied for this row"], 1):
            _body(ue.cell(row=i, column=ci, value=v), center=ci == 1)
    if not result.unmatched_excel:
        ue.cell(row=2, column=1, value="Every Excel row had a PDF.").font = _f(True, "006100")
    ue.freeze_panes = "A2"
    _widths(ue, {}, 2, len(result.unmatched_excel) + 1)
    _page(ue)

    wb.save(str(path))
    return str(path)


# ====================================================================== Meritto vs Marksheet
def build_meritto_report(path, info: dict, checks):
    """Summary | Results (one row per check) | Needs attention."""
    import meritto as M

    pal = {M.M_CORRECT: PALETTE[ST_MATCH], M.M_MINOR: PALETTE[ST_CLOSE], M.M_REVIEW: PALETTE[ST_REVIEW],
           M.M_OLD: PALETTE[ST_MISMATCH], M.M_WRONG: PALETTE[ST_MISMATCH], M.M_NOFIELD: PALETTE[ST_REVIEW],
           M.M_NOPDF: PALETTE[ST_MISMATCH], M.M_MARKS: PALETTE[ST_SKIPPED], M.M_SKIP: PALETTE[ST_SKIPPED]}

    def paint(cell, st):
        fill, color = pal.get(st, PALETTE[ST_SKIPPED])
        cell.fill = PatternFill("solid", fgColor=fill)
        cell.font = _f(True, color)

    heads = ["#", "Excel row", "Enrollment no.", "Student", "Field", "Expected (Meritto)", "Old value (marksheet)",
             "Value in PDF", "Result", "Match %", "PDF file", "Page", "Details", "Remarks (Excel)", "Manually adjusted"]

    def row_vals(n, c):
        return [n, c.excel_row, c.enrollment, c.student, c.field_label, c.expected, c.claimed, c.pdf_value, c.status,
                c.score, c.pdf_file, c.pdf_page, c.note, c.remark, "; ".join(c.manual) if c.manual else ""]

    wb = Workbook()
    res = wb.active
    res.title = "Results"
    _header(res, 1, heads)
    for n, c in enumerate(checks, 1):
        for ci, v in enumerate(row_vals(n, c), 1):
            _body(res.cell(row=n + 1, column=ci, value=v), center=ci in (1, 2, 10, 12))
        paint(res.cell(row=n + 1, column=9), c.status)
        res.cell(row=n + 1, column=10).number_format = '0"%"'
    last = max(len(checks), 1) + 1
    res.freeze_panes = "D2"
    res.auto_filter.ref = f"A1:{get_column_letter(len(heads))}{last}"
    _widths(res, {1: 6, 4: 24, 6: 30, 7: 30, 8: 30, 9: 22, 11: 30, 13: 50, 14: 40}, 2, last)
    _page(res)

    na = wb.create_sheet("Needs attention")
    _header(na, 1, heads + ["Reviewer decision", "Reviewer comment"])
    r = 2
    for n, c in enumerate(checks, 1):
        if c.status not in M.M_PROBLEM:
            continue
        for ci, v in enumerate(row_vals(n, c) + ["", ""], 1):
            _body(na.cell(row=r, column=ci, value=v), center=ci in (1, 2, 10, 12))
        paint(na.cell(row=r, column=9), c.status)
        na.cell(row=r, column=10).number_format = '0"%"'
        r += 1
    if r == 2:
        na.cell(row=2, column=1, value="Nothing needs attention.").font = _f(True, "006100")
    else:
        dv = DataValidation(type="list", formula1='"Accepted,Marksheet re-issued,Meritto corrected,Rejected"', allow_blank=True)
        na.add_data_validation(dv)
        dv.add(f"P2:P{r - 1}")
        na.auto_filter.ref = f"A1:Q{r - 1}"
    na.freeze_panes = "D2"
    _widths(na, {1: 6, 4: 24, 6: 30, 7: 30, 8: 30, 9: 22, 11: 30, 13: 50, 14: 40, 16: 22, 17: 30}, 2, r)
    _page(na)

    ws = wb.create_sheet("Summary", 0)
    ws.sheet_view.showGridLines = False
    ws["A1"] = "Meritto vs Marksheet report"
    ws["A1"].font = _f(True, "0F5E6E", 16)
    ws["A2"] = "Checks that each marksheet now shows the value given in the Meritto/TR record"
    ws["A2"].font = _f(False, "5A6B71", 10)
    s = info.get("settings", {})
    cols = info.get("columns", {})
    r = 4
    for k, v in [("Generated", datetime.now().strftime("%d-%m-%Y %H:%M")), ("Run date", info.get("created_at", "")),
                 ("Excel file", info.get("excel_file", "")), ("Sheet", info.get("sheet", "")),
                 ("Header row", (info.get("header_row", -1) + 1) or "none"), ("PDF records", info.get("pdf_count", "")),
                 ("Name matching mode", _mode_text(s)),
                 ("Titles ignored (Mr, Smt, ...)", "Yes" if s.get("ignore_titles", True) else "No")] + [
                (label, col_letter(cols[key]) if isinstance(cols.get(key), int) else "Not used") for key, label in M.ROLES]:
        a, b = ws.cell(row=r, column=1, value=k), ws.cell(row=r, column=2, value=v)
        a.font, b.font = _f(True), _f()
        for x in (a, b):
            x.border = BORDER
            x.alignment = Alignment(vertical="top", wrap_text=True)
        r += 1
    r += 1
    _header(ws, r, ["Result", "Checks", "Share"])
    r += 1
    t0, total = r, r + len(M.M_ORDER)
    for st in M.M_ORDER:
        a = ws.cell(row=r, column=1, value=st)
        b = ws.cell(row=r, column=2, value=f"=COUNTIF(Results!$I$2:$I${last},A{r})")
        c = ws.cell(row=r, column=3, value=f"=IF($B${total}=0,0,B{r}/$B${total})")
        for x in (a, b, c):
            _body(x, wrap=False)
        paint(a, st)
        b.alignment = c.alignment = Alignment(horizontal="center")
        c.number_format = "0.0%"
        r += 1
    a, b = ws.cell(row=r, column=1, value="Total checks"), ws.cell(row=r, column=2, value=f"=SUM(B{t0}:B{r - 1})")
    for x in (a, b):
        _body(x, wrap=False)
        x.font = _f(True)
    b.alignment = Alignment(horizontal="center")
    r += 2
    for k, v in [(M.M_CORRECT, "The PDF shows the expected value."),
                 (M.M_MINOR, "Normal mode only: very close to the expected value (spacing, initials, word order)."),
                 (M.M_REVIEW, "Normal mode only: partly similar, or day/month swapped. Check by hand."),
                 (M.M_OLD, "The PDF still shows the old value that was reported as wrong."),
                 (M.M_WRONG, "The PDF shows something else."),
                 (M.M_NOFIELD, "The PDF was found but this field could not be read from it."),
                 (M.M_NOPDF, "No uploaded PDF has this enrollment number (or ABC ID)."),
                 (M.M_MARKS, "The row is about marks, which are not compared automatically."),
                 (M.M_SKIP, "Empty expected value, or a field that is not on marksheets (e.g. Aadhaar).")]:
        a, b = ws.cell(row=r, column=1, value=k), ws.cell(row=r, column=2, value=v)
        _body(a, wrap=False)
        _body(b)
        paint(a, k)
        r += 1
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 80
    ws.column_dimensions["C"].width = 12
    _page(ws)
    wb.save(str(path))
    return str(path)
