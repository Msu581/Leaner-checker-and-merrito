"""
meritto.py - "Meritto vs Marksheet": check that each marksheet now shows the value
the Meritto/TR record says it should.

Each Excel row names a student (enrollment no.) and, in the "expected" column, one or more
lines such as "Father's Name : S R Sahoo". For every line the matching PDF is found by
enrollment number (ABC ID as fallback), the same field is read from it, and the two are
compared using the normal or strict rules from core.py. The optional "old value" column
(what the marksheet wrongly showed) is used to say whether the old error is still there.

No GUI or database code lives here.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, replace
from dataclasses import field as dc_field  # "field" is also a Check attribute

import core
from core import (
    FIELD_LABELS,
    MODE_STRICT,
    ST_CLOSE,
    ST_MATCH,
    ST_REVIEW,
    ColumnGuess,
    Settings,
    header_score,
)

# check results
M_CORRECT = "Correct"
M_MINOR = "Correct (minor differences)"
M_REVIEW = "Needs review"
M_OLD = "Still wrong (same as old value)"
M_WRONG = "Mismatch"
M_NOFIELD = "Field not in PDF"
M_NOPDF = "PDF not found"
M_MARKS = "Marks row (not checked)"
M_SKIP = "Not checked"
M_ORDER = [M_CORRECT, M_MINOR, M_REVIEW, M_OLD, M_WRONG, M_NOFIELD, M_NOPDF, M_MARKS, M_SKIP]
M_OK = (M_CORRECT, M_MINOR)
M_PROBLEM = (M_REVIEW, M_OLD, M_WRONG, M_NOFIELD, M_NOPDF)

# Excel columns this mode uses
ROLES = [
    ("enroll", "Enrollment / Reg. no."),
    ("expected", "Expected data (as per Meritto)"),
    ("claimed", "Old value in marksheet (optional)"),
    ("student", "Student name (optional)"),
    ("remark", "Remarks (optional)"),
    ("abc", "ABC ID (optional)"),
]
ROLE_LABELS = dict(ROLES)
CHECKABLE = ("name", "father", "mother", "dob", "abc", "reg")

_EXPECTED_HDR = re.compile(r"meritto|merito|\btr\b|expected|correct|should be|data as per|as per record", re.I)
_CLAIMED_HDR = re.compile(r"\bin (the )?mark ?sheet|mark ?sheet (data|value)|printed|wrong|incorrect|old value|current", re.I)
_REMARK_HDR = re.compile(r"remark|comment|issue|discrepanc|observation", re.I)
_LINE = re.compile(r"^\s*([^:：]{2,60}?)\s*[:：]\s*(.*?)\s*$")
_MARKS = re.compile(r"\bmarks?\b|\btotal\b|\bgrade\b|\bsgpa\b|\bcgpa\b", re.I)


# --------------------------------------------------------------------------
# Parsing the "Label : value" cells
# --------------------------------------------------------------------------
def parse_cell(text):
    """'Father's Name : A\\nMother's Name : B' -> [(label, field key or None, value), ...].
    Lines without a colon come back with an empty label."""
    out = []
    for line in re.split(r"[\r\n]+", str(text or "")):
        line = line.strip()
        if not line:
            continue
        m = _LINE.match(line)
        if m:
            out.append((m.group(1).strip(), core.label_field(m.group(1)), m.group(2).strip()))
        else:
            out.append(("", None, line))
    return out


@dataclass
class Check:
    """One field to verify, from one Excel row (a row with two lines gives two checks)."""
    excel_row: int                 # 1-based, as shown in Excel
    enrollment: str
    student: str = ""
    remark: str = ""
    label: str = ""                # label as written, e.g. "Father's Name"
    field: str | None = None       # core field key
    expected: str = ""             # value the marksheet should show (Meritto)
    claimed: str = ""              # value the marksheet showed before (optional column)
    kind: str = "field"            # field | marks | unsupported | empty
    abc: str = ""
    pdf_file: str = ""
    pdf_path: str = ""
    pdf_page: int | None = None
    pdf_value: str = ""
    status: str = ""
    score: float | None = None
    note: str = ""
    parse_note: str = ""
    # manual overrides (None = automatic)
    force_pdf_path: str | None = None
    force_pdf_value: str | None = None
    manual: list = dc_field(default_factory=list)   # human-readable list of what was changed

    @property
    def field_label(self):
        return FIELD_LABELS.get(self.field, self.label or "-")


# --------------------------------------------------------------------------
# Column detection
# --------------------------------------------------------------------------
def _role_score(role, h):
    t = re.sub(r"\s+", " ", str(h or "")).strip()
    if not t:
        return 0.0
    if role == "enroll":
        return header_score("reg", t)
    if role == "claimed":
        return 1.0 if _CLAIMED_HDR.search(t) else 0.0
    if role == "expected":
        return 0.0 if _CLAIMED_HDR.search(t) else (1.0 if _EXPECTED_HDR.search(t) else 0.0)
    if role == "student":
        return header_score("name", t)
    if role == "remark":
        return 1.0 if _REMARK_HDR.search(t) else 0.0
    if role == "abc":
        return header_score("abc", t)
    return 0.0


def detect_header_row(grid):
    """Row (0-based) naming the most different roles; -1 if none names two."""
    best, best_n = -1, 1
    for r in range(min(30, len(grid))):
        n = sum(1 for role, _ in ROLES if any(_role_score(role, c) >= .5 for c in grid[r]))
        if n > best_n:
            best, best_n = r, n
    return best


def _looks_labelled(v):
    return any(f for _, f, _ in parse_cell(v))


def detect_columns(grid, header_row, pdf_records=None, keep=None):
    """Suggest a column for every role. `keep` = {role: col} chosen by hand (never changed)."""
    keep = {k: v for k, v in (keep or {}).items() if v is not None}
    ncols = len(grid[0]) if grid else 0
    hdr = lambda c: grid[header_row][c] if 0 <= header_row < len(grid) else ""
    rows = [r for r in range(header_row + 1, len(grid)) if any(grid[r])]
    vals = lambda c: [grid[r][c] for r in rows if grid[r][c]]
    pdf_regs = {core.norm_reg(p.fields.get("reg")) for p in (pdf_records or []) if p.fields.get("reg")}
    cands = []
    for c in range(ncols):
        v = vals(c)
        labelled = (sum(map(_looks_labelled, v)) / len(v)) if v else 0
        idlike = (sum(1 for x in v if re.fullmatch(r"\d{6,}", core.norm_reg(x))) / len(v)) if v else 0
        hits = sum(1 for x in v if core.norm_reg(x) in pdf_regs) if pdf_regs else 0
        for role, _ in ROLES:
            h = _role_score(role, hdr(c))
            why = [f'header "{hdr(c)}"'] if h >= .5 else []
            if role == "enroll":
                s = .6 * h + .3 * idlike + (.5 * min(1, hits / len(pdf_regs)) if pdf_regs else 0)
                if hits:
                    why.append(f"{hits} PDF reg. numbers found")
                elif idlike > .7:
                    why.append("values look like ID numbers")
            elif role in ("expected", "claimed"):
                s = .7 * h + .3 * labelled + (-.01 * c if role == "expected" else .01 * c * (h > 0))  # tie: leftmost = expected
                if labelled > .3:
                    why.append(f"{labelled:.0%} of cells look like 'Label : value'")
            else:
                s = .8 * h
            cands.append((role, c, s, why))
    result = {k: ColumnGuess() for k, _ in ROLES}
    used = set(keep.values())
    for k, c in keep.items():
        result[k] = ColumnGuess(c, "manual", 1.0, "Set manually")
    for role, c, s, why in sorted(cands, key=lambda x: -x[2]):
        if result[role].col is not None or c in used or s < .3:
            continue
        result[role] = ColumnGuess(c, "high" if s >= .7 else "medium" if s >= .5 else "low", s, ", ".join(why))
        used.add(c)
    return result


# --------------------------------------------------------------------------
# Building and running the checks
# --------------------------------------------------------------------------
def build_checks(grid, header_row, cols, last_row=None, row_label=None):
    """Turn the Excel rows into Check objects. cols = {role: column index or None}.
    last_row: 1-based last row to read (None = to the end)."""
    if cols.get("enroll") is None or cols.get("expected") is None:
        raise ValueError("Choose the enrollment column and the expected-data column first.")
    cell = lambda r, role: (grid[r][cols[role]] if cols.get(role) is not None and cols[role] < len(grid[r]) else "").strip()
    row_no = row_label or (lambda r: r + 1)
    end = len(grid) if not last_row else min(len(grid), last_row)
    checks = []
    for r in range(header_row + 1, end):
        enr, exp = cell(r, "enroll"), cell(r, "expected")
        if not enr and not exp:
            continue  # blank row or section title ("HHM Emversity")
        base = dict(excel_row=row_no(r), enrollment=enr, student=cell(r, "student"), remark=cell(r, "remark"),
                    abc=cell(r, "abc"))
        if not exp:
            checks.append(Check(**base, kind="empty", parse_note="Expected-data cell is empty"))
            continue
        claimed = parse_cell(cell(r, "claimed"))
        claimed_by_field = {f: v for _, f, v in claimed if f}
        entries = parse_cell(exp)
        for label, fld, value in entries:
            chk = Check(**base, label=label, field=fld, expected=value)
            if fld is None and not label:
                if _MARKS.search(value):
                    chk.kind = "marks"
                else:  # no label: take the field from the Remarks column if it names one
                    fld = core.label_field(chk.remark) if chk.remark else None
                    if fld in CHECKABLE:
                        chk.field, chk.parse_note = fld, "Field taken from the Remarks column (no label in the cell)"
                    else:
                        chk.kind, chk.parse_note = "unsupported", "No 'Label : value' found and Remarks do not name a field"
            elif fld not in CHECKABLE:
                chk.kind, chk.parse_note = "unsupported", f'"{label}" is not a field read from marksheets'
            if chk.kind == "field":
                if not chk.expected:
                    chk.kind, chk.parse_note = "empty", "No value after the label"
                chk.claimed = claimed_by_field.get(chk.field, "")
                if not chk.claimed and len(entries) == 1 and len(claimed) == 1:
                    chk.claimed = claimed[0][2]
            checks.append(chk)
    _mark_duplicates(checks)
    return checks


def _mark_duplicates(checks):
    seen = {}
    for c in checks:
        if c.kind != "field":
            continue
        seen.setdefault((core.norm_reg(c.enrollment), c.field), []).append(c)
    for group in seen.values():
        if len(group) > 1:
            for c in group:
                others = [str(o.excel_row) for o in group if o is not c]
                c.parse_note = "; ".join(x for x in (c.parse_note, f"Same student and field also on row(s) {', '.join(others)}") if x)


def pdf_index(pdf_records):
    by_reg, by_abc = {}, {}
    for p in pdf_records:
        if p.fields.get("reg"):
            by_reg.setdefault(core.norm_reg(p.fields["reg"]), []).append(p)
        if p.fields.get("abc"):
            by_abc.setdefault(core.norm_abc(p.fields["abc"]), []).append(p)
    return by_reg, by_abc


def _same(field_key, a, b, s: Settings):
    """Strict equality, used for the 'old value' test whatever the mode."""
    return core.compare_field(field_key, a, b, replace(s, mode=MODE_STRICT)).status == ST_MATCH


def evaluate(chk: Check, pdf_records, s: Settings, index=None):
    """Fill in chk.pdf_* / status / score / note."""
    chk.pdf_file = chk.pdf_path = chk.pdf_value = ""
    chk.pdf_page, chk.score, chk.note = None, None, ""
    if chk.kind == "marks":
        chk.status, chk.note = M_MARKS, "Marks are not printed as 'Label : value'; check by hand"
        return chk
    if chk.kind != "field" or not chk.field or not chk.expected:
        chk.status, chk.note = M_SKIP, chk.parse_note or "No expected value to check"
        return chk
    by_reg, by_abc = index or pdf_index(pdf_records)
    if chk.force_pdf_path:
        recs = [p for p in pdf_records if p.path == chk.force_pdf_path]
        how = "chosen by hand"
    else:
        recs, how = by_reg.get(core.norm_reg(chk.enrollment), []), ""
        if not recs and chk.abc and core.norm_abc(chk.abc) in by_abc:
            recs, how = by_abc[core.norm_abc(chk.abc)], "matched by ABC ID"
    if not recs:
        chk.status = M_NOPDF
        k = core.norm_reg(chk.enrollment)
        near = sorted((core.edit_distance(k, x), x) for x in by_reg if k and abs(len(x) - len(k)) <= 1)
        chk.note = "No enrollment number on this row" if not k else "No uploaded PDF has this enrollment number"
        if near and near[0][0] <= 1:
            chk.note += f". Closest PDF: {by_reg[near[0][1]][0].file} ({near[0][1]})"
        return chk
    rec = next((p for p in recs if p.fields.get(chk.field)), recs[0])
    chk.pdf_file, chk.pdf_path, chk.pdf_page = rec.file, rec.path, rec.page
    chk.pdf_value = chk.force_pdf_value if chk.force_pdf_value is not None else str(rec.fields.get(chk.field, ""))
    notes = [x for x in (how, chk.parse_note) if x]
    if rec.unreadable:
        notes.append(rec.note)
    if not chk.pdf_value:
        chk.status = M_NOFIELD
        chk.note = "; ".join([f"{chk.field_label} not found in {rec.file}"] + notes)
        return chk
    fr = core.compare_field(chk.field, chk.pdf_value, chk.expected, s)
    chk.score = fr.score
    if fr.status == ST_MATCH:
        chk.status = M_CORRECT
    elif chk.claimed and _same(chk.field, chk.pdf_value, chk.claimed, s):
        chk.status = M_OLD  # wins over 'close match': this exact value was reported as wrong
    elif fr.status == ST_CLOSE:
        chk.status = M_MINOR
    elif fr.status == ST_REVIEW:
        chk.status = M_REVIEW
    else:
        chk.status = M_WRONG
    if chk.status != M_CORRECT:
        notes.insert(0, f'PDF has "{fr.pdf_value}", expected "{fr.excel_value}" ({fr.note})')
    else:
        notes.insert(0, fr.note)
    chk.note = "; ".join(notes)
    return chk


def run_checks(checks, pdf_records, s: Settings):
    idx = pdf_index(pdf_records)
    for c in checks:
        evaluate(c, pdf_records, s, idx)
    return checks


def counts(checks):
    c = {k: 0 for k in M_ORDER}
    for x in checks:
        c[x.status] = c.get(x.status, 0) + 1
    return c
